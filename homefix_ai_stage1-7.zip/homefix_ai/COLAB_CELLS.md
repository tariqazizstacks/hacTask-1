# HomeFix AI — Colab Notebook Cells

Paste these into `HomeFix_AI.ipynb` in order. These are notebook cells, **not**
project files. Every project file is created from a cell using `%%writefile`.

---

## Cell 1 — Installs

```python
!pip -q install gradio groq python-dotenv sentence-transformers
print("installs done")
```

Do **not** install pandas / numpy / scikit-learn / matplotlib. Colab already
has them and reinstalling is a reliable way to break the runtime.

---

## Cell 2 — Mount Drive and create folders

```python
from google.colab import drive
drive.mount('/content/drive')

import os
BASE = '/content/drive/MyDrive/homefix_ai'
for d in ['data', 'src', 'knowledge_base', 'cache', 'assets']:
    os.makedirs(f'{BASE}/{d}', exist_ok=True)
os.chdir(BASE)
print("working in:", os.getcwd())
```

---

## Cell 3 — Live-reload imports

```python
import sys
if BASE not in sys.path:
    sys.path.append(BASE)
%load_ext autoreload
%autoreload 2
```

Without `autoreload`, editing a module and re-running a cell silently uses the
old version. This costs teams hours of phantom debugging.

---

## Cell 4 — Write the project files

Open `src/config.py` from this package, copy its contents, and paste into a
cell with this as the **first line**:

```
%%writefile src/config.py
```

Repeat for every file:

| File in this package | First line of the Colab cell |
|---|---|
| `src/__init__.py` | `%%writefile src/__init__.py` |
| `src/config.py` | `%%writefile src/config.py` |
| `src/utils.py` | `%%writefile src/utils.py` |
| `src/database.py` | `%%writefile src/database.py` |
| `src/safety.py` | `%%writefile src/safety.py` |
| `src/ai_assistant.py` | `%%writefile src/ai_assistant.py` |
| `src/classifier.py` | `%%writefile src/classifier.py` |
| `src/provider_matching.py` | `%%writefile src/provider_matching.py` |
| `generate_data.py` | `%%writefile generate_data.py` |
| `test_stage3.py` | `%%writefile test_stage3.py` |
| `test_stage4.py` | `%%writefile test_stage4.py` |
| `test_stage5.py` | `%%writefile test_stage5.py` |
| `test_stage6.py` | `%%writefile test_stage6.py` |
| `test_stage7.py` | `%%writefile test_stage7.py` |
| `requirements.txt` | `%%writefile requirements.txt` |
| `.env.example` | `%%writefile .env.example` |

Alternatively, upload this whole folder to your Google Drive once and skip the
`%%writefile` step entirely.

---

## Cell 5 — Config self-check

```python
!python src/config.py
```

Expected:

```
BASE_DIR            : /content/drive/MyDrive/homefix_ai
BASE_DIR exists     : True
DATA_IS_TEMPORARY   : False
Service categories  : 8
Areas               : 6
Weights sum to      : 100
API key found       : True
```

* `API key found : False` → your Colab secret is not set. See Cell 6.
* `DATA_IS_TEMPORARY : True` → Drive did not mount; bookings will be lost.

---

## Cell 6 — Groq health check

First: left sidebar → 🔑 **Secrets** → Add new secret → name `GROQ_API_KEY`,
paste your key from `console.groq.com`, toggle **Notebook access** ON.

```python
from groq import Groq
from src.config import get_api_key, GROQ_MODEL

key = get_api_key()
assert key, "No GROQ_API_KEY. Sidebar -> Secrets -> GROQ_API_KEY -> Notebook access ON"

client = Groq(api_key=key)
resp = client.chat.completions.create(
    model=GROQ_MODEL,
    messages=[{"role": "user", "content": "Reply with exactly: OK"}],
    max_tokens=5,
)
print("model:", GROQ_MODEL, "->", resp.choices[0].message.content)
```

---

## Cell 7 — Confirm the model ID is still live

Groq retires models regularly. Run this before demo day.

```python
import requests
r = requests.get("https://api.groq.com/openai/v1/models",
                 headers={"Authorization": f"Bearer {key}"})
ids = sorted(m["id"] for m in r.json()["data"])
print(*ids, sep="\n")
```

If `llama-3.3-70b-versatile` is not listed, change `GROQ_MODEL` in
`src/config.py`. Nothing else in the project needs to change.

---

## Cell 8 — Generate the data

```python
!python generate_data.py
```

Expected: validation passes, 8 services, 32 providers, 15 seeded requests.

---

## Cell 8b — Stage 3 checks

```python
!python -m src.utils      # helper self-check
!python -m src.database   # data health report
!python test_stage3.py    # full suite: expect 95 passed, 0 failed
```

---

## Cell 8c — Stage 4 checks

```python
!python -m src.safety     # six sample messages across all three tiers
!python test_stage4.py    # expect 97 passed, 0 failed
```

---

## Cell 8d - Stage 5 checks

```python
!python test_stage5.py       # expect 146 passed, 0 failed (no API key needed)
!python -m src.ai_assistant  # LIVE Groq call - needs your key
```

`test_stage5.py` uses a stub client, so it passes with no key and no network.
`python -m src.ai_assistant` is the real thing: it prints the system prompt
size, runs a health check, then extracts slots from two sample messages.
That is the first real proof your key and model ID work end to end.

---

## Cell 8e - Stage 6 checks

```python
!python -m src.classifier   # the brief's 8 examples, scored
!python test_stage6.py      # expect 118 passed, 0 failed
```

`python -m src.classifier` prints a table of the eight worked examples from
requirement C with their scores. Useful as a screenshot for your report.

---

## Cell 8f - Stage 7 checks

```python
!python -m src.provider_matching   # three ranked searches with score reasons
!python test_stage7.py             # expect 101 passed, 0 failed
```

`python -m src.provider_matching` prints the ranked results for an in-area
search, an out-of-area search and the graceful-degradation case. Another good
screenshot for the report.

`test_stage3.py` backs up `requests.csv` before it runs and restores it
afterwards, so it is safe to run at any time — including during a demo.

---

## Cell 9 — Launch the app (from Stage 8 onward)

```python
!python app.py
```

or, to keep it inside the notebook:

```python
from app import demo
demo.launch(share=True, debug=True)
```

The `share=True` public link lasts 72 hours — useful for sending to your
evaluator.

---

## Packaging for submission

```python
!zip -r /content/homefix_ai_submission.zip /content/drive/MyDrive/homefix_ai \
    -x "*/cache/*" "*/__pycache__/*" "*.env"
from google.colab import files
files.download('/content/homefix_ai_submission.zip')
```

Note the exclusions: never ship `.env`, and the embedding cache is
regenerable dead weight.
