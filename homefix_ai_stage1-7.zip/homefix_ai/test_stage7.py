"""
test_stage7.py
==============
Tests for src/provider_matching.py.

    python test_stage7.py

The scoring tests check arithmetic you can verify by hand from providers.csv,
which is the point: a ranking nobody can recompute is a black box, and this
one is meant to be defensible in a viva.
"""

import sys
from pathlib import Path

import pandas as pd

sys.path.append(str(Path(__file__).resolve().parent))

from src import config, database, provider_matching as pm

PASSED = 0
FAILED = 0
W = config.SCORING_WEIGHTS


def check(label: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  PASS  {label}")
    else:
        FAILED += 1
        print(f"  FAIL  {label} {detail}")


def slots(category=None, area=None, urgency="normal", **extra):
    base = {"service_category": category, "area": area, "urgency": urgency}
    base.update(extra)
    return base


# ===========================================================================
print("\n[1] Weights and configuration")
# ===========================================================================
check("weights sum to 100", sum(W.values()) == 100, str(sum(W.values())))
check("area is weighted highest alongside rating",
      W["area"] == 30 and W["rating"] == 30)
check("neutral credit is between 0 and 1", 0 < config.NEUTRAL_CREDIT < 1)
check("same-region credit is partial", 0 < config.SAME_REGION_CREDIT < 1)

# ===========================================================================
print("\n[2] Area scoring")
# ===========================================================================
pts, why = pm._score_area("Islamabad", "Islamabad")
check("exact area gets full points", pts == W["area"], str(pts))
check("exact area explains itself", "Islamabad" in why)

pts, _ = pm._score_area("Rawalpindi", "Islamabad")
check("same region gets partial credit",
      pts == W["area"] * config.SAME_REGION_CREDIT, str(pts))

pts, _ = pm._score_area("Karachi", "Islamabad")
check("different region gets zero", pts == 0.0, str(pts))

pts, why = pm._score_area("Karachi", None)
check("no area given gets neutral credit",
      pts == W["area"] * config.NEUTRAL_CREDIT, str(pts))
check("no area explains itself", "no area" in why)

check("exact beats near beats far",
      pm._score_area("Lahore", "Lahore")[0]
      > pm._score_area("Faisalabad", "Lahore")[0]
      > pm._score_area("Karachi", "Lahore")[0])

# ===========================================================================
print("\n[3] Rating scoring")
# ===========================================================================
check("5.0 gets full points", pm._score_rating(5.0)[0] == W["rating"])
check("4.0 gets 80 percent", pm._score_rating(4.0)[0] == W["rating"] * 0.8)
check("0 gets nothing", pm._score_rating(0)[0] == 0.0)
check("junk rating does not crash", pm._score_rating("excellent")[0] == 0.0)
check("None rating does not crash", pm._score_rating(None)[0] == 0.0)
check("higher rating scores higher",
      pm._score_rating(4.8)[0] > pm._score_rating(4.2)[0])

# ===========================================================================
print("\n[4] Availability scoring depends on urgency")
# ===========================================================================
check("urgent + Today gets full points",
      pm._score_availability("Today", "urgent")[0] == W["availability"])
check("emergency + Today gets full points",
      pm._score_availability("Today", "emergency")[0] == W["availability"])
check("urgent + Tomorrow gets half",
      pm._score_availability("Tomorrow", "urgent")[0] == W["availability"] * 0.5)
check("urgent + Weekends Only gets zero",
      pm._score_availability("Weekends Only", "urgent")[0] == 0.0)

neutral = W["availability"] * config.NEUTRAL_CREDIT
check("normal urgency gives everyone neutral credit",
      all(pm._score_availability(a, "normal")[0] == neutral
          for a in config.AVAILABILITY_OPTIONS))
check("a slow provider is not punished on a non-urgent job",
      pm._score_availability("Weekends Only", "normal")[0]
      > pm._score_availability("Weekends Only", "urgent")[0])
check("unknown availability does not crash",
      pm._score_availability("Whenever", "urgent")[0] == 0.0)

# ===========================================================================
print("\n[5] Price scoring")
# ===========================================================================
check("no budget gives neutral credit",
      pm._score_price(800, 3500, None)[0] == W["price"] * config.NEUTRAL_CREDIT)
check("fully inside budget gets full points",
      pm._score_price(800, 3500, 4000)[0] == W["price"])
check("entirely above budget gets zero",
      pm._score_price(5000, 9000, 3000)[0] == 0.0)

partial = pm._score_price(1000, 3000, 2000)[0]
check("partly inside budget gets partial credit",
      0 < partial < W["price"], str(partial))
check("partial credit is proportional", abs(partial - W["price"] * 0.5) < 0.01)
check("junk prices do not crash",
      pm._score_price("x", None, 1000)[0] == W["price"] * config.NEUTRAL_CREDIT)

# ===========================================================================
print("\n[6] Total score bounds and breakdown")
# ===========================================================================
best = pm.score_provider(
    {"area": "Islamabad", "rating": 5.0, "availability": "Today",
     "price_min": 100, "price_max": 200},
    "Islamabad", "urgent", 5000)
check("a perfect provider scores 100", best["score"] == 100.0, str(best["score"]))

worst = pm.score_provider(
    {"area": "Karachi", "rating": 0, "availability": "Weekends Only",
     "price_min": 9000, "price_max": 9999},
    "Islamabad", "urgent", 100)
check("the worst possible provider scores 0", worst["score"] == 0.0, str(worst["score"]))

parts = sum(best[k] for k in
            ("score_area", "score_rating", "score_availability", "score_price"))
check("the parts add up to the total", abs(parts - best["score"]) < 0.05,
      f"{parts} vs {best['score']}")
check("every factor has an explanation",
      all(best[k] for k in ("why_area", "why_rating", "why_availability", "why_price")))

# ===========================================================================
print("\n[7] Category is a HARD filter")
# ===========================================================================
result = pm.find_providers(slots("Plumber", "Lahore"))
check("only plumbers are returned",
      set(result["providers"]["service_category"]) == {"Plumber"})
check("a 5-star AC technician never appears in a plumbing search",
      "Ahmed Cooling Services" not in set(result["providers"]["provider_name"]))

for category in config.SERVICE_CATEGORIES:
    r = pm.find_providers(slots(category, "Islamabad"))
    check(f"{category} returns only its own trade",
          r["count"] > 0 and set(r["providers"]["service_category"]) == {category})

# ===========================================================================
print("\n[8] Invalid and empty inputs")
# ===========================================================================
for bad in [None, "", "Pipe Guy", "plumber"]:
    r = pm.find_providers(slots(bad, "Lahore"))
    check(f"category {bad!r} returns nothing", r["count"] == 0)
    check(f"category {bad!r} explains why", len(r["message"]) > 20)

check("empty slots do not crash", pm.find_providers({})["count"] == 0)
check("None slots do not crash", pm.find_providers(None)["count"] == 0)
check("result always has a providers DataFrame",
      isinstance(pm.find_providers(None)["providers"], pd.DataFrame))

# empty dataset
real_loader = database.load_providers
database.load_providers = lambda *a, **k: pd.DataFrame()
try:
    r = pm.find_providers(slots("Plumber", "Lahore"))
    check("an empty provider file is handled", r["count"] == 0)
    check("an empty provider file tells you to regenerate",
          "generate_data" in r["message"], r["message"])
finally:
    database.load_providers = real_loader

# ===========================================================================
print("\n[9] Ranking behaviour")
# ===========================================================================
r = pm.find_providers(slots("AC Technician", "Islamabad", "urgent"))
check("three cards are returned", r["count"] == 3, str(r["count"]))
check("the local provider ranks first",
      r["providers"].iloc[0]["area"] == "Islamabad",
      r["providers"].iloc[0]["provider_name"])
check("scores descend",
      list(r["providers"]["score"]) == sorted(r["providers"]["score"], reverse=True))
check("area is not a filter - out-of-area options are still offered",
      set(r["providers"]["area"]) != {"Islamabad"})
check("the note explains the mixed areas", "Islamabad" in r["message"])

check("top_n is respected",
      pm.find_providers(slots("Plumber", "Lahore"), top_n=2)["count"] == 2)
check("top_n larger than the pool is capped",
      pm.find_providers(slots("Plumber", "Lahore"), top_n=99)["count"] == 4)
check("total_in_category is reported",
      pm.find_providers(slots("Plumber", "Lahore"))["total_in_category"] == 4)

first = pm.find_providers(slots("Electrician", "Lahore", "urgent"))
second = pm.find_providers(slots("Electrician", "Lahore", "urgent"))
check("ranking is deterministic across runs",
      list(first["providers"]["provider_id"]) == list(second["providers"]["provider_id"]))

# ===========================================================================
print("\n[10] Graceful degradation")
# ===========================================================================
# Hyderabad has no AC technicians in the demo data.
r = pm.find_providers(slots("AC Technician", "Hyderabad", "urgent"))
check("no local providers still returns results", r["count"] == 3)
check("the out-of-area case is flagged", r["relaxed"] is True)
check("in_area reports zero", r["in_area"] == 0)
check("the message is honest about it",
      "Hyderabad" in r["message"] and "other areas" in r["message"])

r_local = pm.find_providers(slots("Electrician", "Hyderabad", "urgent"))
check("an area WITH a provider is not flagged as relaxed",
      r_local["relaxed"] is False)
check("the local provider still ranks first",
      r_local["providers"].iloc[0]["area"] == "Hyderabad")

r_noarea = pm.find_providers(slots("Plumber", None))
check("no area given still returns results", r_noarea["count"] == 3)
check("no area given is not flagged as relaxed", r_noarea["relaxed"] is False)

# ===========================================================================
print("\n[11] Urgency changes the ranking")
# ===========================================================================
urgent = pm.find_providers(slots("Painter", "Karachi", "urgent"))
normal = pm.find_providers(slots("Painter", "Karachi", "normal"))
u_names = list(urgent["providers"]["provider_name"])
n_names = list(normal["providers"]["provider_name"])
check("urgency affects the ordering or the scores",
      u_names != n_names
      or list(urgent["providers"]["score"]) != list(normal["providers"]["score"]),
      f"{u_names} vs {n_names}")

weekend_only = database.load_providers()
weekend_only = weekend_only[weekend_only["availability"] == "Weekends Only"]
check("the demo data contains weekend-only providers to test against",
      len(weekend_only) > 0)

# ===========================================================================
print("\n[12] Budget filtering")
# ===========================================================================
rich = pm.find_providers(slots("Painter", "Lahore"), budget=20000)
poor = pm.find_providers(slots("Painter", "Lahore"), budget=2500)
check("a generous budget scores higher than a tight one",
      rich["providers"].iloc[0]["score_price"]
      >= poor["providers"].iloc[0]["score_price"])
check("budget can also come from the slots",
      pm.find_providers(slots("Painter", "Lahore", budget_max=20000))
      ["providers"].iloc[0]["score_price"] == W["price"])

# ===========================================================================
print("\n[13] filter_providers - the browse tab")
# ===========================================================================
df = pm.filter_providers("Plumber")
check("category filter works", set(df["service_category"]) == {"Plumber"})
check("browse results are sorted by rating",
      list(df["rating"]) == sorted(df["rating"], reverse=True))

check("area filter works",
      set(pm.filter_providers("Plumber", area="Lahore")["area"]) == {"Lahore"})
check("availability filter works",
      set(pm.filter_providers(availability="Today")["availability"]) == {"Today"})
check("min_rating filter works",
      (pm.filter_providers(min_rating=4.5)["rating"] >= 4.5).all())
check("max_price filter works",
      (pm.filter_providers(max_price=600)["price_min"] <= 600).all())
check("no filters returns everyone", len(pm.filter_providers()) == 32)
check("an invalid category is ignored rather than crashing",
      len(pm.filter_providers("Pipe Guy")) == 32)
check("combined filters narrow the list",
      len(pm.filter_providers("Plumber", area="Lahore")) <= len(pm.filter_providers("Plumber")))
check("an impossible combination returns empty, not an error",
      len(pm.filter_providers("Locksmith", area="Hyderabad")) == 0)

# ===========================================================================
print("\n[14] Explanations")
# ===========================================================================
row = pm.find_providers(slots("AC Technician", "Islamabad", "urgent"))["providers"].iloc[0]
line = pm.explain_score(row)
check("one-line explanation is produced", len(line) > 20)
check("explanation names the area", "Islamabad" in line)
check("explanation names the rating", "out of 5" in line)

md = pm.score_breakdown_markdown(row)
check("breakdown is a markdown table", md.startswith("| Factor |"))
check("breakdown lists all four factors",
      all(f in md for f in ("Area", "Rating", "Availability", "Price")))
check("breakdown shows the total out of 100", "/ 100" in md)
check("breakdown works on a plain dict", pm.score_breakdown_markdown(row.to_dict()) == md)

# ===========================================================================
print("\n[15] The demo flow from the roadmap")
# ===========================================================================
demo = {"service_category": "AC Technician", "area": "Islamabad",
        "urgency": "urgent", "problem_summary": "AC leaking water, not cooling"}
r = pm.find_providers(demo)
check("demo step 5-6: two to three providers are shown", 2 <= r["count"] <= 3)
check("demo: every card has a score", (r["providers"]["score"] > 0).all())
check("demo: every card has a price estimate",
      (r["providers"]["estimated_price"] > 0).all())
check("demo: phone numbers are present for the booking step",
      "phone" in r["providers"].columns)
check("demo: the top pick is a real provider id",
      r["providers"].iloc[0]["provider_id"].startswith("P"))
check("demo: selecting the top pick resolves in the database",
      database.get_provider(r["providers"].iloc[0]["provider_id"]) is not None)

# ===========================================================================
print(f"\n{'=' * 46}")
print(f"  {PASSED} passed, {FAILED} failed")
print(f"{'=' * 46}\n")
sys.exit(1 if FAILED else 0)
