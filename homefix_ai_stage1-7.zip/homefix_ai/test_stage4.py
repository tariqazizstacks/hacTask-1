"""
test_stage4.py
==============
Tests for src/safety.py.

    python test_stage4.py

The false-positive section is the important one. A safety guard that fires on
"I need an AC gas refill" teaches users to dismiss the red banner, which
means they dismiss it when there really is a gas leak. Over-triggering is a
safety bug, not a harmless one.
"""

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

from src import config, safety

PASSED = 0
FAILED = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  PASS  {label}")
    else:
        FAILED += 1
        print(f"  FAIL  {label} {detail}")


def expect(text: str, tier: int, severity: str = None, hazard: str = None,
           allow_llm: bool = None) -> None:
    r = safety.screen(text)
    ok = r["tier"] == tier
    detail = f"-> tier {r['tier']} / {r['severity']} / {r['hazard']}"
    if ok and severity is not None:
        ok = r["severity"] == severity
    if ok and hazard is not None:
        ok = r["hazard"] == hazard
    if ok and allow_llm is not None:
        ok = r["allow_llm"] is allow_llm
    check(f"{text[:52]!r}", ok, detail)


# ===========================================================================
print("\n[1] TIER 1 CRITICAL - gas")
# ===========================================================================
for t in [
    "There is a gas smell in my kitchen",
    "I can smell gas near the stove",
    "gas leak in the kitchen please help",
    "my LPG cylinder is leaking",
    "the gas is leaking from the pipe",
    "I smell gas in the whole house",
]:
    expect(t, 1, "critical", "gas", allow_llm=False)

# ===========================================================================
print("\n[2] TIER 1 CRITICAL - fire and smoke")
# ===========================================================================
for t in [
    "the curtains caught fire",
    "smoke is coming from the switchboard",
    "there are flames near the meter",
    "my kitchen is on fire",
]:
    expect(t, 1, "critical", allow_llm=False)

# ===========================================================================
print("\n[3] TIER 1 CRITICAL - electrical")
# ===========================================================================
for t in [
    "I got an electric shock from the washing machine",
    "the socket is sparking",
    "there is a burning smell from the wiring",
    "exposed electrical wiring in the bathroom",
    "the switch has melted",
    "water is leaking onto the socket",
]:
    expect(t, 1, "critical", "electrical", allow_llm=False)

# ===========================================================================
print("\n[4] TIER 1 CRITICAL - injury")
# ===========================================================================
for t in [
    "my brother is bleeding after touching the wire",
    "someone is unconscious",
]:
    expect(t, 1, "critical", allow_llm=False)

# ===========================================================================
print("\n[5] TIER 1 URGENT - water and structural (LLM still allowed)")
# ===========================================================================
for t in [
    "water is everywhere, the pipe burst",
    "my bathroom is flooding",
    "sewage is backing up in the drain",
]:
    expect(t, 1, "urgent", "water", allow_llm=True)

for t in [
    "the ceiling is collapsing in the bedroom",
    "there is a large crack in the wall",
]:
    expect(t, 1, "urgent", "structural", allow_llm=True)

# ===========================================================================
print("\n[6] FALSE POSITIVES - these must NOT trigger (tier 3)")
# ===========================================================================
for t in [
    "I need an AC gas refill",
    "my AC needs gas charging",
    "gas refilling for split AC",
    "my gas geyser is not heating",
    "I want gas stove installation",
    "please install a smoke detector",
    "I need smoke detector battery replacement",
    "fireplace cleaning service",
    "fire alarm installation please",
    "water not coming in the tap",
    "there is low water pressure",
    "my water heater not working",
    "no water supply since morning",
    "burning smell from the food in the oven",
    "hairline crack in the wall needs filling",
    "crack in the window glass",
    "my lights keep going off",
    "my washing machine is making a strange noise",
    "I need someone to paint my bedroom",
    "my door lock is broken",
    "my wooden table is broken",
    "AC is leaking water and not cooling",
]:
    expect(t, 3, "none", allow_llm=True)

# ===========================================================================
print("\n[7] TIER 2 - dangerous DIY requests")
# ===========================================================================
for t in [
    "How do I replace a circuit breaker myself?",
    "can I fix the geyser myself",
    "teach me how to rewire my room",
    "step by step guide for gas line connection",
    "how to change the main switch",
    "any way I can fix the fuse instead of calling an electrician",
    "how do I add refrigerant to my AC myself",
]:
    expect(t, 2, "caution", "diy_risk", allow_llm=True)

# ===========================================================================
print("\n[8] TIER 2 must NOT fire on harmless 'how do I' questions")
# ===========================================================================
for t in [
    "how do I book a plumber",
    "how much does painting cost",
    "how do I cancel my request",
    "how do I clean my sofa myself",
    "can I select a different provider",
    "how to get a carpenter for my cupboard",
]:
    expect(t, 3, "none", allow_llm=True)

# ===========================================================================
print("\n[9] Result shape and edge cases")
# ===========================================================================
required = {"tier", "severity", "hazard", "label", "advice", "message",
            "allow_llm", "category_hint", "matched", "urgency_override"}

for label, value in [("empty string", ""), ("None", None),
                     ("whitespace", "   \n  "), ("emoji only", "\U0001F600")]:
    r = safety.screen(value)
    check(f"{label} -> safe tier 3", r["tier"] == 3 and r["allow_llm"] is True)
    check(f"{label} -> all keys present", required <= set(r.keys()))

r = safety.screen("gas leak")
check("critical result has every key", required <= set(r.keys()))
check("critical message is non-empty", len(r["message"]) > 50)
check("critical message includes the rescue contact",
      config.EMERGENCY_CONTACTS["rescue"] in r["message"])
check("critical message refuses repair steps",
      "not a certified technician" in r["message"])
check("critical sets urgency_override", r["urgency_override"] == "emergency")
check("critical records matched patterns", len(r["matched"]) > 0)
check("gas suggests Plumber as the category hint",
      r["category_hint"] == "Plumber")

r_safe = safety.screen("my sink is blocked")
check("safe result has an empty message", r_safe["message"] == "")
check("safe result has no advice", r_safe["advice"] == [])

r2 = safety.screen("how do I rewire the socket myself")
check("tier 2 message has no emergency number",
      config.EMERGENCY_CONTACTS["rescue"] not in r2["message"])
check("tier 2 message offers to find a professional",
      "professional" in r2["message"].lower())

check("very long input is handled",
      safety.screen("gas leak " + "x" * 5000)["tier"] == 1)
check("mixed case is handled", safety.screen("GAS LEAK IN KITCHEN")["tier"] == 1)
check("advice lists are copies, not shared references",
      safety.screen("gas leak")["advice"] is not safety.HAZARDS["gas"]["advice"])

# ===========================================================================
print("\n[10] LLM integration helpers")
# ===========================================================================
check("is_blocked True for critical", safety.is_blocked(safety.screen("gas leak")))
check("is_blocked False for urgent", not safety.is_blocked(safety.screen("pipe burst")))
check("is_blocked False for tier 2",
      not safety.is_blocked(safety.screen("how do I rewire this myself")))
check("is_blocked False for safe", not safety.is_blocked(safety.screen("sink blocked")))
check("is_blocked handles an empty dict", not safety.is_blocked({}))

note_safe = safety.system_note(safety.screen("my sink is blocked"))
check("no system note for safe text", note_safe == "")

note_diy = safety.system_note(safety.screen("how do I rewire the socket myself"))
check("tier 2 note is a SAFETY OVERRIDE", "SAFETY OVERRIDE" in note_diy)
check("tier 2 note forbids instructions", "Do NOT provide any instructions" in note_diy)
check("tier 2 note forbids claiming certification",
      "certified technician" in note_diy)

note_haz = safety.system_note(safety.screen("pipe burst water everywhere"))
check("tier 1 note is a SAFETY OVERRIDE", "SAFETY OVERRIDE" in note_haz)
check("tier 1 note forbids repair steps", "repair steps" in note_haz)
check("system_note handles an empty dict", safety.system_note({}) == "")

check("disclaimer names the project as academic",
      "academic" in safety.SAFETY_DISCLAIMER)
check("disclaimer denies being a technician",
      "not a certified technician" in safety.SAFETY_DISCLAIMER)

# ===========================================================================
print("\n[11] Requirement J - the exact example from the brief")
# ===========================================================================
r = safety.screen("How do I repair exposed electrical wiring?")
check("brief example is caught as a hazard", r["tier"] in (1, 2), str(r["tier"]))
check("brief example never yields repair steps", not r["allow_llm"] or r["tier"] == 2)
check("brief example mentions a professional or electrician",
      "professional" in r["message"].lower() or "electrician" in r["message"].lower())

# ===========================================================================
print(f"\n{'=' * 46}")
print(f"  {PASSED} passed, {FAILED} failed")
print(f"{'=' * 46}\n")
sys.exit(1 if FAILED else 0)
