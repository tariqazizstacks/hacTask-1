"""
test_stage6.py
==============
Tests for src/classifier.py.

    python test_stage6.py

Section [1] is every worked example from requirement C of the project brief,
used verbatim. If those eight ever fail, the app fails its own specification.

Section [3] is the part that matters technically: cases where symptom words
point at one trade and the device points at another.
"""

import json
import sys
from pathlib import Path
from types import SimpleNamespace

sys.path.append(str(Path(__file__).resolve().parent))

from src import ai_assistant as ai
from src import classifier, config

PASSED = 0
FAILED = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  PASS  {label}")
    else:
        FAILED += 1
        print(f"  FAIL  {label} {detail}")


def expect(text: str, category: str) -> None:
    r = classifier.classify(text)
    check(f"{text[:46]!r} -> {category}", r["category"] == category,
          f"got {r['category']} (score {r['score']}, {r['reason']})")


# ===========================================================================
print("\n[1] Requirement C - the brief's own examples, verbatim")
# ===========================================================================
expect("My pipe is leaking", "Plumber")
expect("My lights keep going off", "Electrician")
expect("My washing machine is making a strange noise", "Appliance Repair")
expect("My AC is leaking water", "AC Technician")
expect("I need someone to paint my bedroom", "Painter")
expect("My door lock is broken", "Locksmith")
expect("I need someone to clean my house", "Home Cleaner")
expect("My wooden table is broken", "Carpenter")

# ===========================================================================
print("\n[2] Realistic phrasings, including informal English")
# ===========================================================================
expect("My AC is leaking water and isn't cooling", "AC Technician")
expect("kitchen sink blocked water not going down", "Plumber")
expect("my ac not cooling properly", "AC Technician")
expect("fridge is not cooling at all", "Appliance Repair")
expect("the tap in the bathroom keeps dripping", "Plumber")
expect("need an electrician for socket work", "Electrician")
expect("my cupboard door hinge is broken", "Carpenter")
expect("i am locked out, key broke in the lock", "Locksmith")
expect("want to repaint my lounge walls", "Painter")
expect("need deep cleaning before guests come", "Home Cleaner")
expect("microwave stopped working yesterday", "Appliance Repair")
expect("geyser is not heating the water", "Plumber")

# ===========================================================================
print("\n[3] Disambiguation - the device beats the symptom")
# ===========================================================================
# These are the cases a flat keyword count gets wrong. "leaking" and "water"
# are Plumber words, but the thing that is leaking decides the trade.
expect("my washing machine is leaking water everywhere", "Appliance Repair")
expect("the AC is dripping water onto the floor", "AC Technician")
expect("water is leaking from the fridge", "Appliance Repair")
expect("the pipe under the sink is leaking water", "Plumber")

r = classifier.classify("my door lock is broken")
check("'door lock' outscores 'door'", r["category"] == "Locksmith",
      str(r["scores"]))
check("Carpenter still scores on 'door'", "Carpenter" in r["scores"])

# word boundaries
r = classifier.classify("I need someone to paint my bedroom")
check("'bed' does not match inside 'bedroom'",
      "Carpenter" not in r["scores"] or r["category"] == "Painter",
      str(r["scores"]))
check("'carpet cleaning' is not routed to Carpenter",
      classifier.classify("I need carpet cleaning")["category"] == "Home Cleaner")

# ===========================================================================
print("\n[4] Refusing to guess")
# ===========================================================================
for text in ["something is wrong at home", "hello", "I need help",
             "can you help me please", "it is broken"]:
    r = classifier.classify(text)
    check(f"{text[:40]!r} -> no guess", r["category"] is None,
          f"got {r['category']}")

for value in ["", "   ", None]:
    r = classifier.classify(value)
    check(f"{value!r} handled safely", r["category"] is None and r["score"] == 0)

r = classifier.classify("water")
check("a single weak keyword is below the threshold",
      r["category"] is None and r["score"] < classifier.MIN_SCORE,
      f"score {r['score']}")

# ===========================================================================
print("\n[5] Ambiguity detection")
# ===========================================================================
r = classifier.classify("the light above my kitchen sink is not working")
check("competing anchors flagged as ambiguous", r["ambiguous"] is True,
      str(r["scores"]))
check("ambiguous result has no category", r["category"] is None)
check("ambiguous result names a runner-up", r["runner_up"] is not None)
q = classifier.clarifying_question(r)
check("ambiguity produces an either/or question", q is not None and " or " in q, str(q))
check("question stays short", len(q) < 160, str(len(q or "")))

r_clear = classifier.classify("my kitchen sink is blocked")
check("a clear winner is not flagged ambiguous", r_clear["ambiguous"] is False)
check("a clear winner needs no question",
      classifier.clarifying_question(r_clear) is None)

q_empty = classifier.clarifying_question(classifier.classify("hello"))
check("an unresolved result asks an open question",
      q_empty is not None and "describe" in q_empty.lower())

# ===========================================================================
print("\n[6] Scoring internals")
# ===========================================================================
r = classifier.classify("my washing machine is making a strange noise")
check("winner exposes its matched terms", len(r["matched"]) > 0)
check("reason is human-readable", "\u2192" in r["reason"] or "score" in r["reason"])
check("full score table is returned", isinstance(r["scores"], dict))
check("confidence is capped below 1",
      all(classifier.classify(t)["confidence"] <= classifier.CONFIDENCE_CAP
          for t in ["my door lock is broken", "deep cleaning of my house"]))
check("higher score means higher confidence",
      classifier.classify("my door lock is broken")["confidence"]
      >= classifier.classify("my pipe is leaking")["confidence"])
check("anchors weigh more than keywords",
      classifier.ANCHOR_WEIGHT > classifier.KEYWORD_WEIGHT)

top = classifier.suggest_categories("the light above my kitchen sink", 2)
check("suggest_categories returns pairs",
      len(top) == 2 and isinstance(top[0], tuple) and isinstance(top[0][1], int))
check("suggestions are sorted by score", top[0][1] >= top[1][1])
check("suggest_categories on junk is empty",
      classifier.suggest_categories("zzz qqq") == [])

# ===========================================================================
print("\n[7] validate_category")
# ===========================================================================
check("exact category -> llm",
      classifier.validate_category("Plumber", "") == ("Plumber", "llm"))
check("whitespace tolerated",
      classifier.validate_category("  Electrician  ", "") == ("Electrician", "llm"))
check("case insensitive",
      classifier.validate_category("ac technician", "") == ("AC Technician", "llm"))

aliases = {"Plumbing": "Plumber", "Electrical": "Electrician",
           "HVAC": "AC Technician", "Cleaning": "Home Cleaner",
           "Painting": "Painter", "Carpentry": "Carpenter",
           "Appliance": "Appliance Repair", "Lock repair": "Locksmith"}
for raw, expected in aliases.items():
    got, method = classifier.validate_category(raw, "")
    check(f"alias {raw!r} -> {expected}", got == expected and method == "llm",
          f"got {got}/{method}")

got, method = classifier.validate_category("Pipe Guy", "my kitchen sink is blocked")
check("invented category falls back to keywords",
      got == "Plumber" and method == "keyword_fallback", f"{got}/{method}")

got, method = classifier.validate_category(None, "my AC is not cooling")
check("null category falls back to keywords",
      got == "AC Technician" and method == "keyword_fallback")

got, method = classifier.validate_category("Pipe Guy", "hello there")
check("unresolvable returns None/unresolved",
      got is None and method == "unresolved", f"{got}/{method}")

check("'Carpet cleaning' is not mistaken for Carpenter",
      classifier.validate_category("Carpet cleaning", "I need carpet cleaning")[0]
      == "Home Cleaner")

# ===========================================================================
print("\n[8] resolve() - integration with the slot dict")
# ===========================================================================
base = ai.empty_slots()

s = classifier.resolve({**base, "service_category": "Plumber", "ai_used": True},
                       "my sink is blocked")
check("valid LLM category is kept", s["service_category"] == "Plumber")
check("source recorded as llm", s["category_source"] == "llm")
check("fallback flag cleared", s["needs_keyword_fallback"] is False)

s = classifier.resolve({**base, "service_category": "Pipe Guy", "ai_used": True},
                       "my kitchen sink is blocked")
check("hallucinated category is corrected", s["service_category"] == "Plumber")
check("source recorded as keyword_fallback",
      s["category_source"] == "keyword_fallback")

s = classifier.resolve({**base, "service_category": None, "ai_used": False,
                        "needs_keyword_fallback": True},
                       "my AC is leaking water and not cooling")
check("offline slots get a category", s["service_category"] == "AC Technician")
check("offline confidence comes from keywords", 0 < s["confidence"] <= classifier.CONFIDENCE_CAP)
check("offline fallback flag cleared", s["needs_keyword_fallback"] is False)

s = classifier.resolve({**base, "service_category": "Plumber",
                        "category_source": "safety_hint"}, "gas leak in kitchen")
check("safety hint is left alone", s["service_category"] == "Plumber")
check("safety hint keeps its source", s["category_source"] == "safety_hint")

s = classifier.resolve({**base, "service_category": None, "ai_used": False},
                       "hello there")
check("unresolvable leaves category null", s["service_category"] is None)
check("unresolvable flags the fallback", s["needs_keyword_fallback"] is True)
check("unresolvable sets a follow-up question", bool(s["follow_up_question"]))
check("offline unresolvable uses the question as the reply",
      s["reply"] == s["follow_up_question"])

s = classifier.resolve({**base, "service_category": None, "ai_used": False},
                       "the light above my kitchen sink is not working")
check("ambiguous result is flagged", s["ambiguous"] is True)
check("ambiguous result offers choices",
      len(s.get("suggested_categories", [])) == 2, str(s.get("suggested_categories")))

check("resolve adds a human-readable reason", bool(s["classifier_reason"]))
check("resolve exposes the score table", isinstance(s["classifier_scores"], dict))
check("resolve handles an empty dict", isinstance(classifier.resolve({}, "hi"), dict))
check("resolve handles None", isinstance(classifier.resolve(None, "hi"), dict))
check("resolve uses problem_summary when no text is passed",
      classifier.resolve({**base, "problem_summary": "my pipe is leaking"},
                         "")["service_category"] == "Plumber")

# ===========================================================================
print("\n[9] The category is ALWAYS valid or None")
# ===========================================================================
junk = ["'; DROP TABLE providers; --", "<script>alert(1)</script>", "\U0001F600" * 20,
        "x" * 3000, "Plumber Electrician Carpenter Painter", "12345",
        "null", "undefined", "{}", "AC AC AC AC AC"]
for text in junk:
    r = classifier.classify(text)
    ok = r["category"] is None or r["category"] in config.SERVICE_CATEGORIES
    check(f"junk input yields a valid category or None: {text[:22]!r}", ok,
          str(r["category"]))
    s = classifier.resolve({**base, "service_category": text}, text)
    ok2 = s["service_category"] is None or s["service_category"] in config.SERVICE_CATEGORIES
    check(f"resolve is safe on: {text[:22]!r}", ok2, str(s["service_category"]))

# ===========================================================================
print("\n[10] End-to-end - the Stage 5 gap is now closed")
# ===========================================================================
class DeadClient:
    """Every call fails, simulating no network or an expired key."""
    def __init__(self):
        outer = self

        class _C:
            def create(self, **kwargs):
                raise RuntimeError("connection refused")

        self.chat = SimpleNamespace(completions=_C())


slots = ai.extract_request_info("My AC is leaking water and isn't cooling",
                                client=DeadClient())
check("Groq down -> ai_used False", slots["ai_used"] is False)
check("Groq down -> category unknown before the classifier",
      slots["service_category"] is None)
check("Groq down -> fallback flag raised", slots["needs_keyword_fallback"] is True)

resolved = classifier.resolve(slots, "My AC is leaking water and isn't cooling")
check("classifier rescues the category offline",
      resolved["service_category"] == "AC Technician")
check("rescue is honestly labelled",
      resolved["category_source"] == "keyword_fallback")
check("the app still has something to show the user",
      len(resolved["reply"]) > 20)

# and the same pipeline with a working model
class OkClient:
    def __init__(self, payload):
        outer = self

        class _C:
            def create(self, **kwargs):
                msg = SimpleNamespace(content=json.dumps(payload))
                return SimpleNamespace(choices=[SimpleNamespace(message=msg)])

        self.chat = SimpleNamespace(completions=_C())


good = ai.extract_request_info(
    "My kitchen sink is blocked",
    client=OkClient({"service_category": "Plumber", "reply": "I can help.",
                     "urgency": "normal", "confidence": 0.9}))
resolved_good = classifier.resolve(good, "My kitchen sink is blocked")
check("online path keeps the LLM category",
      resolved_good["service_category"] == "Plumber")
check("online path is labelled llm", resolved_good["category_source"] == "llm")

# ===========================================================================
print(f"\n{'=' * 46}")
print(f"  {PASSED} passed, {FAILED} failed")
print(f"{'=' * 46}\n")
sys.exit(1 if FAILED else 0)
