"""
src/database.py
===============
The ONLY module in the project that touches the CSV files.

Every other module asks this one for data. That single rule buys us a lot:
file paths, missing-file recovery, column ordering and atomic writes are all
handled in one place, and no other module has to know whether the backing
store is CSV, SQLite or Postgres. Swapping in SQLite later (a listed future
improvement) means rewriting this file and nothing else.

Contract for the whole module: NO FUNCTION HERE RAISES.
Readers return an empty DataFrame with correct columns on failure.
Writers return a (ok, value, error) tuple. app.py branches on that tuple and
shows a friendly message -- requirement N.

Public API:
    load_providers()                -> DataFrame
    load_services()                 -> DataFrame
    load_requests()                 -> DataFrame
    get_provider(provider_id)       -> dict | None
    save_request(form)              -> (ok, request_id, error)
    update_request_status(rid, s)   -> (ok, error)
    get_request(request_id)         -> dict | None
    data_health()                   -> dict

Imports from: config.py, utils.py
Used by: provider_matching.py, classifier.py, analytics.py, app.py
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pandas as pd

from . import config, utils

# ---------------------------------------------------------------------------
# In-memory cache
# ---------------------------------------------------------------------------
# providers.csv and services.csv are read-only reference data, so we read them
# from disk once and reuse. requests.csv is NEVER cached -- the dashboard has
# to show a booking the moment it is saved.

_cache: dict[str, pd.DataFrame] = {}


def clear_cache() -> None:
    """Call after editing providers.csv by hand, or from a Refresh button."""
    _cache.clear()


def _empty(columns: list[str]) -> pd.DataFrame:
    return pd.DataFrame(columns=columns)


def _read_csv(path: Path, columns: list[str] | None = None) -> tuple[pd.DataFrame, str]:
    """Read a CSV defensively. Returns (dataframe, error_message)."""
    if not path.exists():
        return _empty(columns or []), f"{path.name} not found. Run generate_data.py first."
    try:
        df = pd.read_csv(path)
    except pd.errors.EmptyDataError:
        return _empty(columns or []), f"{path.name} is empty."
    except Exception as exc:  # malformed rows, encoding problems, locked file
        return _empty(columns or []), f"Could not read {path.name}: {exc}"

    if columns:
        missing = [c for c in columns if c not in df.columns]
        if missing:
            return _empty(columns), f"{path.name} is missing columns: {missing}"
        df = df[columns]
    return df, ""


# ===========================================================================
# READERS
# ===========================================================================

def load_providers(use_cache: bool = True) -> pd.DataFrame:
    """
    All 32 demo providers, with two derived columns added:

        estimated_price -> utils.estimate_price(price_min, price_max)
        region          -> from config.AREA_REGIONS

    Derived here rather than stored in the CSV so there is one formula, and
    so the region grouping can change without regenerating the dataset.
    """
    if use_cache and "providers" in _cache:
        return _cache["providers"].copy()

    df, error = _read_csv(config.PROVIDERS_CSV, config.PROVIDER_PUBLIC_COLUMNS + ["phone"])
    if error:
        print(f"[database] {error}")
        return df

    df["rating"] = pd.to_numeric(df["rating"], errors="coerce").fillna(0.0)
    for col in ("price_min", "price_max", "experience_years"):
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)

    df["estimated_price"] = df.apply(
        lambda r: utils.estimate_price(r["price_min"], r["price_max"]), axis=1
    )
    df["region"] = df["area"].map(config.AREA_REGIONS).fillna("Unknown")

    _cache["providers"] = df.copy()
    return df


def load_services(use_cache: bool = True) -> pd.DataFrame:
    """The 8 canonical categories. classifier.py reads the keywords column."""
    if use_cache and "services" in _cache:
        return _cache["services"].copy()

    df, error = _read_csv(config.SERVICES_CSV)
    if error:
        print(f"[database] {error}")
        return df

    _cache["services"] = df.copy()
    return df


def load_requests() -> pd.DataFrame:
    """
    Every booking. Auto-creates the file with correct headers if missing, so
    a fresh clone of the repo works without running the generator first.

    Never cached: the Dashboard and Analytics tabs must see a new booking
    immediately after it is saved.
    """
    if not config.REQUESTS_CSV.exists():
        config.ensure_dirs()
        _empty(config.REQUEST_COLUMNS).to_csv(config.REQUESTS_CSV, index=False)

    df, error = _read_csv(config.REQUESTS_CSV, config.REQUEST_COLUMNS)
    if error:
        print(f"[database] {error}")
        return df

    df["estimated_price"] = pd.to_numeric(
        df["estimated_price"], errors="coerce"
    ).fillna(0).astype(int)
    df["status"] = df["status"].where(
        df["status"].isin(config.REQUEST_STATUSES), config.DEFAULT_STATUS
    )
    return df


def get_provider(provider_id: str) -> dict | None:
    """One provider as a plain dict, or None. Used when a card is selected."""
    if not provider_id:
        return None
    df = load_providers()
    if df.empty:
        return None
    match = df[df["provider_id"] == str(provider_id).strip()]
    return None if match.empty else match.iloc[0].to_dict()


def get_provider_by_name(name: str) -> dict | None:
    """
    Look up by display name. Needed because Gradio's gr.Radio gives us the
    provider NAME the user clicked, not the ID (see the roadmap note about
    Gradio not supporting buttons inside generated HTML).
    """
    if not name:
        return None
    df = load_providers()
    if df.empty:
        return None
    match = df[df["provider_name"].str.strip() == str(name).strip()]
    return None if match.empty else match.iloc[0].to_dict()


def get_request(request_id: str) -> dict | None:
    df = load_requests()
    if df.empty:
        return None
    match = df[df["request_id"] == str(request_id).strip()]
    return None if match.empty else match.iloc[0].to_dict()


# ===========================================================================
# WRITERS
# ===========================================================================

def _atomic_write(df: pd.DataFrame, path: Path) -> None:
    """
    Write to a temp file in the same directory, then os.replace() it.

    Why bother: Colab sessions get interrupted, and a half-written CSV loses
    every booking in the file, not just the new one. os.replace is atomic on
    both Linux and Windows.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    os.close(fd)
    try:
        df.to_csv(tmp, index=False)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def save_request(form: dict) -> tuple[bool, str | None, str]:
    """
    Validate and append one booking.

    Returns (ok, request_id, error_message):
        (True,  "HFX-20260912-A3F1", "")
        (False, None, "Please fix the following: ...")

    Order of operations matters:
      1. utils.validate_booking_form  -- field-level rules (no I/O)
      2. provider existence check     -- needs the dataset, so it lives here
      3. build the row in config.REQUEST_COLUMNS order
      4. collision-check the generated ID
      5. atomic append
    """
    try:
        errors = utils.validate_booking_form(form)

        provider = get_provider(form.get("provider_id"))
        if not provider:
            errors["provider_id"] = "That provider could not be found. Please select again."
        elif not errors.get("service_category") and provider["service_category"] != form.get("service_category"):
            # guards against a stale selection after the user changes problem
            errors["provider_id"] = (
                f"{provider['provider_name']} does not offer "
                f"{form.get('service_category')}. Please select again."
            )

        if errors:
            return False, None, utils.format_errors(errors)

        existing = load_requests()
        request_id = utils.generate_request_id()
        used = set(existing["request_id"]) if not existing.empty else set()
        while request_id in used:                       # astronomically unlikely
            request_id = utils.generate_request_id()

        row = {
            "request_id": request_id,
            "created_at": utils.now_string(),
            "customer_name": utils.clean_text(form.get("customer_name"), 100),
            "phone": utils.clean_text(form.get("phone"), 20),
            "area": utils.clean_text(form.get("area"), 50),
            "address": utils.clean_text(form.get("address"), 200),
            "problem_description": utils.clean_text(form.get("problem_description"), 500),
            "service_category": form.get("service_category"),
            "provider_id": provider["provider_id"],
            "provider_name": provider["provider_name"],
            "preferred_date": utils.clean_text(form.get("preferred_date"), 10),
            "preferred_time": form.get("preferred_time"),
            "notes": utils.clean_text(form.get("notes"), 300),
            # recomputed from the dataset -- never trusted from the form,
            # and never invented by the LLM (requirement K)
            "estimated_price": utils.estimate_price(
                provider["price_min"], provider["price_max"]
            ),
            "urgency": utils.clean_text(form.get("urgency")) or "normal",
            "status": config.DEFAULT_STATUS,
        }

        updated = pd.concat(
            [existing, pd.DataFrame([row], columns=config.REQUEST_COLUMNS)],
            ignore_index=True,
        )[config.REQUEST_COLUMNS]

        _atomic_write(updated, config.REQUESTS_CSV)
        return True, request_id, ""

    except Exception as exc:
        return False, None, f"Could not save your request: {exc}"


def update_request_status(request_id: str, new_status: str) -> tuple[bool, str]:
    """Change one booking's status. Powers the demo status dropdown."""
    try:
        if new_status not in config.REQUEST_STATUSES:
            return False, f"Status must be one of: {', '.join(config.REQUEST_STATUSES)}"

        df = load_requests()
        if df.empty:
            return False, "There are no requests yet."

        mask = df["request_id"] == str(request_id).strip()
        if not mask.any():
            return False, f"Request {request_id} not found."

        df.loc[mask, "status"] = new_status
        _atomic_write(df[config.REQUEST_COLUMNS], config.REQUESTS_CSV)
        return True, ""
    except Exception as exc:
        return False, f"Could not update the status: {exc}"


# ===========================================================================
# HEALTH CHECK
# ===========================================================================

def data_health() -> dict:
    """
    One call that tells app.py everything it needs for the startup banner:
    which files are present, how many rows, and whether data will persist.
    """
    providers = load_providers()
    services = load_services()
    requests = load_requests()

    problems: list[str] = []
    if providers.empty:
        problems.append("providers.csv is missing or empty - run generate_data.py")
    if services.empty:
        problems.append("services.csv is missing or empty - run generate_data.py")
    if not providers.empty:
        uncovered = set(config.SERVICE_CATEGORIES) - set(providers["service_category"])
        if uncovered:
            problems.append(f"no providers for: {', '.join(sorted(uncovered))}")
    if config.DATA_IS_TEMPORARY:
        problems.append("Google Drive is not mounted - bookings will be lost on disconnect")

    return {
        "ok": not problems,
        "problems": problems,
        "providers": len(providers),
        "services": len(services),
        "requests": len(requests),
        "base_dir": str(config.BASE_DIR),
    }


# ===========================================================================
# Self-check: python -m src.database
# ===========================================================================
if __name__ == "__main__":
    health = data_health()
    print("base dir :", health["base_dir"])
    print("providers:", health["providers"])
    print("services :", health["services"])
    print("requests :", health["requests"])
    print("ok       :", health["ok"])
    for p in health["problems"]:
        print("  !", p)
