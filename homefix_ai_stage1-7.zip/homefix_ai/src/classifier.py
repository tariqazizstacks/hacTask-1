"""
src/classifier.py
=================
Maps a customer's words to exactly one of the 8 controlled service
categories -- and refuses to guess when it cannot.

Two jobs:

  1. VALIDATE what the LLM produced. A model that returns "Pipe Guy" or
     "Plumbing Services" must not reach the matcher.

  2. CLASSIFY without the LLM. When Groq is unreachable, this module is the
     whole brain of the app. It scores the raw text against the keyword
     columns in services.csv and picks a winner, or asks a clarifying
     question if two categories are too close.

THE SCORING IDEA
----------------
Symptoms are ambiguous; objects are not.

    "my washing machine is leaking water"

"leaking" and "water" are Plumber words. "washing machine" is an Appliance
Repair word. A flat keyword count gets this wrong. So services.csv has two
keyword columns and they are weighted very differently:

    anchor_keywords  the DEVICE or THING       weight 10 per word
    keywords         symptoms and context      weight  2 per word

Multi-word terms score higher because they are more specific: "door lock"
(20) beats "door" (10), which is how a Locksmith wins over a Carpenter.

Public API:
    classify(text)                      -> dict
    validate_category(raw, text)        -> (category, method)
    resolve(slots, text)                -> slots        <- main integration
    suggest_categories(text, n=3)       -> list[tuple]
    clarifying_question(result)         -> str | None

Imports from: config.py, database.py, utils.py
Used by: app.py (after ai_assistant.extract_request_info)
"""

from __future__ import annotations

import re

from . import config, database, utils

# ===========================================================================
# TUNING
# ===========================================================================
# All the magic numbers live here, named, so they can be explained and tuned
# in one place rather than hidden in the scoring loop.

ANCHOR_WEIGHT = 10      # per word of a matched device/object term
KEYWORD_WEIGHT = 2      # per word of a matched symptom/context term
MIN_SCORE = 8           # below this we say "I don't know" instead of guessing
AMBIGUITY_RATIO = 0.75  # runner-up >= 75% of the winner -> ask, don't guess
MAX_CONFIDENCE_SCORE = 30   # score at which keyword confidence reaches its cap
CONFIDENCE_CAP = 0.85       # keyword matching never claims more than this

_pattern_cache: dict[str, re.Pattern] = {}


def _pattern(term: str) -> re.Pattern:
    """
    Word-boundary matcher for one term, compiled once.

    Boundaries matter more than they look. Without \\b, "bed" matches
    "bedroom" and "I need someone to paint my bedroom" becomes a Carpenter
    job. That exact case is in the test suite.
    """
    if term not in _pattern_cache:
        _pattern_cache[term] = re.compile(
            r"\b" + r"\s+".join(re.escape(w) for w in term.split()) + r"\b",
            re.IGNORECASE,
        )
    return _pattern_cache[term]


def _terms(value) -> list[str]:
    if not isinstance(value, str):
        return []
    return [t.strip().lower() for t in value.split(",") if t.strip()]


def clear_cache() -> None:
    _pattern_cache.clear()


# ===========================================================================
# SCORING
# ===========================================================================

def score_categories(text: str) -> dict[str, dict]:
    """
    Score every category against the text.

    Returns {category: {"score": int, "anchors": [...], "keywords": [...]}}
    The matched term lists are kept so the UI can show WHY a category won --
    a black-box classifier is much harder to defend in a viva.
    """
    clean = utils.clean_text(text, 1000).lower()
    services = database.load_services()
    results: dict[str, dict] = {}

    if clean == "" or services.empty:
        return results

    for _, row in services.iterrows():
        category = row["service_category"]
        if category not in config.SERVICE_CATEGORIES:
            continue

        score = 0
        hit_anchors: list[str] = []
        hit_keywords: list[str] = []

        for term in _terms(row.get("anchor_keywords")):
            if _pattern(term).search(clean):
                score += ANCHOR_WEIGHT * len(term.split())
                hit_anchors.append(term)

        for term in _terms(row.get("keywords")):
            if term in hit_anchors:          # don't pay twice for one word
                continue
            if _pattern(term).search(clean):
                score += KEYWORD_WEIGHT * len(term.split())
                hit_keywords.append(term)

        if score:
            results[category] = {
                "score": score,
                "anchors": hit_anchors,
                "keywords": hit_keywords,
            }
    return results


def _confidence(score: int) -> float:
    """
    Map a raw score to 0..CONFIDENCE_CAP.

    Capped below 1.0 deliberately: keyword matching is a fallback, and it
    should never present itself as more certain than the language model.
    """
    if score <= 0:
        return 0.0
    return round(min(score / MAX_CONFIDENCE_SCORE, 1.0) * CONFIDENCE_CAP, 2)


def classify(text: str) -> dict:
    """
    Keyword-only classification. Never raises, never invents a category.

    Returns:
        category    the winner, or None
        score       raw score of the winner
        confidence  0..0.85
        runner_up   (category, score) or None
        ambiguous   True when the top two are too close to separate
        matched     the terms that won it
        scores      the full table, for debugging and the UI
    """
    result = {
        "category": None,
        "score": 0,
        "confidence": 0.0,
        "runner_up": None,
        "ambiguous": False,
        "matched": [],
        "scores": {},
        "reason": "no recognisable service words found",
    }

    scores = score_categories(text)
    result["scores"] = {k: v["score"] for k, v in scores.items()}
    if not scores:
        return result

    ranked = sorted(scores.items(), key=lambda kv: kv[1]["score"], reverse=True)
    top_name, top = ranked[0]
    second = ranked[1] if len(ranked) > 1 else None

    result["score"] = top["score"]
    result["matched"] = top["anchors"] + top["keywords"]
    if second:
        result["runner_up"] = (second[0], second[1]["score"])

    # too weak to act on
    if top["score"] < MIN_SCORE:
        result["reason"] = (
            f"best match '{top_name}' scored {top['score']}, "
            f"below the minimum of {MIN_SCORE}"
        )
        return result

    # too close to call
    if second and second[1]["score"] >= top["score"] * AMBIGUITY_RATIO:
        result["ambiguous"] = True
        result["reason"] = (
            f"'{top_name}' ({top['score']}) and '{second[0]}' "
            f"({second[1]['score']}) are too close to separate"
        )
        return result

    result["category"] = top_name
    result["confidence"] = _confidence(top["score"])
    result["reason"] = (
        f"matched {', '.join(result['matched'][:4])} \u2192 {top_name} "
        f"(score {top['score']})"
    )
    return result


def suggest_categories(text: str, n: int = 3) -> list[tuple[str, int]]:
    """Top N scoring categories. Feeds the 'did you mean?' dropdown."""
    scores = score_categories(text)
    ranked = sorted(scores.items(), key=lambda kv: kv[1]["score"], reverse=True)
    return [(name, data["score"]) for name, data in ranked[:n]]


# ===========================================================================
# VALIDATION
# ===========================================================================

# Shapes a language model actually produces instead of our exact strings.
# An explicit map rather than fuzzy prefix matching: "Carpet cleaning" and
# "Carpenter" share their first five letters, so a prefix rule would route
# a sofa-shampoo job to a carpenter. Explicit is safer and easier to defend.
CATEGORY_ALIASES = {
    "plumbing": "Plumber", "plumber": "Plumber", "pipe fitter": "Plumber",
    "plumbing services": "Plumber", "water works": "Plumber",
    "electrical": "Electrician", "electric": "Electrician",
    "electrical work": "Electrician", "electrical services": "Electrician",
    "ac": "AC Technician", "ac repair": "AC Technician",
    "ac technician": "AC Technician", "hvac": "AC Technician",
    "air conditioning": "AC Technician", "air conditioner repair": "AC Technician",
    "appliance": "Appliance Repair", "appliance repair": "Appliance Repair",
    "electronics repair": "Appliance Repair", "home appliance": "Appliance Repair",
    "cleaning": "Home Cleaner", "cleaner": "Home Cleaner",
    "house cleaning": "Home Cleaner", "home cleaning": "Home Cleaner",
    "maid service": "Home Cleaner", "housekeeping": "Home Cleaner",
    "painting": "Painter", "painter": "Painter", "wall painting": "Painter",
    "carpentry": "Carpenter", "carpenter": "Carpenter", "woodwork": "Carpenter",
    "furniture repair": "Carpenter",
    "locksmith": "Locksmith", "lock repair": "Locksmith", "key maker": "Locksmith",
}


def validate_category(raw, text: str = "") -> tuple[str | None, str]:
    """
    The contract from the roadmap: (category, method).

        ("Plumber", "llm")               the model gave a valid category
        ("Plumber", "keyword_fallback")  the model was wrong; keywords rescued it
        (None, "unresolved")             neither could decide

    Known aliases are recovered before falling back. Anything unrecognised is
    discarded rather than trusted -- we would rather fall through to keyword
    scoring on the user's own words than accept an invented category.
    """
    candidate = utils.clean_text(raw, 60)

    if candidate in config.SERVICE_CATEGORIES:
        return candidate, "llm"

    lowered = candidate.lower().strip(" .-")
    if lowered:
        exact = next((c for c in config.SERVICE_CATEGORIES if c.lower() == lowered), None)
        if exact:
            return exact, "llm"
        if lowered in CATEGORY_ALIASES:
            return CATEGORY_ALIASES[lowered], "llm"

    result = classify(text)
    if result["category"]:
        return result["category"], "keyword_fallback"
    return None, "unresolved"


# ===========================================================================
# CLARIFYING QUESTIONS
# ===========================================================================

def clarifying_question(result: dict) -> str | None:
    """
    Ask, rather than guess. Requirement B: short, and only when it matters.

    Two shapes, because the two failure modes are different: an ambiguous
    result needs an either/or, an empty result needs an open question.
    """
    if not result:
        return None

    if result.get("ambiguous") and result.get("runner_up"):
        winner = max(result["scores"], key=result["scores"].get)
        other = result["runner_up"][0]
        return (
            f"I want to send the right person \u2014 is this more of a "
            f"{winner.lower()} job or a {other.lower()} job?"
        )

    if not result.get("category"):
        return (
            "I could not tell which service you need. Could you describe what "
            "is wrong and which item it affects \u2014 for example \"the tap in "
            "the kitchen is leaking\"?"
        )
    return None


# ===========================================================================
# INTEGRATION -- the function app.py actually calls
# ===========================================================================

def resolve(slots: dict, text: str = "") -> dict:
    """
    Take the slot dict from ai_assistant and guarantee the category is either
    valid or honestly null.

    This closes the gap left at the end of Stage 5: when Groq is unreachable,
    `needs_keyword_fallback` is True and nothing had acted on it. Now keyword
    classification fills in, the app keeps working with no API key, and
    `category_source` records which path was taken so the UI can be honest
    about it.

    Never raises. Always returns a dict with a valid or null category.
    """
    slots = dict(slots or {})
    probe = utils.clean_text(text) or slots.get("problem_summary") or ""

    # a category set by the safety guard is already trustworthy
    if slots.get("category_source") == "safety_hint" and slots.get("service_category"):
        slots["needs_keyword_fallback"] = False
        slots.setdefault("classifier_reason", "set by the safety keyword guard")
        return slots

    category, method = validate_category(slots.get("service_category"), probe)
    result = classify(probe)

    slots["service_category"] = category
    slots["classifier_scores"] = result["scores"]
    slots["classifier_reason"] = result["reason"]
    slots["ambiguous"] = bool(result["ambiguous"])

    if category:
        slots["category_source"] = method
        slots["needs_keyword_fallback"] = False
        # an offline classification carries the keyword confidence, since the
        # LLM confidence field is meaningless when the LLM never ran
        if method == "keyword_fallback" and not slots.get("ai_used"):
            slots["confidence"] = result["confidence"]
    else:
        slots["category_source"] = None
        slots["needs_keyword_fallback"] = True
        question = clarifying_question(result)
        if question:
            slots["follow_up_question"] = question
            # with no LLM reply to show, the question becomes the reply
            if not slots.get("ai_used") and not slots.get("reply"):
                slots["reply"] = question
        if result["ambiguous"]:
            slots["suggested_categories"] = [c for c, _ in suggest_categories(probe, 2)]

    return slots


# ===========================================================================
# Self-check: python -m src.classifier
# ===========================================================================
if __name__ == "__main__":
    samples = [
        "My pipe is leaking",
        "My lights keep going off",
        "My washing machine is making a strange noise",
        "My AC is leaking water",
        "I need someone to paint my bedroom",
        "My door lock is broken",
        "I need someone to clean my house",
        "My wooden table is broken",
        "my washing machine is leaking water everywhere",
        "something is wrong at home",
    ]
    width = max(len(s) for s in samples)
    for text in samples:
        r = classify(text)
        name = r["category"] or ("AMBIGUOUS" if r["ambiguous"] else "UNRESOLVED")
        print(f"{text:<{width}}  ->  {name:<18} "
              f"score {r['score']:>3}  conf {r['confidence']:.2f}")
