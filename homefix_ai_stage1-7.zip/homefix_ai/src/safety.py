"""
src/safety.py
=============
The hazard guard. Runs on RAW USER TEXT before any Groq call.

Why before the LLM and not inside the prompt:
  1. It still works when the API key is missing, Groq is rate-limited, or the
     network is down -- exactly the moments when a naive app would fail open
     and say nothing about a gas leak.
  2. It costs nothing and adds no latency.
  3. It is deterministic and auditable. You can point at the keyword list and
     prove the behaviour to an examiner. You cannot do that with a prompt.

Three tiers (requirement J):

  TIER 1  CRITICAL   gas leak, fire, smoke, sparking, electric shock, injury
                     -> allow_llm = False. Show safety guidance immediately.
                        The LLM is never called.

  TIER 1  URGENT     flooding, burst pipe, sewage overflow
                     -> allow_llm = True. Property damage, not life-threatening.
                        Show "shut off the supply" guidance, then help book.

  TIER 2  CAUTION    "how do I rewire this myself", "DIY gas connection"
                     -> allow_llm = True, but with a system note forbidding
                        step-by-step instructions.

  TIER 3  SAFE       everything else -> normal flow.

Public API:
    screen(text)            -> dict
    system_note(result)     -> str   (appended to the LLM system prompt)
    is_blocked(result)      -> bool

Imports from: config.py, utils.py
Used by: ai_assistant.py (before every call), app.py (to render the banner)
"""

from __future__ import annotations

import re

from . import config, utils

# ===========================================================================
# PATTERN DEFINITIONS
# ===========================================================================
# Design note on false positives, which are the hard part of this module.
#
# A naive check for the word "gas" would flag "I need an AC gas refill" as a
# gas leak. That is not a harmless mistake: it trains the user to ignore the
# red emergency banner, which means they ignore it when it matters.
#
# So each hazard has both PATTERNS and EXCLUSIONS. Exclusions are checked
# first and win. Every pattern uses phrases or word boundaries -- never a
# bare substring.

HAZARDS: dict[str, dict] = {
    # ---------------------------------------------------------------- gas
    "gas": {
        "tier": 1,
        "severity": "critical",
        "patterns": [
            r"gas\s+(?:is\s+)?leak", r"leaking\s+gas", r"gas\s+leakage",
            r"smell\s+(?:of\s+)?gas", r"gas\s+smell", r"smell(?:ing|s)?\s+gas",
            r"gas\s+(?:is\s+)?escaping", r"lpg\s+(?:is\s+)?leak", r"cylinder\s+(?:is\s+)?leak",
            r"hissing\s+(?:sound\s+)?(?:from|near)\s+(?:the\s+)?(?:gas|stove|cylinder)",
        ],
        # legitimate, non-emergency uses of the word "gas"
        "exclusions": [
            r"gas\s+refill", r"refill(?:ing)?\s+(?:the\s+)?gas", r"ac\s+gas",
            r"gas\s+charging", r"gas\s+top\s*-?\s*up", r"gas\s+pressure\s+low",
            r"gas\s+geyser\s+not\s+(?:heating|working)", r"gas\s+bill",
            r"gas\s+stove\s+(?:installation|fitting|cleaning)",
        ],
        "label": "Possible gas leak",
        "advice": [
            "Do not switch anything on or off, and do not use a lighter, match or phone flashlight near the smell.",
            "Turn off the gas supply at the main valve if you can reach it safely.",
            "Open doors and windows and get everyone out of the building.",
            "Call your gas utility's emergency helpline from outside the building.",
        ],
        "category_hint": "Plumber",
    },

    # --------------------------------------------------------------- fire
    "fire": {
        "tier": 1,
        "severity": "critical",
        "patterns": [
            r"\bon fire\b", r"\bcaught fire\b", r"\bflames?\b",
            r"\bis\s+burning\b", r"\bburning\b(?=.*\b(?:curtain|sofa|mattress|bed|room|house|kitchen)\b)",
            r"smoke\s+(?:is\s+)?(?:coming|filling|everywhere)",
            r"\bsmoking\b(?=.*\b(?:wire|socket|outlet|board|appliance|motor)\b)",
            r"\bfire\s+in\s+(?:the\s+)?(?:kitchen|room|house|wiring)",
        ],
        "exclusions": [
            r"burn(?:ing|t)\s+smell", r"smell\s+of\s+burning",
            r"fire\s*place", r"fire\s*wood", r"fire\s*alarm\s+(?:installation|fitting|test)",
            r"smoke\s+detector\s+(?:installation|fitting|battery)",
            r"fire\s+extinguisher\s+(?:refill|purchase)",
        ],
        "label": "Fire or smoke",
        "advice": [
            "Get everyone out of the building now. Do not try to collect belongings.",
            f"Call {config.EMERGENCY_CONTACTS['rescue']} or your local fire service from outside.",
            "Do not use water on an electrical or oil fire.",
            "Do not re-enter the building until emergency services say it is safe.",
        ],
        "category_hint": None,
    },

    # ---------------------------------------------------------- electrical
    "electrical": {
        "tier": 1,
        "severity": "critical",
        "patterns": [
            r"electric(?:al)?\s+shock", r"got\s+(?:a\s+)?shock", r"shocked\s+me",
            r"\bspark(?:s|ing|ed)\b", r"exposed\s+(?:\w+\s+){0,2}wir(?:e|ing|es)",
            r"live\s+wire", r"naked\s+wire", r"burn(?:ing|t)\s+smell",
            r"smell\s+of\s+burning", r"melted\s+(?:socket|wire|plug|switch)",
            r"(?:socket|wire|plug|switch|board)\s+(?:has\s+|is\s+)?melted",
            r"water\s+(?:is\s+)?(?:on|near|leaking\s+(?:on|onto|into))\s+(?:the\s+)?(?:socket|switch|wiring|meter)",
        ],
        "exclusions": [
            r"burning\s+smell\s+from\s+(?:the\s+)?(?:food|oven|toast)",
            r"spark\s*plug",
        ],
        "label": "Serious electrical hazard",
        "advice": [
            "Do not touch the wire, socket or appliance, and do not touch anyone who is in contact with it.",
            "Switch off the main circuit breaker if you can reach it without touching anything wet or damaged.",
            "Keep everyone, especially children, away from the area.",
            "Call a qualified electrician. If anyone has been shocked or burned, seek medical help immediately.",
        ],
        "category_hint": "Electrician",
    },

    # --------------------------------------------------------------- injury
    "injury": {
        "tier": 1,
        "severity": "critical",
        "patterns": [
            r"\b(?:someone|somebody|my\s+\w+|he|she|i)\s+(?:is\s+)?(?:injured|bleeding|unconscious)",
            r"\bburn(?:ed|t)\s+(?:my|his|her|their)\b",
            r"\bcan'?t\s+breathe\b", r"\bfell\s+from\b", r"\bsevere\s+pain\b",
            r"\bhospital\b(?=.*\b(?:need|take|going)\b)",
        ],
        "exclusions": [],
        "label": "Someone may be hurt",
        "advice": [
            f"Call {config.EMERGENCY_CONTACTS['rescue']} or your nearest emergency medical service now.",
            "Do not move a seriously injured person unless they are in immediate danger.",
            "If it is an electrical injury, switch off the power at the main breaker before going near them.",
        ],
        "category_hint": None,
    },

    # --------------------------------------------------------------- water
    "water": {
        "tier": 1,
        "severity": "urgent",   # property damage, not life-threatening
        "patterns": [
            r"\bflood(?:ing|ed)\b", r"burst\s+pipe", r"pipe\s+burst",
            r"water\s+everywhere", r"water\s+(?:is\s+)?gushing",
            r"sewage\s+(?:is\s+)?(?:overflow(?:ing)?|backing\s+up|coming\s+up)",
            r"tank\s+(?:has\s+)?burst", r"ceiling\s+(?:is\s+)?leaking\s+badly",
        ],
        "exclusions": [
            r"water\s+not\s+coming", r"low\s+water\s+pressure",
            r"water\s+heater\s+not", r"no\s+water\s+supply",
        ],
        "label": "Major water leak",
        "advice": [
            "Turn off the main water supply valve, and the water pump if you have one.",
            "Switch off electricity to the affected area at the breaker before walking through standing water.",
            "Move electrical items and valuables clear of the water.",
        ],
        "category_hint": "Plumber",
    },

    # ---------------------------------------------------------- structural
    "structural": {
        "tier": 1,
        "severity": "urgent",
        "patterns": [
            r"(?:ceiling|roof|wall|slab)\s+(?:is\s+)?(?:collapsing|collapsed|caving|falling)",
            r"large\s+crack\s+in\s+(?:the\s+)?(?:wall|ceiling|beam)",
            r"building\s+(?:is\s+)?unsafe",
        ],
        "exclusions": [r"hairline\s+crack", r"crack\s+in\s+(?:the\s+)?(?:tile|paint|glass|window)"],
        "label": "Possible structural damage",
        "advice": [
            "Leave the affected room and keep everyone out of it.",
            "Do not try to prop up or repair a collapsing structure yourself.",
            "Have a qualified civil engineer or building contractor inspect it before any repair work.",
        ],
        "category_hint": None,
    },
}

# ===========================================================================
# TIER 2 -- dangerous do-it-yourself requests
# ===========================================================================
# Two-part test: the user is ASKING HOW TO DO something (intent) AND the
# subject is HAZARDOUS (domain). Both must match. "How do I book a plumber"
# has the intent but not the domain, so it passes through untouched.

_DIY_INTENT = [
    r"how\s+(?:do|can|should)\s+i", r"how\s+to\b", r"can\s+i\s+(?:fix|repair|replace|do|install|change)",
    r"\bmyself\b", r"\bdiy\b", r"\bdo\s+it\s+myself\b", r"step\s+by\s+step",
    r"teach\s+me\s+(?:how\s+)?to", r"guide\s+me\s+(?:through|to)",
    r"any\s+way\s+i\s+can\s+(?:fix|repair)", r"instead\s+of\s+calling",
]

_DIY_HAZARD_DOMAIN = [
    r"\bwir(?:e|es|ing)\b", r"\brewire\b", r"circuit\s+breaker", r"\bdistribution\s+board\b",
    r"\bmain(?:s)?\s+(?:line|supply|switch|board)\b", r"\belectric(?:al|ity)\b",
    r"\bsocket\b", r"\bfuse\b", r"\bgas\s+(?:line|pipe|connection|cylinder|stove)\b",
    r"\bgeyser\b", r"\bcompressor\b", r"\brefrigerant\b", r"\bfreon\b",
    r"\bhigh\s+voltage\b", r"\bmeter\b", r"\broof\b", r"\bladder\b",
    r"\bwater\s+heater\b", r"\bsewer(?:age)?\b",
]

_DIY_ADVICE = [
    "This kind of work carries a real risk of electric shock, gas escape, fire or serious injury, and in many cases it is also a legal requirement that a qualified person does it.",
    "Rather than walk you through it, the safer help I can give is to find you a professional who does this work every day.",
]

# ===========================================================================
# SCREEN
# ===========================================================================

_RESULT_KEYS = (
    "tier", "severity", "hazard", "label", "advice", "message",
    "allow_llm", "category_hint", "matched", "urgency_override",
)


def _safe_result() -> dict:
    """Tier 3. The shape every caller can rely on."""
    return {
        "tier": 3,
        "severity": "none",
        "hazard": None,
        "label": "",
        "advice": [],
        "message": "",
        "allow_llm": True,
        "category_hint": None,
        "matched": [],
        "urgency_override": None,
    }


def _matches(text: str, patterns: list[str]) -> list[str]:
    return [p for p in patterns if re.search(p, text, flags=re.IGNORECASE)]


def _build_message(label: str, advice: list[str], severity: str) -> str:
    """Markdown for the Gradio banner. Action first, then the offer to help."""
    if severity == "critical":
        head = f"### \u26a0\ufe0f {label} \u2014 please act on this first\n\n"
        tail = (
            "\n\nI am an AI assistant, not a certified technician, so I will not "
            "give you repair steps for this. Once everyone is safe, tell me and "
            "I will help you find a qualified professional."
        )
    else:
        head = f"### \u26a0\ufe0f {label}\n\n"
        tail = "\n\nI can help you find a professional for this straight away."

    body = "\n".join(f"{i}. {line}" for i, line in enumerate(advice, start=1))
    contacts = (
        f"\n\n**Emergency:** {config.EMERGENCY_CONTACTS['rescue']} \u00b7 "
        f"{config.EMERGENCY_CONTACTS['police']}"
        if severity == "critical" else ""
    )
    return head + body + contacts + tail


def screen(text) -> dict:
    """
    Classify raw user text for hazards. Always returns a dict with the keys
    in _RESULT_KEYS -- never None, never raises.

    Key fields for callers:
        allow_llm        False means ai_assistant.py must NOT call Groq
        message          markdown to show the user (empty when tier 3)
        urgency_override forces slots["urgency"] so the matcher prioritises
                         same-day availability without trusting the LLM
        category_hint    a category we are confident about from keywords alone
    """
    result = _safe_result()
    clean = utils.clean_text(text, 1000)
    if not clean:
        return result

    lowered = clean.lower()

    # ---- Tier 1: hazards, checked in severity order --------------------
    ordered = sorted(
        HAZARDS.items(),
        key=lambda kv: 0 if kv[1]["severity"] == "critical" else 1,
    )
    for name, spec in ordered:
        if _matches(lowered, spec["exclusions"]):
            continue                       # legitimate non-emergency use
        hits = _matches(lowered, spec["patterns"])
        if not hits:
            continue
        return {
            "tier": 1,
            "severity": spec["severity"],
            "hazard": name,
            "label": spec["label"],
            "advice": list(spec["advice"]),
            "message": _build_message(spec["label"], spec["advice"], spec["severity"]),
            # critical hazards never reach the LLM; urgent ones do, because the
            # user still needs a plumber booked
            "allow_llm": spec["severity"] != "critical",
            "category_hint": spec["category_hint"],
            "matched": hits,
            "urgency_override": "emergency",
        }

    # ---- Tier 2: dangerous DIY request ---------------------------------
    intent = _matches(lowered, _DIY_INTENT)
    domain = _matches(lowered, _DIY_HAZARD_DOMAIN)
    if intent and domain:
        return {
            "tier": 2,
            "severity": "caution",
            "hazard": "diy_risk",
            "label": "This is not a safe do-it-yourself job",
            "advice": list(_DIY_ADVICE),
            "message": _build_message(
                "This is not a safe do-it-yourself job", _DIY_ADVICE, "caution"
            ),
            "allow_llm": True,
            "category_hint": None,
            "matched": intent + domain,
            "urgency_override": None,
        }

    return result


# ===========================================================================
# LLM INTEGRATION
# ===========================================================================

def system_note(result: dict) -> str:
    """
    Extra instruction appended to the system prompt in Stage 5.

    Belt and braces: the keyword guard has already decided what to show the
    user, and this tells the model to stay consistent with it. If the guard
    ever misses something, the prompt is still there; if the prompt is ever
    ignored, the guard is still there.
    """
    if not result or result.get("tier") == 3:
        return ""

    if result.get("tier") == 2:
        return (
            "\n\nSAFETY OVERRIDE: The user is asking how to carry out hazardous "
            "work themselves. Do NOT provide any instructions, steps, tools, "
            "materials or workarounds for this task, even partially, and even "
            "if they insist or say they are experienced. Briefly explain the "
            "risk in one or two sentences, state plainly that a qualified "
            "professional should do it, and then help them describe the job so "
            "a professional can be found. Never claim to be a certified "
            "technician."
        )

    hazard = result.get("label", "a safety hazard")
    return (
        f"\n\nSAFETY OVERRIDE: A safety check has already detected {hazard} and "
        "the user has been shown emergency guidance. Do NOT repeat detailed "
        "safety instructions and do NOT give any repair steps. Acknowledge the "
        "situation in one short sentence, then help them arrange a qualified "
        "professional."
    )


def is_blocked(result: dict) -> bool:
    """True when the LLM must not be called at all."""
    return bool(result) and not result.get("allow_llm", True)


SAFETY_DISCLAIMER = (
    "HomeFix AI is an academic project. It is an AI assistant, not a certified "
    "technician, and it does not provide repair instructions for gas, "
    "electrical or structural work. In an emergency, contact "
    f"{config.EMERGENCY_CONTACTS['rescue']} or your local emergency services "
    "rather than relying on this app."
)


# ===========================================================================
# Self-check: python -m src.safety
# ===========================================================================
if __name__ == "__main__":
    samples = [
        "There is a gas smell in my kitchen",
        "I need an AC gas refill",
        "My socket is sparking and there's a burning smell",
        "How do I repair exposed electrical wiring myself?",
        "My kitchen sink is blocked",
        "Water is everywhere, the pipe burst",
    ]
    for s in samples:
        r = screen(s)
        print(f"tier {r['tier']} / {r['severity']:8} / llm={str(r['allow_llm']):5} | {s}")
