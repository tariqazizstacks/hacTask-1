"""
src/config.py
=============
Single source of truth for the whole HomeFix AI application.

Every other module imports from here. Nothing in this file imports from
another project module, so there can never be a circular import.

Responsibilities:
  1. Work out WHERE the project lives (Colab+Drive / Colab / local VS Code)
  2. Hold the CONTROLLED VOCABULARY (the 8 service categories, areas, statuses)
  3. Hold the SCORING WEIGHTS used by provider_matching.py
  4. Hold the Groq model settings
  5. Load the API key safely (Colab Secrets -> .env -> environment variable)

Used by: every file in src/ and by app.py
"""

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# 1. PATHS
# ---------------------------------------------------------------------------
# The same code must run in three places, so we detect the environment
# instead of hardcoding a path. Every other module uses these constants --
# if you ever see a hardcoded path elsewhere in the project, it's a bug.

def _detect_base_dir() -> Path:
    # (a) Explicit override always wins. Useful for testing.
    override = os.getenv("HOMEFIX_BASE_DIR")
    if override:
        return Path(override)

    # (b) Colab with Google Drive mounted -> data survives the session ending
    drive_root = Path("/content/drive/MyDrive")
    if drive_root.exists():
        return drive_root / "homefix_ai"

    # (c) Colab without Drive -> works, but files are lost on disconnect
    if Path("/content").exists():
        return Path("/content/homefix_ai")

    # (d) Local VS Code -> the folder that contains src/
    return Path(__file__).resolve().parent.parent


BASE_DIR = _detect_base_dir()
DATA_DIR = BASE_DIR / "data"
KB_DIR = BASE_DIR / "knowledge_base"
CACHE_DIR = BASE_DIR / "cache"
ASSETS_DIR = BASE_DIR / "assets"

PROVIDERS_CSV = DATA_DIR / "providers.csv"
SERVICES_CSV = DATA_DIR / "services.csv"
REQUESTS_CSV = DATA_DIR / "requests.csv"
EMBEDDINGS_CACHE = CACHE_DIR / "kb_embeddings.npy"
CHUNKS_CACHE = CACHE_DIR / "kb_chunks.json"

# True when Drive is NOT in the path while running on Colab -> warn the user
DATA_IS_TEMPORARY = str(BASE_DIR).startswith("/content") and "drive" not in str(BASE_DIR)


def ensure_dirs() -> None:
    """Create every folder the app writes to. Safe to call repeatedly."""
    for d in (DATA_DIR, KB_DIR, CACHE_DIR, ASSETS_DIR):
        d.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# 2. CONTROLLED VOCABULARY
# ---------------------------------------------------------------------------
# This is the guardrail that stops the LLM inventing service types.
# classifier.py validates every LLM output against SERVICE_CATEGORIES.

SERVICE_CATEGORIES = [
    "AC Technician",
    "Plumber",
    "Electrician",
    "Appliance Repair",
    "Home Cleaner",
    "Painter",
    "Carpenter",
    "Locksmith",
]

# Areas are grouped into regions so provider_matching.py can award partial
# credit for a nearby provider instead of returning an empty result set.
AREA_REGIONS = {
    "Islamabad": "North",
    "Rawalpindi": "North",
    "Lahore": "Central",
    "Faisalabad": "Central",
    "Karachi": "South",
    "Hyderabad": "South",
}
AREAS = list(AREA_REGIONS.keys())

AVAILABILITY_OPTIONS = ["Today", "Tomorrow", "Within 3 Days", "Weekends Only"]
URGENCY_LEVELS = ["emergency", "urgent", "normal"]
REQUEST_STATUSES = ["Pending", "Confirmed", "Completed", "Cancelled"]
DEFAULT_STATUS = "Pending"

TIME_SLOTS = [
    "Morning (9 AM - 12 PM)",
    "Afternoon (12 PM - 4 PM)",
    "Evening (4 PM - 8 PM)",
]

# The exact column order of data/requests.csv. Defined ONCE, here, because
# three separate pieces of code have to agree on it: generate_data.py writes
# the seed file, database.py appends to it, and analytics.py reads it. If this
# list and the CSV ever disagree, bookings silently land in the wrong columns.
REQUEST_COLUMNS = [
    "request_id", "created_at", "customer_name", "phone", "area", "address",
    "problem_description", "service_category", "provider_id", "provider_name",
    "preferred_date", "preferred_time", "notes", "estimated_price",
    "urgency", "status",
]

# Columns a provider card is allowed to display. `phone` is deliberately
# absent -- it is only revealed after a booking is confirmed (requirement F).
PROVIDER_PUBLIC_COLUMNS = [
    "provider_id", "provider_name", "service_category", "area", "rating",
    "price_min", "price_max", "availability", "experience_years", "description",
]

# ---------------------------------------------------------------------------
# 3b. EMERGENCY CONTACTS (used by safety.py)
# ---------------------------------------------------------------------------
# VERIFY THESE BEFORE YOUR DEMO. Helpline numbers vary by province and change
# over time, and a wrong emergency number in a safety message is worse than no
# number at all. Rescue 1122 and Police 15 are nationally recognised in
# Pakistan; the gas and electricity entries are left as labels on purpose --
# fill in your own utility's published helpline, or leave them as guidance.
EMERGENCY_CONTACTS = {
    "rescue": "Rescue 1122",
    "police": "Police 15",
    "gas_utility": "your gas utility's emergency helpline (printed on your gas bill)",
    "power_utility": "your electricity provider's fault helpline (printed on your bill)",
}


# ---------------------------------------------------------------------------
# Service category is a HARD FILTER, not a score -- a plumber is never a
# valid answer to an AC problem. These four weights sum to 100 so the final
# score reads as a percentage on the provider card.

SCORING_WEIGHTS = {
    "area": 30,          # right service in the wrong city is useless
    "rating": 30,        # quality signal
    "availability": 20,  # only matters when the job is urgent
    "price": 20,         # only scored when the customer gave a budget
}

SAME_REGION_CREDIT = 0.5   # a nearby area earns half the area weight
NEUTRAL_CREDIT = 0.75      # score given when a factor doesn't apply
TOP_N_PROVIDERS = 3        # how many cards to show

# ---------------------------------------------------------------------------
# 4. GROQ / LLM SETTINGS
# ---------------------------------------------------------------------------
# Groq rotates its model line-up. Verify these IDs before demo day with:
#   GET https://api.groq.com/openai/v1/models
GROQ_MODEL = "llama-3.3-70b-versatile"
GROQ_FALLBACK_MODEL = "llama-3.1-8b-instant"
GROQ_TEMPERATURE = 0.2      # low: we want reliable extraction, not creativity
GROQ_MAX_TOKENS = 700
GROQ_TIMEOUT = 30           # seconds
GROQ_MAX_RETRIES = 1

# ---------------------------------------------------------------------------
# 5. RAG SETTINGS (used by rag.py)
# ---------------------------------------------------------------------------
EMBEDDING_MODEL = "all-MiniLM-L6-v2"   # ~90 MB, runs on CPU, free
RAG_TOP_K = 3
RAG_MIN_SIMILARITY = 0.35              # below this we admit we don't know

# ---------------------------------------------------------------------------
# 6. API KEY
# ---------------------------------------------------------------------------

def get_api_key() -> str | None:
    """
    Three-tier lookup so one codebase runs everywhere:
      1. Colab Secrets  (the key icon in the left sidebar)
      2. a local .env file
      3. a plain environment variable

    Returns None if no key is found. The app must still launch in that case
    and fall back to keyword classification -- never crash on a missing key.
    """
    # 1. Colab Secrets
    try:
        from google.colab import userdata  # type: ignore
        key = userdata.get("GROQ_API_KEY")
        if key:
            return key.strip()
    except Exception:
        pass  # not on Colab, or the secret has no notebook access

    # 2. .env file
    try:
        from dotenv import load_dotenv
        load_dotenv(BASE_DIR / ".env")
    except Exception:
        pass

    # 3. environment variable
    key = os.getenv("GROQ_API_KEY")
    return key.strip() if key else None


def ai_enabled() -> bool:
    """True when a Groq key is available. app.py uses this to show the banner."""
    return get_api_key() is not None


# ---------------------------------------------------------------------------
# 7. UI TEXT
# ---------------------------------------------------------------------------
APP_NAME = "HomeFix AI"
APP_TAGLINE = "Tell us what's wrong. We'll help you find the right professional."
DEMO_NOTICE = (
    "All service providers shown in this app are FICTIONAL DEMO DATA created "
    "for an academic project. They are not real businesses and the phone "
    "numbers are not real numbers."
)
EXAMPLE_PROMPTS = [
    "My AC isn't cooling.",
    "My kitchen sink is blocked.",
    "My washing machine is leaking.",
    "I need an electrician.",
]

# ---------------------------------------------------------------------------
# Self-check: run `python src/config.py` to confirm paths resolve correctly
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    print(f"BASE_DIR            : {BASE_DIR}")
    print(f"BASE_DIR exists     : {BASE_DIR.exists()}")
    print(f"DATA_IS_TEMPORARY   : {DATA_IS_TEMPORARY}")
    print(f"Service categories  : {len(SERVICE_CATEGORIES)}")
    print(f"Areas               : {len(AREAS)}")
    print(f"Weights sum to      : {sum(SCORING_WEIGHTS.values())}")
    print(f"API key found       : {ai_enabled()}")
