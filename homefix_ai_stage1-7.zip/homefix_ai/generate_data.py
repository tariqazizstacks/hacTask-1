"""
generate_data.py
================
Run this ONCE to create the three CSV files the app reads.

    python generate_data.py          (local)
    !python generate_data.py         (Colab)

Why a script instead of hand-typing CSVs?
  * The data is version-controlled and reproducible -- any team member can
    regenerate identical files.
  * Prices, ratings and areas are validated against src/config.py, so the
    dataset can never drift out of sync with the controlled vocabulary.
  * It self-checks at the end (row counts, nulls, category coverage).

The provider records are HARDCODED, not randomly generated. Random data would
change on every run and break the seeded request history.

Outputs:
  data/services.csv   -> the 8 canonical categories + matching keywords
  data/providers.csv  -> 32 fictional demo providers (4 per category)
  data/requests.csv   -> 15 seeded historical bookings so the analytics tab
                         has something to chart from day one

Connects to: database.py reads requests.csv, provider_matching.py reads
providers.csv, classifier.py reads services.csv.
"""

import sys
from pathlib import Path

import pandas as pd

sys.path.append(str(Path(__file__).resolve().parent))

from src import config

# ===========================================================================
# 1. SERVICES  -- the controlled vocabulary
# ===========================================================================
# The `keywords` column does double duty:
#   * it is injected into the LLM system prompt as category hints
#   * classifier.py scores raw user text against it when the LLM is
#     unavailable or returns an invalid category (the keyword fallback)

SERVICES = [
    {
        "service_id": "S1",
        "service_category": "AC Technician",
        "anchor_keywords": "ac,air conditioner,air conditioning,split ac,window ac,inverter ac,hvac,ac unit,outdoor unit",
        "keywords": "ac,air conditioner,air conditioning,cooling,not cooling,gas refill,split ac,window ac,inverter ac,compressor,hvac,ac leaking,ac service",
        "description": "Installation, servicing, gas refilling and repair of split, window and inverter air conditioners.",
        "typical_price_min": 800,
        "typical_price_max": 3500,
    },
    {
        "service_id": "S2",
        "service_category": "Plumber",
        "anchor_keywords": "sink,tap,faucet,pipe,drain,toilet,flush,commode,basin,geyser,water heater,water tank,water motor,sewerage,nali",
        "keywords": "pipe,sink,leak,leaking,drain,blocked,clogged,tap,faucet,water,toilet,flush,bathroom,geyser,water tank,sewerage,drainage",
        "description": "Leak repair, blocked drains, tap and pipe replacement, toilet and geyser installation.",
        "typical_price_min": 500,
        "typical_price_max": 2500,
    },
    {
        "service_id": "S3",
        "service_category": "Electrician",
        "anchor_keywords": "light,lights,bulb,tube light,switch,socket,plug,wiring,fuse,breaker,switchboard,meter,electric meter,ups",
        "keywords": "light,lights,bulb,wiring,switch,power,electricity,fuse,breaker,socket,plug,short circuit,voltage,meter,fan not working,tripping",
        "description": "House wiring, switchboard and breaker repair, lighting installation and electrical fault finding.",
        "typical_price_min": 400,
        "typical_price_max": 3000,
    },
    {
        "service_id": "S4",
        "service_category": "Appliance Repair",
        "anchor_keywords": "washing machine,fridge,refrigerator,freezer,microwave,oven,dryer,dishwasher,water dispenser,juicer,toaster,iron",
        "keywords": "washing machine,fridge,refrigerator,freezer,microwave,oven,dryer,dishwasher,water dispenser,appliance,machine noise,not spinning",
        "description": "Repair and servicing of washing machines, refrigerators, microwaves, ovens and other home appliances.",
        "typical_price_min": 600,
        "typical_price_max": 4000,
    },
    {
        "service_id": "S5",
        "service_category": "Home Cleaner",
        "anchor_keywords": "cleaning,deep cleaning,house cleaning,home cleaning,clean my house,clean the house,sofa cleaning,carpet cleaning,maid,housekeeping",
        "keywords": "clean,cleaning,deep clean,dusting,sofa cleaning,carpet,mopping,kitchen cleaning,bathroom cleaning,maid,housekeeping,post construction cleaning",
        "description": "General house cleaning, deep cleaning, sofa and carpet shampooing, and post-renovation clean-up.",
        "typical_price_min": 1500,
        "typical_price_max": 6000,
    },
    {
        "service_id": "S6",
        "service_category": "Painter",
        "anchor_keywords": "paint,painting,repaint,repainting,whitewash,distemper,emulsion,wall paint,polish,putty",
        "keywords": "paint,painting,wall,walls,ceiling,color,colour,whitewash,distemper,emulsion,polish,primer,repaint,peeling paint",
        "description": "Interior and exterior painting, whitewashing, wall putty work and wood polishing.",
        "typical_price_min": 2000,
        "typical_price_max": 15000,
    },
    {
        "service_id": "S7",
        "service_category": "Carpenter",
        "anchor_keywords": "furniture,wood,wooden,door,cabinet,cupboard,wardrobe,table,chair,drawer,shelf,bed frame",
        "keywords": "wood,wooden,furniture,door,doors,cabinet,cupboard,wardrobe,table,chair,bed,drawer,hinge,shelf,broken furniture,carpentry",
        "description": "Furniture repair and assembly, door and cabinet fitting, custom shelving and woodwork.",
        "typical_price_min": 700,
        "typical_price_max": 5000,
    },
    {
        "service_id": "S8",
        "service_category": "Locksmith",
        "anchor_keywords": "lock,door lock,key,padlock,duplicate key,broken key,latch,handle",
        "keywords": "lock,locked,key,keys,door lock,stuck,broken key,duplicate key,padlock,handle,locked out,safe,security lock",
        "description": "Lock repair and replacement, key duplication, lock-out assistance and security lock installation.",
        "typical_price_min": 500,
        "typical_price_max": 2000,
    },
]

# ===========================================================================
# 2. PROVIDERS  -- 32 FICTIONAL demo records, 4 per category
# ===========================================================================
# Phone numbers use the synthetic 0300-000-00XX pattern on purpose: it is
# obviously fake, so we can never accidentally publish a real person's
# number in a student project. utils.mask_phone() masks it again in the UI.
#
# Ratings are deliberately spread between 3.8 and 4.9, and availability is
# spread across all four options, so the scoring engine has real variation
# to rank on. A dataset where every provider is 4.5/Today proves nothing.

PROVIDERS = [
    # ---------------- AC Technician ----------------
    ("P001", "Ahmed Cooling Services", "AC Technician", "Faisalabad", 4.8, 800, 3500, "Today", 6,
     "Split and inverter AC specialists offering same-day gas refilling and leak repair."),
    ("P002", "CoolAir Experts", "AC Technician", "Lahore", 4.5, 1000, 4000, "Tomorrow", 9,
     "Full AC servicing, compressor repair and annual maintenance contracts."),
    ("P003", "Capital Climate Care", "AC Technician", "Islamabad", 4.6, 1200, 4500, "Today", 7,
     "Certified HVAC team handling installation, dismantling and cooling faults."),
    ("P004", "Breeze Master AC", "AC Technician", "Karachi", 4.2, 700, 3000, "Within 3 Days", 4,
     "Budget-friendly AC repair, drainage cleaning and window unit servicing."),

    # ---------------- Plumber ----------------
    ("P005", "Rapid Pipe Solutions", "Plumber", "Islamabad", 4.7, 600, 2500, "Today", 8,
     "Emergency leak control, blocked drain clearing and pipe replacement."),
    ("P006", "Bilal Plumbing Works", "Plumber", "Rawalpindi", 4.3, 500, 2000, "Today", 5,
     "Bathroom and kitchen plumbing, tap fitting and geyser installation."),
    ("P007", "AquaFix Plumbers", "Plumber", "Lahore", 4.6, 700, 2800, "Tomorrow", 11,
     "Experienced team for sewerage issues, water tank cleaning and re-piping."),
    ("P008", "Indus Water Works", "Plumber", "Karachi", 4.0, 450, 1800, "Within 3 Days", 3,
     "Affordable drain unblocking, motor fitting and general plumbing repair."),

    # ---------------- Electrician ----------------
    ("P009", "SafeVolt Electricians", "Electrician", "Islamabad", 4.9, 500, 3000, "Today", 12,
     "Licensed electricians for fault finding, breaker upgrades and safe rewiring."),
    ("P010", "Kamran Electric House", "Electrician", "Faisalabad", 4.4, 400, 2200, "Tomorrow", 6,
     "Switchboard repair, lighting installation and fan or motor troubleshooting."),
    ("P011", "PowerLine Services", "Electrician", "Lahore", 4.5, 600, 3200, "Today", 8,
     "Complete house wiring, UPS and solar inverter connection work."),
    ("P012", "Metro Electric Care", "Electrician", "Hyderabad", 3.9, 350, 1800, "Weekends Only", 4,
     "Weekend electrical repairs, socket replacement and minor wiring jobs."),

    # ---------------- Appliance Repair ----------------
    ("P013", "HomeTech Appliance Repair", "Appliance Repair", "Lahore", 4.7, 800, 4000, "Today", 10,
     "Washing machine, refrigerator and microwave repair with 30-day warranty."),
    ("P014", "Usman Electronics Repair", "Appliance Repair", "Islamabad", 4.4, 700, 3500, "Tomorrow", 7,
     "On-site diagnostics for fridges, dryers and dishwashers of all brands."),
    ("P015", "FixIt Appliance Clinic", "Appliance Repair", "Karachi", 4.1, 600, 3000, "Within 3 Days", 5,
     "Motor, drum and thermostat replacement for major household appliances."),
    ("P016", "Lyallpur Machine Care", "Appliance Repair", "Faisalabad", 4.3, 650, 3200, "Today", 6,
     "Same-day washing machine and water dispenser repair at your doorstep."),

    # ---------------- Home Cleaner ----------------
    ("P017", "SparkleHome Cleaning", "Home Cleaner", "Islamabad", 4.8, 2000, 6000, "Today", 5,
     "Trained crew for deep cleaning, kitchen degreasing and bathroom sanitising."),
    ("P018", "FreshNest Cleaners", "Home Cleaner", "Lahore", 4.6, 1800, 5500, "Tomorrow", 4,
     "Sofa and carpet shampooing plus full-house cleaning packages."),
    ("P019", "Pindi Deep Clean", "Home Cleaner", "Rawalpindi", 4.2, 1500, 4500, "Weekends Only", 3,
     "Weekend deep cleaning service for apartments and small houses."),
    ("P020", "Coastal Clean Crew", "Home Cleaner", "Karachi", 4.4, 2200, 7000, "Within 3 Days", 6,
     "Post-construction and move-in cleaning with eco-friendly products."),

    # ---------------- Painter ----------------
    ("P021", "ColorCraft Painters", "Painter", "Lahore", 4.7, 2500, 15000, "Tomorrow", 13,
     "Interior and exterior painting with putty work and colour consultation."),
    ("P022", "Perfect Finish Painting", "Painter", "Islamabad", 4.5, 3000, 18000, "Within 3 Days", 9,
     "Premium emulsion finishes, texture walls and wood polishing."),
    ("P023", "Shahid Paint Works", "Painter", "Faisalabad", 4.1, 2000, 12000, "Today", 7,
     "Economical whitewash and distemper work for full homes or single rooms."),
    ("P024", "Urban Wall Studio", "Painter", "Karachi", 4.3, 2800, 16000, "Weekends Only", 5,
     "Feature walls, stencil designs and weekend-only residential painting."),

    # ---------------- Carpenter ----------------
    ("P025", "WoodMaster Carpentry", "Carpenter", "Islamabad", 4.6, 800, 5000, "Tomorrow", 11,
     "Custom wardrobes, kitchen cabinets and precision furniture repair."),
    ("P026", "Classic Furniture Repair", "Carpenter", "Lahore", 4.4, 700, 4500, "Today", 8,
     "Same-day fixes for broken tables, chairs, beds and cupboard hinges."),
    ("P027", "Hyderabad Wood Works", "Carpenter", "Hyderabad", 4.0, 600, 3800, "Within 3 Days", 6,
     "Door fitting, shelving and general carpentry for homes and offices."),
    ("P028", "Precision Carpenters", "Carpenter", "Rawalpindi", 4.5, 900, 5500, "Today", 9,
     "Furniture assembly, drawer track replacement and wood polishing."),

    # ---------------- Locksmith ----------------
    ("P029", "QuickKey Locksmiths", "Locksmith", "Islamabad", 4.7, 500, 2000, "Today", 6,
     "Fast lock-out assistance, key duplication and door lock replacement."),
    ("P030", "SecureLock Services", "Locksmith", "Lahore", 4.5, 600, 2200, "Today", 8,
     "Digital and mechanical lock installation plus safe opening service."),
    ("P031", "City Lock Rescue", "Locksmith", "Karachi", 4.2, 550, 2500, "Today", 4,
     "Round-the-clock response for jammed locks and broken keys."),
    ("P032", "Ali Lock & Key", "Locksmith", "Faisalabad", 3.8, 400, 1600, "Tomorrow", 3,
     "Basic padlock, handle and door lock repair at low cost."),
]

PROVIDER_COLUMNS = [
    "provider_id", "provider_name", "service_category", "area", "rating",
    "price_min", "price_max", "availability", "phone", "experience_years",
    "description",
]

# ===========================================================================
# 3. SEEDED REQUEST HISTORY
# ===========================================================================
# 15 fictional past bookings. Purpose: the analytics dashboard (Stage 12)
# must have data to aggregate during the demo. "Total requests: 1" looks
# broken. Every provider_id below must exist in PROVIDERS -- the self-check
# at the bottom enforces that.

SEED_REQUESTS = [
    # (request_id, created_at, customer, area, problem, category, provider_id, date, time_slot, urgency, status)
    ("HFX-20260814-7A2130", "2026-08-14 10:12", "Hina Raza", "Islamabad", "AC not cooling properly in the bedroom", "AC Technician", "P003", "2026-08-15", "Morning (9 AM - 12 PM)", "normal", "Completed"),
    ("HFX-20260817-3C4487", "2026-08-17 16:40", "Tariq Mehmood", "Lahore", "Kitchen sink completely blocked", "Plumber", "P007", "2026-08-18", "Evening (4 PM - 8 PM)", "urgent", "Completed"),
    ("HFX-20260820-9F0874", "2026-08-20 09:05", "Sana Iqbal", "Islamabad", "Lights keep tripping in the lounge", "Electrician", "P009", "2026-08-20", "Afternoon (12 PM - 4 PM)", "urgent", "Completed"),
    ("HFX-20260823-1B7732", "2026-08-23 14:22", "Faisal Nadeem", "Karachi", "Washing machine making loud noise while spinning", "Appliance Repair", "P015", "2026-08-26", "Morning (9 AM - 12 PM)", "normal", "Completed"),
    ("HFX-20260825-5D19D1", "2026-08-25 11:30", "Ayesha Khan", "Lahore", "Need full house deep cleaning before guests arrive", "Home Cleaner", "P018", "2026-08-27", "Morning (9 AM - 12 PM)", "normal", "Completed"),
    ("HFX-20260828-2E6302", "2026-08-28 18:55", "Zain Abbas", "Faisalabad", "Bedroom walls need repainting", "Painter", "P023", "2026-09-01", "Morning (9 AM - 12 PM)", "normal", "Cancelled"),
    ("HFX-20260830-8A3567", "2026-08-30 08:47", "Nida Sheikh", "Rawalpindi", "Cupboard door hinge broken", "Carpenter", "P028", "2026-08-31", "Afternoon (12 PM - 4 PM)", "normal", "Completed"),
    ("HFX-20260901-4C9206", "2026-09-01 20:10", "Usman Javed", "Islamabad", "Locked out, main door lock jammed", "Locksmith", "P029", "2026-09-01", "Evening (4 PM - 8 PM)", "emergency", "Completed"),
    ("HFX-20260903-6B50D7", "2026-09-03 13:15", "Maryam Aslam", "Islamabad", "AC leaking water onto the floor", "AC Technician", "P003", "2026-09-04", "Afternoon (12 PM - 4 PM)", "urgent", "Completed"),
    ("HFX-20260905-0F81E8", "2026-09-05 10:00", "Bilal Qureshi", "Rawalpindi", "Bathroom tap dripping continuously", "Plumber", "P006", "2026-09-06", "Morning (9 AM - 12 PM)", "normal", "Completed"),
    ("HFX-20260907-7D2605", "2026-09-07 17:33", "Rabia Noor", "Lahore", "Refrigerator not cooling at all", "Appliance Repair", "P013", "2026-09-08", "Evening (4 PM - 8 PM)", "urgent", "Confirmed"),
    ("HFX-20260909-3A14DA", "2026-09-09 12:48", "Hamza Sultan", "Karachi", "Sofa and carpet shampooing required", "Home Cleaner", "P020", "2026-09-13", "Morning (9 AM - 12 PM)", "normal", "Confirmed"),
    ("HFX-20260910-9E5784", "2026-09-10 09:20", "Sadia Farooq", "Islamabad", "Two power sockets stopped working", "Electrician", "P009", "2026-09-11", "Morning (9 AM - 12 PM)", "urgent", "Confirmed"),
    ("HFX-20260911-5C036A", "2026-09-11 15:05", "Adnan Rauf", "Lahore", "Wooden dining table leg cracked", "Carpenter", "P026", "2026-09-12", "Afternoon (12 PM - 4 PM)", "normal", "Pending"),
    ("HFX-20260911-8B4932", "2026-09-11 19:40", "Kiran Shah", "Islamabad", "Living room needs a fresh coat of paint", "Painter", "P022", "2026-09-16", "Morning (9 AM - 12 PM)", "normal", "Pending"),
]

# Schema now lives in src/config.py so database.py uses the identical list.
REQUEST_COLUMNS = config.REQUEST_COLUMNS


# ===========================================================================
# 4. BUILDERS
# ===========================================================================

def build_services() -> pd.DataFrame:
    return pd.DataFrame(SERVICES)


def build_providers() -> pd.DataFrame:
    rows = []
    for i, p in enumerate(PROVIDERS, start=1):
        (pid, name, category, area, rating,
         pmin, pmax, availability, years, desc) = p
        rows.append({
            "provider_id": pid,
            "provider_name": name,
            "service_category": category,
            "area": area,
            "rating": rating,
            "price_min": pmin,
            "price_max": pmax,
            "availability": availability,
            # synthetic, clearly-fake number -- never a real subscriber
            "phone": f"0300-000-{i:04d}",
            "experience_years": years,
            "description": desc,
        })
    return pd.DataFrame(rows, columns=PROVIDER_COLUMNS)


def build_requests(providers: pd.DataFrame) -> pd.DataFrame:
    """Expand SEED_REQUESTS into the full 16-column request schema."""
    lookup = providers.set_index("provider_id")
    rows = []
    for (rid, created, customer, area, problem,
         category, pid, date, slot, urgency, status) in SEED_REQUESTS:
        prov = lookup.loc[pid]
        # estimated price = midpoint of the provider's quoted range,
        # which is exactly how provider_matching.py will compute it later
        estimate = int(round((prov["price_min"] + prov["price_max"]) / 2, -1))
        rows.append({
            "request_id": rid,
            "created_at": created,
            "customer_name": customer,
            "phone": f"0311-000-{len(rows) + 1:04d}",
            "area": area,
            "address": f"Demo address, {area}",
            "problem_description": problem,
            "service_category": category,
            "provider_id": pid,
            "provider_name": prov["provider_name"],
            "preferred_date": date,
            "preferred_time": slot,
            "notes": "",
            "estimated_price": estimate,
            "urgency": urgency,
            "status": status,
        })
    return pd.DataFrame(rows, columns=REQUEST_COLUMNS)


# ===========================================================================
# 5. SELF-CHECK
# ===========================================================================

def validate(services: pd.DataFrame,
             providers: pd.DataFrame,
             requests: pd.DataFrame) -> list[str]:
    """Return a list of problems. An empty list means the dataset is clean."""
    errors: list[str] = []

    # -- services
    if len(services) != len(config.SERVICE_CATEGORIES):
        errors.append(f"services.csv has {len(services)} rows, expected {len(config.SERVICE_CATEGORIES)}")
    if "anchor_keywords" not in services.columns:
        errors.append("services.csv is missing the anchor_keywords column")
    unknown = set(services["service_category"]) - set(config.SERVICE_CATEGORIES)
    if unknown:
        errors.append(f"services.csv has categories not in config: {unknown}")

    # -- providers
    if providers.isnull().values.any():
        errors.append("providers.csv contains null values")
    if providers["provider_id"].duplicated().any():
        errors.append("providers.csv has duplicate provider_id values")
    bad_cat = set(providers["service_category"]) - set(config.SERVICE_CATEGORIES)
    if bad_cat:
        errors.append(f"providers.csv has invalid categories: {bad_cat}")
    bad_area = set(providers["area"]) - set(config.AREAS)
    if bad_area:
        errors.append(f"providers.csv has invalid areas: {bad_area}")
    bad_avail = set(providers["availability"]) - set(config.AVAILABILITY_OPTIONS)
    if bad_avail:
        errors.append(f"providers.csv has invalid availability: {bad_avail}")
    if not providers["rating"].between(1, 5).all():
        errors.append("providers.csv has a rating outside 1-5")
    if not (providers["price_min"] < providers["price_max"]).all():
        errors.append("providers.csv has price_min >= price_max somewhere")
    counts = providers["service_category"].value_counts()
    thin = [c for c in config.SERVICE_CATEGORIES if counts.get(c, 0) < 2]
    if thin:
        errors.append(f"fewer than 2 providers in: {thin}")

    # -- requests
    orphans = set(requests["provider_id"]) - set(providers["provider_id"])
    if orphans:
        errors.append(f"requests.csv references unknown providers: {orphans}")
    bad_status = set(requests["status"]) - set(config.REQUEST_STATUSES)
    if bad_status:
        errors.append(f"requests.csv has invalid statuses: {bad_status}")
    if requests["request_id"].duplicated().any():
        errors.append("requests.csv has duplicate request_id values")

    return errors


def main() -> int:
    config.ensure_dirs()

    services = build_services()
    providers = build_providers()
    requests = build_requests(providers)

    errors = validate(services, providers, requests)
    if errors:
        print("VALIDATION FAILED -- files not written:")
        for e in errors:
            print(f"  - {e}")
        return 1

    services.to_csv(config.SERVICES_CSV, index=False)
    providers.to_csv(config.PROVIDERS_CSV, index=False)
    # Only seed requests.csv if it does not already exist, so re-running
    # this script can never wipe real bookings made during a demo.
    if config.REQUESTS_CSV.exists():
        print(f"! {config.REQUESTS_CSV.name} already exists -- left untouched")
    else:
        requests.to_csv(config.REQUESTS_CSV, index=False)

    print("Validation passed. Files written to", config.DATA_DIR)
    print(f"  services.csv  : {len(services)} rows")
    print(f"  providers.csv : {len(providers)} rows x {len(providers.columns)} cols")
    print(f"  requests.csv  : {len(requests)} seeded rows")
    print("\nProviders per category:")
    print(providers["service_category"].value_counts().to_string())
    print("\nProviders per area:")
    print(providers["area"].value_counts().to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
