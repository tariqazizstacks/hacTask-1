# HomeFix AI — Complete Build Roadmap
### AI Home Service Assistant | Google Colab + Gradio + Groq

> **Project type:** Generative AI + Business Analytics student project
> **Status:** Planning complete — ready to build
> **Share this file with all team members before writing any code.**

---

## Quick clarification: Groq vs Grok

These are different products and it matters:

- **Groq** (`console.groq.com`) — free tier, OpenAI-compatible API, very fast inference. **This is what we are using.**
- **Grok** (`x.ai`) — xAI's model, paid.

The code is written against an OpenAI-compatible endpoint, so switching providers later is a two-line change in `config.py`.

---

## PART 1 — Final Tech Stack

| Layer | Choice | Why |
|---|---|---|
| Dev environment | Google Colab | No local setup required |
| UI | Gradio Blocks (5.x) | Tabs, chat, HTML cards, `share=True` public demo link |
| LLM | Groq — `llama-3.3-70b-versatile` | Free tier, JSON mode, fast |
| Fallback LLM | `llama-3.1-8b-instant` | If we hit rate limits mid-demo |
| Data | Pandas + CSV | Simple, inspectable, gradeable |
| RAG | `sentence-transformers` (all-MiniLM-L6-v2) + NumPy cosine | No vector DB, no paid API |
| RAG fallback | scikit-learn TF-IDF | If the model download fails |
| Secrets | Colab Secrets + `python-dotenv` | Works in both Colab and VS Code |
| Persistence | Google Drive mount | Colab wipes `/content` when the session dies |

**Model IDs — verify before demo day.** Groq rotates models. Hit `https://api.groq.com/openai/v1/models` to get a JSON list of currently active models. Keep that as a health-check cell in the notebook.

---

## PART 2 — Architecture

```
                         ┌────────────────────────────┐
                         │   GRADIO UI (app.py)       │
                         │  6 Tabs + gr.State         │
                         └────────────┬───────────────┘
                                      │
        ┌──────────────┬──────────────┼──────────────┬──────────────┐
        ▼              ▼              ▼              ▼              ▼
 ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌───────────┐ ┌───────────┐
 │ai_assistant│ │ classifier │ │  provider_ │ │ database  │ │ analytics │
 │    .py     │ │    .py     │ │ matching.py│ │   .py     │ │   .py     │
 └─────┬──────┘ └─────┬──────┘ └─────┬──────┘ └─────┬─────┘ └─────┬─────┘
       │              │              │              │             │
       ▼              ▼              ▼              ▼             ▼
  ┌─────────┐   ┌──────────┐   ┌──────────┐   ┌──────────┐  ┌──────────┐
  │ Groq API│   │  safety  │   │providers │   │requests  │  │ Pandas   │
  │         │   │  .py     │   │  .csv    │   │  .csv    │  │ charts   │
  └─────────┘   └──────────┘   └──────────┘   └──────────┘  └──────────┘
       │
       ▼
  ┌─────────┐
  │ rag.py  │──► knowledge_base/*.txt ──► embeddings (cached .npy)
  └─────────┘
```

### The critical data flow — memorize this for the viva

```
User text
   ↓
safety.py            → scan for emergency keywords FIRST (before any LLM call)
   ↓
ai_assistant.py      → Groq call with JSON mode
   ↓
returns SLOT DICT    → {service_category, urgency, area, ...}
   ↓
classifier.py        → VALIDATE category against the fixed list of 8
   ↓
provider_matching.py → filter + score providers.csv
   ↓
Gradio HTML cards    → user picks one
   ↓
database.py          → append row to requests.csv, status = "Pending"
   ↓
Dashboard + Analytics read the same CSV
```

**The one design decision that carries the whole project:** the LLM never touches provider data. It only produces a JSON slot dict. Every fact about a provider comes from Pandas. This satisfies requirements C, E, K and J at once — and it is what examiners will ask about.

---

## PART 3 — Folder Structure

Drive-backed, but identical to what runs in VS Code.

```
/content/drive/MyDrive/homefix_ai/
│
├── app.py                    ← Gradio entry point
├── requirements.txt
├── .env.example
├── README.md
├── HomeFix_AI.ipynb          ← the Colab notebook (our dev cockpit)
│
├── data/
│   ├── providers.csv         ← 32 DEMO records
│   ├── services.csv          ← 8 canonical categories
│   └── requests.csv          ← bookings (created at runtime)
│
├── knowledge_base/
│   ├── services.txt
│   ├── faq.txt
│   └── policies.txt
│
├── src/
│   ├── __init__.py
│   ├── config.py             ← paths, categories, weights, model name
│   ├── utils.py              ← validation, ID generation, formatting
│   ├── safety.py             ← emergency + dangerous-advice guard
│   ├── ai_assistant.py       ← Groq client + system prompt + JSON extraction
│   ├── classifier.py         ← category validation + keyword fallback
│   ├── provider_matching.py  ← scoring engine
│   ├── rag.py                ← embed, cache, retrieve
│   ├── database.py           ← CSV read/write layer
│   └── analytics.py          ← Pandas aggregations
│
├── cache/
│   └── kb_embeddings.npy     ← generated once, reused
│
└── assets/
    └── style.css
```

**Why this works in Colab:** we write every file with `%%writefile`, so we get real modular files — gradeable, zippable, GitHub-ready — while never leaving the notebook.

---

## PART 4 — Data Schema

### `data/services.csv` — the controlled vocabulary

```
service_id,service_category,keywords,description,typical_price_min,typical_price_max
S1,AC Technician,"ac,air conditioner,cooling,gas refill,split ac",...,800,3500
S2,Plumber,"pipe,sink,leak,drain,tap,water,toilet,blocked",...,500,2500
S3,Electrician,"light,wiring,switch,power,fuse,breaker,socket",...,400,3000
S4,Appliance Repair,"washing machine,fridge,microwave,oven,dryer",...,600,4000
S5,Home Cleaner,"clean,dusting,deep clean,sofa,carpet",...,1500,6000
S6,Painter,"paint,wall,ceiling,color,whitewash",...,2000,15000
S7,Carpenter,"wood,furniture,door,cabinet,table,chair",...,700,5000
S8,Locksmith,"lock,key,door lock,stuck,broken key",...,500,2000
```

This file is the single source of truth for categories. The LLM prompt is built from it, the validator checks against it, and the keyword fallback uses the `keywords` column. One file, three jobs.

### `data/providers.csv` — 32 demo records, 4 per category

```
provider_id, provider_name, service_category, area, rating,
price_min, price_max, availability, phone, experience_years, description
```

Rules:
- `availability` ∈ {Today, Tomorrow, Within 3 Days, Weekends Only}
- `phone` must be masked in the UI → `0300-XXX4521`
- `area` drawn from ~6 fixed areas, so matching actually has something to match on
- Every card carries a **DEMO DATA** badge. We never claim these are real businesses.

### `data/requests.csv` — written at runtime

```
request_id, created_at, customer_name, phone, area, address,
problem_description, service_category, provider_id, provider_name,
preferred_date, preferred_time, notes, estimated_price, urgency, status
```

- `request_id` format: `HFX-20260912-A3F19C` (date + 6 hex chars)
- `status` ∈ {Pending, Confirmed, Completed, Cancelled}

**Seed it with ~15 fake historical rows before the demo.** An analytics dashboard showing "Total requests: 1" is a bad look.

---

## PART 5 — Installation (Colab cells)

**Cell 1 — installs**
```python
!pip -q install gradio groq python-dotenv sentence-transformers pandas
```
`pandas`, `numpy`, `scikit-learn` and `matplotlib` are pre-installed in Colab. Do **not** reinstall them — that is a common way to break a runtime 10 minutes before a presentation.

**Cell 2 — mount Drive**
```python
from google.colab import drive
drive.mount('/content/drive')
BASE = '/content/drive/MyDrive/homefix_ai'
!mkdir -p {BASE}/{data,src,knowledge_base,cache,assets}
%cd {BASE}
```

**Cell 3 — make imports live-reload**
```python
import sys; sys.path.append(BASE)
%load_ext autoreload
%autoreload 2
```

**`requirements.txt`** (for the VS Code / submission version)
```
gradio>=5.0.0
groq>=0.11.0
pandas>=2.0.0
numpy>=1.24.0
python-dotenv>=1.0.0
sentence-transformers>=3.0.0
scikit-learn>=1.3.0
```

---

## PART 6 — API Key (do this before writing any code)

1. Go to `console.groq.com` → sign in → **API Keys** → Create. Copy it immediately; it is shown only once.
2. In Colab: left sidebar **🔑 Secrets** → Add new secret → Name `GROQ_API_KEY`, paste the value, toggle **Notebook access** ON.
3. `config.py` reads it with a three-tier fallback so the same file runs in Colab, in VS Code, and on a teammate's laptop:

```python
def get_api_key():
    # 1. Colab Secrets  2. .env file  3. environment variable
    try:
        from google.colab import userdata
        return userdata.get("GROQ_API_KEY")
    except Exception:
        pass
    load_dotenv()
    return os.getenv("GROQ_API_KEY")
```

If it returns `None`, the app must still launch and show a yellow banner: *"AI Assistant offline — keyword classification active."* **Never crash on a missing key.** Examiners test this.

`.env.example` ships with `GROQ_API_KEY=` and nothing else.
**Add `.env` to `.gitignore` before the first commit.** Nobody pushes a real key.

---

## PART 7 — The 12 Build Stages

Each stage ends with something we can actually run. Never move on with a broken stage.

| # | Stage | Files | Done when… |
|---|---|---|---|
| 1 | Setup & secrets | `config.py` | A test Groq call prints a reply |
| 2 | Data generation | `providers.csv`, `services.csv` | `df.shape` = (32, 11), no nulls |
| 3 | Storage layer | `database.py`, `utils.py` | We can write and read back a fake request |
| 4 | Safety layer | `safety.py` | "gas leak" returns an emergency block, pre-LLM |
| 5 | AI extraction | `ai_assistant.py` | 5 test sentences → 5 valid JSON slot dicts |
| 6 | Validation | `classifier.py` | An invalid category from the LLM is caught and corrected |
| 7 | Matching engine | `provider_matching.py` | Ranked DataFrame with a visible `score` column |
| 8 | Gradio skeleton | `app.py` | 6 empty tabs launch with `share=True` |
| 9 | Chat tab wired | `app.py` | Full chat → cards → selection loop works |
| 10 | Booking + dashboard | `app.py` | Submitted request appears in the Dashboard tab |
| 11 | RAG | `rag.py`, `knowledge_base/` | "What is your cancellation policy?" answers from the KB |
| 12 | Analytics + README | `analytics.py`, `README.md` | 4 metrics + 2 charts render |

**Suggested schedule — 4 people, 2 weeks:** Stages 1–3 on days 1–2, Stages 4–7 on days 3–5, Stages 8–10 on days 6–9, Stages 11–12 on days 10–12, then two full days of testing and rehearsal.

---

## PART 8 — Module Contracts

These are the exact shapes each module passes to the next. **Agree on them before anyone writes code** and integration day won't be a nightmare.

### `ai_assistant.extract_request_info(user_message, history) -> dict`

```python
{
  "service_category": "AC Technician",        # MUST be one of the 8
  "problem_summary": "AC leaking water, not cooling",
  "object": "split AC",
  "symptoms": ["water leakage", "no cooling"],
  "urgency": "urgent",                        # emergency | urgent | normal
  "area": "Faisalabad" | None,
  "preferred_date": None,
  "preferred_time": None,
  "missing_info": ["area"],
  "follow_up_question": "Which area are you in?" | None,
  "safety_flag": "none",                      # none|electrical|gas|fire|water
  "confidence": 0.92
}
```

Get this from Groq with `response_format={"type": "json_object"}`. Two gotchas:
1. The word **JSON** must literally appear in the prompt or the API rejects the request.
2. Still wrap `json.loads()` in a try/except that falls back to keyword classification.

### `classifier.validate_category(raw, user_text) -> (category, method)`

Returns `("Plumber", "llm")` — or, if the LLM hallucinated "Pipe Guy", falls back to keyword scoring against `services.csv` and returns `("Plumber", "keyword_fallback")`. **Show the method in the UI.** It's an honest touch that impresses evaluators.

### `provider_matching.find_providers(slots, top_n=3) -> DataFrame`

Returns all provider fields plus `score`, `score_breakdown`, `estimated_price`.

### `database.save_request(dict) -> (bool, request_id, error)`

Never raises. Returns a tuple the UI can branch on.

### `rag.retrieve(query, k=3) -> list[dict]`

`[{"text": ..., "source": "faq.txt", "similarity": 0.81}]`. If max similarity < 0.35, return `[]` and let the assistant say it doesn't have that information.

---

## PART 9 — The Scoring Engine

Weights live in `config.py` as a dict so we can tune them live during the demo — that always plays well.

```python
SCORING_WEIGHTS = {
    "area":         30,   # right service, wrong city = useless
    "rating":       30,   # quality signal
    "availability": 20,   # urgency-dependent
    "price":        20,   # only if a budget was given
}
```

**Step 1 — hard filter.** `df[df.service_category == category]`. Category is a filter, not a score. A plumber is never a valid answer to an AC problem, no matter how good their rating.

**Step 2 — score the survivors out of 100.**

| Factor | Rule |
|---|---|
| Area | exact match 30, same-region 15, else 0 |
| Rating | `(rating / 5.0) × 30` |
| Availability | urgency emergency/urgent → Today 20, Tomorrow 10, else 0. Urgency normal → everything gets 15 |
| Price | no budget given → everyone gets 15. Budget given → full 20 when the range fits, scaled down by overshoot |

Note the availability rule: don't penalise a great provider for being busy when nobody is in a hurry.

**Step 3 — graceful degradation.** If zero providers survive the filter, do **not** show an empty screen. Drop the area constraint, re-run, and label the results *"No providers in your area — showing nearby options."* This one behaviour covers requirement N and the "no matching providers" edge case simultaneously.

**Step 4 — expose the breakdown.** Each card shows `Match score: 87/100` with a hover breakdown. Never present a black-box ranking in a Business Analytics project.

---

## PART 10 — Safety Layer

`safety.py` runs **before** the Groq call, on raw text, using keyword matching. Two reasons: it still works when the API is down, and it costs nothing.

**Tier 1 — Emergency**
Triggers: `gas leak`, `smell gas`, `fire`, `smoke`, `sparking`, `electric shock`, `burning smell`, `flooding`.
Action: red banner immediately. Tell them to leave the area / shut the main valve, call emergency services, and *then* offer to find a professional. Skip the LLM entirely.

**Tier 2 — Dangerous DIY request**
Triggers: `how do I fix/repair/rewire` + `wiring`, `gas`, `circuit`, `main line`.
Action: the LLM may respond, but the system prompt forbids step-by-step instructions. It explains the risk and routes to a professional.

**Tier 3 — Normal**
Proceed as usual.

### Hard rules for the system prompt

- You are an assistant, **not** a certified technician
- Never state prices, ratings, availability or provider names — the app supplies those
- Never say a booking is confirmed; only the app confirms
- Never give step-by-step electrical, gas, or structural repair instructions
- If information is unavailable, say so plainly
- Ask at most **one** follow-up question per turn

---

## PART 11 — Gradio UI Map

```python
with gr.Blocks(theme=gr.themes.Soft(primary_hue="blue")) as demo:
    # Shared state — Gradio's equivalent of st.session_state
    slots_state     = gr.State({})    # extracted info
    providers_state = gr.State(None)  # matched DataFrame
    selected_state  = gr.State(None)  # chosen provider dict

    with gr.Tabs():
        with gr.Tab("🏠 Home"):                ...
        with gr.Tab("💬 AI Assistant"):        ...
        with gr.Tab("🔧 Find a Professional"): ...
        with gr.Tab("📅 My Service Request"):  ...
        with gr.Tab("📊 Dashboard"):           ...
        with gr.Tab("ℹ️ About"):               ...
```

### Three Gradio realities to plan around now, not on demo day

1. **No per-card buttons.** Gradio can't easily put a working button inside dynamically generated HTML. Solution: render cards with `gr.HTML`, and place a `gr.Radio` labelled *"Select a provider"* directly beneath, with the matched provider names as choices. Clean, and it works every time.

2. **Tabs don't auto-switch.** After the AI finds providers, we can't reliably push the user to the next tab. Solution: keep chat → cards → selection all on the **AI Assistant** tab, and let the other tabs be alternative entry points into the same functions.

3. **`gr.Chatbot` needs `type="messages"`** in Gradio 5.x, i.e. `[{"role": "user", "content": "..."}]`. The old tuple format is deprecated and will warn or break.

Launch with `demo.launch(share=True, debug=True)` — the public link lasts 72 hours, so it can be shared with the evaluator.

---

## PART 12 — Analytics Tab

Six outputs from `requests.csv` via Pandas:

- Four KPI boxes: total requests, most requested service, most requested area, average estimated price
- Bar chart: requests by service category → `gr.BarPlot`
- Pie/bar: status distribution → `gr.Plot` with matplotlib
- Bonus marks: requests over time (line), average rating of booked providers vs available

Call `load_requests()` fresh on every tab render (`demo.load` + a Refresh button). **Don't cache** — the whole point of the demo is watching the number tick up after a booking.

---

## PART 13 — Error Handling Matrix

| Failure | Behaviour |
|---|---|
| No API key | App launches, yellow banner, keyword classifier active |
| Groq timeout / 429 | Retry once, then fall back to keyword classifier, tell the user |
| Empty message | "Please describe your problem." — no API call |
| Bad JSON from LLM | try/except → keyword fallback |
| Invalid service category | `classifier` corrects it silently, logs the method |
| No matching providers | Relax area filter, show nearby, label it |
| Invalid form data | Field-level red messages, nothing saved |
| Missing CSV | Auto-create with headers, show setup message |
| RAG failure | Answer without retrieval, note that policy info is unavailable |
| Drive not mounted | Fall back to `/content`, warn that data won't persist |

---

## PART 14 — Integration Test Checklist

Run this before presenting. Five test messages through the full pipeline:

1. `"My AC is leaking water and isn't cooling"` → AC Technician, urgency urgent
2. `"kitchen sink blocked water not going down"` → Plumber (tests informal English)
3. `"there is a gas smell in my kitchen"` → emergency banner, no LLM call
4. `"how do I repair exposed electrical wiring myself"` → refusal + electrician referral
5. `"what are your working hours"` → RAG answer from `policies.txt`, no provider search

Then verify:

- [ ] Every import resolves
- [ ] Every path uses `config.BASE_DIR` — no hardcoded paths
- [ ] The `request_id` written by `database.py` is the one shown in the confirmation
- [ ] The Dashboard row count increments by exactly 1
- [ ] The analytics total matches `len(requests_df)`
- [ ] The app launches with the API key deliberately removed

---

## PART 15 — 5-Minute Demo Script

| Time | Action |
|---|---|
| 0:00 | Home tab — read the tagline, click an example prompt |
| 0:30 | Type the AC problem → show the extracted JSON slots in an expander (this is the "AI" moment; make it visible) |
| 1:15 | AI asks one follow-up → answer with an area |
| 1:45 | Three provider cards appear with score breakdowns — say *"the LLM never chose these; Pandas did"* |
| 2:30 | Select, fill the booking form, submit → confirmation with request ID |
| 3:15 | Dashboard tab → point at the new row |
| 3:45 | Analytics tab → totals updated, charts redrawn |
| 4:15 | Type the gas-leak message → emergency banner |
| 4:45 | Close on architecture: controlled categories, LLM for language only, deterministic matching |

---

## PART 16 — Group Division of Work

| Member | Owns | Files |
|---|---|---|
| **A — Data & Backend** | Dataset design, storage layer | `providers.csv`, `services.csv`, `database.py`, `utils.py` |
| **B — AI** | Prompting, extraction, safety | `ai_assistant.py`, `classifier.py`, `safety.py` |
| **C — UI** | All six tabs, styling, cards | `app.py`, `style.css` |
| **D — RAG & Analytics** | Knowledge base, metrics, docs | `rag.py`, `knowledge_base/*`, `analytics.py`, `README.md` |

Everyone owns their own module's error handling. Integration is a shared working session on day 9.

---

## PART 17 — Label These as "Future Improvements"

Say these out loud in the presentation as *deliberate scope decisions*, not gaps:

- SQLite migration
- Real-time provider availability API
- SMS/email confirmation via Twilio
- Multilingual support (Urdu / Roman Urdu)
- Geolocation-based area detection
- Provider login portal
- Payment integration
- Review and rating submission
- FAISS/Chroma vector store for a larger knowledge base
- Fine-tuned classifier replacing the LLM call
- Multi-turn slot memory across sessions

---

## Build Order (pin this)

```
config → data → database → safety → ai_assistant → classifier →
matching → app skeleton → app wiring → rag → analytics → README
```

Nothing gets built out of order. Each stage must run before the next begins.
