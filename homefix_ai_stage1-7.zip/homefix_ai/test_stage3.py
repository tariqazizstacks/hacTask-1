"""
test_stage3.py
==============
Plain-Python tests for utils.py and database.py. No pytest needed.

    python test_stage3.py

Every test prints PASS or FAIL and the script exits non-zero if anything
fails, so it can be dropped into a CI step later. Keep this file -- it is
evidence of testing for your project report.
"""

import shutil
import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

from src import config, database, utils

PASSED = 0
FAILED = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  PASS  {label}")
    else:
        FAILED += 1
        print(f"  FAIL  {label} {detail}")


def valid_form(**overrides) -> dict:
    form = {
        "customer_name": "Test Customer",
        "phone": "0300-1234567",
        "area": "Islamabad",
        "address": "House 1, Street 2, G-11",
        "problem_description": "AC is leaking water and not cooling at all",
        "service_category": "AC Technician",
        "provider_id": "P003",
        "preferred_date": (date.today() + timedelta(days=1)).isoformat(),
        "preferred_time": config.TIME_SLOTS[0],
        "notes": "Second floor",
        "urgency": "urgent",
    }
    form.update(overrides)
    return form


# ===========================================================================
print("\n[1] utils - IDs and timestamps")
# ===========================================================================
import re as _re
rid = utils.generate_request_id()
check("request id matches HFX-YYYYMMDD-XXXXXX",
      bool(_re.fullmatch(r"HFX-\d{8}-[0-9A-F]{6}", rid)), rid)
# Entropy sanity check, not a uniqueness guarantee. 1000 draws from a
# 16.7M space gives ~0.03 expected collisions, so >=998 unique is safe.
# Uniqueness itself is enforced by save_request(), tested in section [8].
_draws = [utils.generate_request_id() for _ in range(1000)]
check("1000 draws yield >=998 unique suffixes",
      len(set(_draws)) >= 998, str(len(set(_draws))))
check("now_string is 16 chars", len(utils.now_string()) == 16, utils.now_string())

# ===========================================================================
print("\n[2] utils - text and escaping")
# ===========================================================================
check("clean_text collapses whitespace",
      utils.clean_text("  my   AC \n leaks ") == "my AC leaks")
check("clean_text handles None", utils.clean_text(None) == "")
check("escape_html neutralises a script tag",
      "<script>" not in utils.escape_html("<script>alert(1)</script>"))
check("truncate adds an ellipsis", utils.truncate("x" * 200, 50).endswith("\u2026"))

# ===========================================================================
print("\n[3] utils - phone")
# ===========================================================================
for good in ["03001234567", "0300-123-4567", "+923001234567", "0092 300 1234567"]:
    check(f"accepts {good}", utils.validate_phone(good))
for bad in ["12345", "", None, "0300123", "04001234567", "abcdefghijk"]:
    check(f"rejects {bad!r}", not utils.validate_phone(bad))
check("mask hides the middle", utils.mask_phone("03001234567") == "0300-XXX-4567",
      utils.mask_phone("03001234567"))
check("mask handles junk", utils.mask_phone("x") == "number unavailable")

# ===========================================================================
print("\n[4] utils - area normalisation")
# ===========================================================================
cases = {
    "Islamabad": "Islamabad", "islamabad": "Islamabad", "ISB": "Islamabad",
    "pindi": "Rawalpindi", "I live in Lahore city": "Lahore",
    "fsd": "Faisalabad", "khi": "Karachi", " Hyderabad ": "Hyderabad",
}
for raw, expected in cases.items():
    got = utils.normalize_area(raw)
    check(f"{raw!r} -> {expected}", got == expected, f"got {got}")
for unknown in ["", None, "Multan", "asdfgh"]:
    check(f"{unknown!r} -> None", utils.normalize_area(unknown) is None)
check("Islamabad and Rawalpindi share a region",
      utils.same_region("Islamabad", "Rawalpindi"))
check("Islamabad and Karachi do not",
      not utils.same_region("Islamabad", "Karachi"))
check("same_region handles None", not utils.same_region(None, "Lahore"))

# ===========================================================================
print("\n[5] utils - price and rating")
# ===========================================================================
check("estimate 800-3500 = 2150", utils.estimate_price(800, 3500) == 2150,
      str(utils.estimate_price(800, 3500)))
check("estimate handles junk", utils.estimate_price("x", None) == 0)
check("format_price", utils.format_price(2150) == "PKR 2,150")
check("format_price handles junk", utils.format_price(None) == "PKR --")
check("star_rating 4.6", utils.star_rating(4.6).startswith("\u2605" * 4))

# ===========================================================================
print("\n[6] utils - form validation")
# ===========================================================================
check("a valid form produces no errors", utils.validate_booking_form(valid_form()) == {},
      str(utils.validate_booking_form(valid_form())))

bad_cases = {
    "customer_name": valid_form(customer_name=""),
    "phone": valid_form(phone="123"),
    "area": valid_form(area="Multan"),
    "address": valid_form(address=""),
    "problem_description": valid_form(problem_description="broken"),
    "service_category": valid_form(service_category="Pipe Guy"),
    "provider_id": valid_form(provider_id=""),
    "preferred_date": valid_form(preferred_date="2020-01-01"),
    "preferred_time": valid_form(preferred_time="Midnight"),
}
for field, form in bad_cases.items():
    errs = utils.validate_booking_form(form)
    check(f"catches bad {field}", field in errs, str(errs))

check("past date rejected", not utils.validate_date("2020-01-01")[0])
check("date >90 days rejected",
      not utils.validate_date((date.today() + timedelta(days=200)).isoformat())[0])
check("tomorrow accepted",
      utils.validate_date((date.today() + timedelta(days=1)).isoformat())[0])
check("bad date format rejected", not utils.validate_date("12/09/2026")[0])
check("format_errors builds a bullet list",
      utils.format_errors({"phone": "bad"}).startswith("Please fix"))
check("format_errors on empty dict is empty", utils.format_errors({}) == "")

# ===========================================================================
print("\n[7] database - readers")
# ===========================================================================
database.clear_cache()
providers = database.load_providers()
check("32 providers loaded", len(providers) == 32, str(len(providers)))
check("estimated_price column derived", "estimated_price" in providers.columns)
check("region column derived", "region" in providers.columns)
check("no Unknown regions", (providers["region"] != "Unknown").all())
check("P001 estimate matches utils formula",
      providers.loc[providers.provider_id == "P001", "estimated_price"].iloc[0]
      == utils.estimate_price(800, 3500))

services = database.load_services()
check("8 services loaded", len(services) == 8, str(len(services)))
check("keywords column present", "keywords" in services.columns)

requests_before = database.load_requests()
check("15 seeded requests", len(requests_before) == 15, str(len(requests_before)))
check("request columns in config order",
      list(requests_before.columns) == config.REQUEST_COLUMNS)

check("get_provider('P003') works",
      database.get_provider("P003")["provider_name"] == "Capital Climate Care")
check("get_provider('P999') returns None", database.get_provider("P999") is None)
check("get_provider('') returns None", database.get_provider("") is None)
check("get_provider_by_name works",
      database.get_provider_by_name("SafeVolt Electricians")["provider_id"] == "P009")
check("get_provider_by_name unknown -> None",
      database.get_provider_by_name("Nobody Ltd") is None)

# ===========================================================================
print("\n[8] database - save_request")
# ===========================================================================
backup = config.REQUESTS_CSV.with_suffix(".backup")
shutil.copy(config.REQUESTS_CSV, backup)

try:
    ok, new_id, err = database.save_request(valid_form())
    check("valid booking saves", ok, err)
    check("returns a request id", bool(new_id) and new_id.startswith("HFX-"), str(new_id))

    after = database.load_requests()
    check("row count went 15 -> 16", len(after) == 16, str(len(after)))

    saved = database.get_request(new_id)
    check("booking is readable back", saved is not None)
    check("status defaults to Pending", saved["status"] == "Pending", str(saved["status"]))
    check("provider_name denormalised",
          saved["provider_name"] == "Capital Climate Care", str(saved["provider_name"]))
    check("estimated_price recomputed from dataset",
          saved["estimated_price"] == utils.estimate_price(1200, 4500),
          str(saved["estimated_price"]))
    check("problem text preserved",
          saved["problem_description"].startswith("AC is leaking"))

    # a form the LLM or UI could plausibly submit wrongly
    ok2, id2, err2 = database.save_request(valid_form(phone="123"))
    check("invalid phone is rejected", not ok2 and id2 is None)
    check("error message is user-friendly", "Phone" in err2, err2)

    ok3, id3, err3 = database.save_request(valid_form(provider_id="P999"))
    check("nonexistent provider is rejected", not ok3)

    # P005 is a Plumber -- must not be bookable for an AC job
    ok4, id4, err4 = database.save_request(
        valid_form(provider_id="P005", service_category="AC Technician"))
    check("category/provider mismatch is rejected", not ok4, err4)
    check("mismatch message names the provider",
          "Rapid Pipe Solutions" in err4, err4)

    check("no partial writes from the 3 failures",
          len(database.load_requests()) == 16, str(len(database.load_requests())))

    # ===================================================================
    print("\n[9] database - update_request_status")
    # ===================================================================
    ok5, err5 = database.update_request_status(new_id, "Confirmed")
    check("status updates", ok5, err5)
    check("new status persisted",
          database.get_request(new_id)["status"] == "Confirmed")
    ok6, err6 = database.update_request_status(new_id, "Teleported")
    check("invalid status rejected", not ok6)
    ok7, err7 = database.update_request_status("HFX-00000000-ZZZZ", "Completed")
    check("unknown request id rejected", not ok7)
    check("row count unchanged after updates",
          len(database.load_requests()) == 16)

    # ===================================================================
    print("\n[10] database - health and resilience")
    # ===================================================================
    health = database.data_health()
    check("health reports ok", health["ok"], str(health["problems"]))
    check("health counts providers", health["providers"] == 32)
    check("health counts requests", health["requests"] == 16)

    # missing file recovery
    config.REQUESTS_CSV.unlink()
    recovered = database.load_requests()
    check("missing requests.csv is recreated", config.REQUESTS_CSV.exists())
    check("recreated file is empty but correctly shaped",
          len(recovered) == 0 and list(recovered.columns) == config.REQUEST_COLUMNS)

    ok8, id8, err8 = database.save_request(valid_form())
    check("can save into a freshly created file", ok8, err8)

finally:
    shutil.move(str(backup), str(config.REQUESTS_CSV))
    print(f"\n  (restored {config.REQUESTS_CSV.name} to its seeded state)")

restored = database.load_requests()
check("requests.csv restored to 15 rows", len(restored) == 15, str(len(restored)))

# ===========================================================================
print(f"\n{'=' * 46}")
print(f"  {PASSED} passed, {FAILED} failed")
print(f"{'=' * 46}\n")
sys.exit(1 if FAILED else 0)
