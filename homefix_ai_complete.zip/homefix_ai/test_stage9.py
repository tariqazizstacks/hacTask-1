"""
test_stage9.py
==============
Tests for the AI Assistant conversation pipeline.

    python test_stage9.py

Everything runs against stub clients, so no API key and no network are
needed. The pipeline under test is the real one:

    safety -> language model -> category validation -> provider matching

Section [4] is the one that matters most: the same conversation with the
model unavailable must still reach a usable list of professionals.
"""

import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

sys.path.append(str(Path(__file__).resolve().parent))

from src import config, ui_logic

PASSED = 0
FAILED = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  PASS  {label}")
    else:
        FAILED += 1
        print(f"  FAIL  {label} {detail}")


class Stub:
    """Returns each scripted payload in turn; counts calls."""

    def __init__(self, *payloads):
        self.payloads = list(payloads)
        self.calls = 0
        outer = self

        class _C:
            def create(self, **kwargs):
                outer.calls += 1
                item = (outer.payloads.pop(0) if outer.payloads
                        else {"reply": "ok"})
                if isinstance(item, Exception):
                    raise item
                content = json.dumps(item)
                return SimpleNamespace(
                    choices=[SimpleNamespace(
                        message=SimpleNamespace(content=content))])

        self.chat = SimpleNamespace(completions=_C())


AC_PAYLOAD = {
    "service_category": "AC Technician",
    "problem_summary": "AC leaking water and not cooling",
    "object": "split AC", "symptoms": ["leaking", "no cooling"],
    "urgency": "urgent", "area": "Islamabad",
    "reply": "That sounds like a drainage problem. Let me find an AC technician.",
    "confidence": 0.94, "in_scope": True,
}


# ===========================================================================
print("\n[1] Empty and trivial input")
# ===========================================================================
for value in ["", "   ", None]:
    turn = ui_logic.process_message(value, [], {})
    check(f"{value!r} does not crash", isinstance(turn, dict))
    check(f"{value!r} asks for a description", "describe" in turn["reply"].lower())
    check(f"{value!r} adds nothing to the history", turn["history"] == [])
    check(f"{value!r} offers no providers", turn["can_book"] is False)

blank = ui_logic.reset_conversation()
check("reset returns the same shape as a turn",
      set(blank) == set(ui_logic.process_message("", [], {})))
check("reset clears the history", blank["history"] == [])
check("reset clears the slots", blank["slots"] == {})
check("reset shows the empty card state", "hf-empty" in blank["cards_html"])

# ===========================================================================
print("\n[2] The happy path")
# ===========================================================================
turn = ui_logic.process_message(
    "My AC is leaking water and isn't cooling, I'm in Islamabad",
    [], {}, client=Stub(AC_PAYLOAD))

check("two chat turns are recorded", len(turn["history"]) == 2)
check("the user turn is stored first", turn["history"][0]["role"] == "user")
check("the assistant turn follows", turn["history"][1]["role"] == "assistant")
check("the reply is the assistant's message",
      turn["history"][1]["content"] == turn["reply"])
check("the trade is identified", turn["slots"]["service_category"] == "AC Technician")
check("the area is captured", turn["slots"]["area"] == "Islamabad")
check("urgency is captured", turn["slots"]["urgency"] == "urgent")

check("providers are matched", turn["matches"] is not None and len(turn["matches"]) == 3)
check("booking becomes possible", turn["can_book"] is True)
check("cards are rendered", turn["cards_html"].count("hf-card\"") == 3)
check("the local provider ranks first", "Capital Climate Care" in turn["cards_html"])
check("one radio choice per card", len(turn["choices"]) == 3)
check("the note explains what was searched",
      "AC Technician" in turn["note_md"] and "Islamabad" in turn["note_md"],
      turn["note_md"])
check("the note mentions prioritising urgency", "soonest" in turn["note_md"])

check("the summary panel is populated", "What I understood" in turn["summary_md"])
check("the summary shows the trade", "AC Technician" in turn["summary_md"])
check("the summary names how the trade was identified",
      "AI language model" in turn["summary_md"])
check("the summary shows the classifier reason",
      "<small>" in turn["summary_md"])

# ===========================================================================
print("\n[3] Multi-turn slot filling")
# ===========================================================================
first = ui_logic.process_message(
    "my ac is broken", [], {},
    client=Stub({"service_category": "AC Technician",
                 "problem_summary": "AC not working", "urgency": "normal",
                 "reply": "Which area are you in?",
                 "follow_up_question": "Which area are you in?",
                 "missing_info": ["area"], "confidence": 0.8}))
check("turn 1 identifies the trade",
      first["slots"]["service_category"] == "AC Technician")
check("turn 1 has no area yet", first["slots"]["area"] is None)
check("turn 1 still shows providers", first["can_book"] is True)

second = ui_logic.process_message(
    "Islamabad", first["history"], first["slots"],
    client=Stub({"area": "Islamabad", "reply": "Thanks, searching Islamabad.",
                 "service_category": None, "confidence": 0.7}))
check("turn 2 keeps the trade from turn 1",
      second["slots"]["service_category"] == "AC Technician")
check("turn 2 adds the area", second["slots"]["area"] == "Islamabad")
check("history accumulates", len(second["history"]) == 4)
check("results are re-ranked for the new area",
      second["matches"].iloc[0]["area"] == "Islamabad")
check("history is capped",
      len(ui_logic.process_message(
          "hello", [{"role": "user", "content": f"m{i}"} for i in range(50)],
          {}, client=Stub(AC_PAYLOAD))["history"]) <= ui_logic.MAX_HISTORY)

# ===========================================================================
print("\n[4] The model is unavailable - the app must still work")
# ===========================================================================
dead = Stub(*[RuntimeError("connection refused")] * 6)
turn = ui_logic.process_message(
    "My AC is leaking water and not cooling in Islamabad", [], {}, client=dead)

check("the failure is not raised", isinstance(turn, dict))
check("the model was attempted", dead.calls > 0)
check("keywords recover the trade",
      turn["slots"]["service_category"] == "AC Technician")
check("the recovery is labelled honestly",
      turn["slots"]["category_source"] == "keyword_fallback")
check("providers are still matched", turn["can_book"] is True)
check("cards are still rendered", "hf-card" in turn["cards_html"])
check("the user still gets a reply", len(turn["reply"]) > 20)
check("the summary says the AI was not used",
      "keyword fallback" in turn["summary_md"].lower(), turn["summary_md"][:200])

# ===========================================================================
print("\n[5] Safety comes first")
# ===========================================================================
stub = Stub(AC_PAYLOAD)
turn = ui_logic.process_message("There is a gas smell in my kitchen", [], {},
                                client=stub)
check("a critical hazard makes no API call", stub.calls == 0)
check("the safety message is the reply", "gas" in turn["reply"].lower())
check("no provider cards are shown under a hazard warning",
      turn["matches"] is None and "hf-empty" in turn["cards_html"])
check("booking is not offered", turn["can_book"] is False)
check("the note offers help once safe",
      "safe" in turn["note_md"].lower(), turn["note_md"])
check("urgency is forced to emergency", turn["slots"]["urgency"] == "emergency")

stub = Stub({"service_category": "Plumber", "area": "Lahore",
             "urgency": "emergency", "reply": "I will find a plumber.",
             "problem_summary": "burst pipe"})
turn = ui_logic.process_message("water is everywhere, the pipe burst", [], {},
                                client=stub)
check("an urgent hazard does call the model", stub.calls == 1)
check("an urgent hazard still shows providers", turn["can_book"] is True)

stub = Stub({"service_category": "Electrician", "reply": "Please do not do that yourself.",
             "urgency": "normal", "problem_summary": "wants to rewire a socket"})
turn = ui_logic.process_message("how do I rewire the socket myself", [], {},
                                client=stub)
check("a DIY request still reaches the model", stub.calls == 1)
check("the safety warning is prepended to the reply",
      "not a safe do-it-yourself job" in turn["reply"].lower())
check("an electrician is still offered", turn["can_book"] is True)

# ===========================================================================
print("\n[6] When the trade cannot be determined")
# ===========================================================================
turn = ui_logic.process_message(
    "something is wrong", [], {},
    client=Stub({"service_category": None, "reply": "Could you say more?",
                 "in_scope": True, "confidence": 0.2}))
check("no trade means no cards", turn["matches"] is None)
check("no trade means no booking", turn["can_book"] is False)
check("the note says a trade is needed", "trade" in turn["note_md"].lower())
check("a follow-up question is offered",
      bool(turn["slots"].get("follow_up_question")))

turn = ui_logic.process_message(
    "the light above my kitchen sink is not working", [], {},
    client=Stub({"service_category": None, "reply": "Let me check.",
                 "confidence": 0.3}))
check("an ambiguous problem is flagged", turn["slots"]["ambiguous"] is True)
check("ambiguity offers two choices",
      len(turn["slots"].get("suggested_categories", [])) == 2)

turn = ui_logic.process_message(
    "write my history homework", [], {},
    client=Stub({"service_category": None, "in_scope": False,
                 "reply": "I can only help with home services."}))
check("out-of-scope requests are marked", turn["slots"]["in_scope"] is False)
check("out-of-scope requests offer no providers", turn["can_book"] is False)

# ===========================================================================
print("\n[7] Choosing a provider")
# ===========================================================================
turn = ui_logic.process_message(
    "My AC is leaking water in Islamabad", [], {}, client=Stub(AC_PAYLOAD))
matches = turn["matches"]

picked = ui_logic.select_provider(turn["choices"][0], matches, turn["slots"])
check("a selection resolves to a provider", picked["provider"] is not None)
check("the right provider is chosen",
      picked["provider"]["provider_name"] == matches.iloc[0]["provider_name"])
check("booking is enabled", picked["can_book"] is True)
check("the score breakdown is shown", "Why this ranking" in picked["breakdown_md"])
check("the breakdown is a table", "| Factor |" in picked["breakdown_md"])
check("the breakdown totals out of 100", "/ 100" in picked["breakdown_md"])
check("the booking summary names the provider",
      matches.iloc[0]["provider_name"] in picked["booking_md"])
check("the booking summary gives an estimate", "PKR" in picked["booking_md"])
check("the booking summary says the price is not final",
      "final price" in picked["booking_md"])

for bad in ["", None, "Nobody (Nowhere)"]:
    blank = ui_logic.select_provider(bad, matches, turn["slots"])
    check(f"selection {bad!r} is rejected", blank["provider"] is None)
    check(f"selection {bad!r} keeps booking disabled", blank["can_book"] is False)

check("selection with no matches is safe",
      ui_logic.select_provider("x", None)["provider"] is None)
check("selection falls back to the database when matches are lost",
      ui_logic.select_provider(
          "Capital Climate Care (Islamabad)",
          pd.DataFrame([{"provider_id": "P003",
                         "provider_name": "Capital Climate Care",
                         "area": "Islamabad"}]))["provider"] is not None)

mismatch = ui_logic.booking_summary_markdown(
    {"provider_name": "X", "service_category": "Plumber", "area": "Lahore",
     "rating": 4.0, "experience_years": 3, "availability": "Today",
     "estimated_price": 900},
    {"service_category": "Electrician"})
check("a trade mismatch is called out", "but selected" in mismatch)

# ===========================================================================
print("\n[8] Safety of rendered content")
# ===========================================================================
turn = ui_logic.process_message(
    "<script>alert('x')</script> my sink is blocked", [], {},
    client=Stub({"service_category": "Plumber",
                 "problem_summary": "<script>alert('x')</script> sink blocked",
                 "reply": "Let me find a plumber.", "urgency": "normal"}))
check("script tags never reach the summary panel",
      "<script>" not in turn["summary_md"])
check("the escaped text is still visible",
      "&lt;script&gt;" in turn["summary_md"])
check("script tags never reach the cards", "<script>" not in turn["cards_html"])

# ===========================================================================
print("\n[9] app.py handlers")
# ===========================================================================
class _Node:
    def __init__(self, name="n"):
        self._name = name

    def __call__(self, *a, **k):
        return _Node(self._name)

    def __getattr__(self, item):
        if item.startswith("_"):
            raise AttributeError(item)
        return _Node(f"{self._name}.{item}")

    def __enter__(self):
        return self

    def __exit__(self, *e):
        return False


class _FakeGradio:
    def __getattr__(self, item):
        if item.startswith("_"):
            raise AttributeError(item)
        return lambda *a, **k: _Node(item)


sys.modules["gradio"] = _FakeGradio()
sys.modules["gradio"].themes = _Node("themes")

import app  # noqa: E402

for handler in ["on_send", "on_select_provider", "on_clear",
                "on_continue_to_booking"]:
    check(f"handler {handler} is defined", callable(getattr(app, handler, None)))

out = app.on_send("my kitchen sink is blocked", [], {})
check("on_send returns 11 outputs", len(out) == 11, str(len(out)))
check("on_send clears the message box", out[8] == "")
check("on_send returns the chat history", isinstance(out[0], list) and len(out[0]) == 2)

cleared = app.on_clear()
check("on_clear returns 12 outputs", len(cleared) == 12, str(len(cleared)))
check("on_clear empties the chat", cleared[0] == [] and cleared[2] == {})

carried = app.on_continue_to_booking(
    {"area": "Lahore", "problem_summary": "sink blocked",
     "preferred_date": None, "preferred_time": None}, {"provider_id": "P007"})
check("on_continue_to_booking returns 5 outputs", len(carried) == 5)
check("the area is carried to the form", carried[1] == "Lahore")
check("the problem text is carried to the form", carried[2] == "sink blocked")
check("a missing date becomes an empty string", carried[3] == "")
check("on_continue_to_booking survives empty slots",
      len(app.on_continue_to_booking(None, None)) == 5)

# ===========================================================================
print(f"\n{'=' * 46}")
print(f"  {PASSED} passed, {FAILED} failed")
print(f"{'=' * 46}\n")
sys.exit(1 if FAILED else 0)
