"""
test_stage10.py
===============
Tests for booking submission and the dashboard status controls.

    python test_stage10.py

This suite writes to data/requests.csv. It takes a backup first and restores
it in a finally block, so it is safe to run at any time, including during a
demo. The last section verifies the file came back with its original 15 rows.
"""

import shutil
import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent))

from src import config, database, ui_logic

PASSED = 0
FAILED = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  PASS  {label}")
    else:
        FAILED += 1
        print(f"  FAIL  {label} {detail}")


TOMORROW = (date.today() + timedelta(days=1)).isoformat()
PROVIDER = database.get_provider("P003")          # Capital Climate Care
SLOTS = {"urgency": "urgent", "problem_summary": "AC leaking water"}


def booking(**overrides):
    args = {
        "name": "Test Customer",
        "phone": "0300-1234567",
        "area": "Islamabad",
        "address": "House 1, Street 2, G-11",
        "problem": "AC is leaking water and not cooling at all",
        "preferred_date": TOMORROW,
        "preferred_time": config.TIME_SLOTS[0],
        "notes": "Second floor",
        "provider": PROVIDER,
        "slots": SLOTS,
    }
    args.update(overrides)
    return ui_logic.submit_booking(**args)


backup = config.REQUESTS_CSV.with_suffix(".backup")
shutil.copy(config.REQUESTS_CSV, backup)

try:
    # =======================================================================
    print("\n[1] No professional selected")
    # =======================================================================
    result = booking(provider=None)
    check("submission is refused", result["ok"] is False)
    check("no reference is issued", result["request_id"] is None)
    check("the form is not cleared", result["clear_form"] is False)
    check("the message says what to do first",
          "AI Assistant" in result["message_md"], result["message_md"])
    check("nothing was written", len(database.load_requests()) == 15)

    # =======================================================================
    print("\n[2] Field validation")
    # =======================================================================
    bad_cases = {
        "empty name": ({"name": ""}, "Name"),
        "short name": ({"name": "Al"}, "Name"),
        "empty phone": ({"phone": ""}, "Phone"),
        "invalid phone": ({"phone": "12345"}, "Phone"),
        "empty address": ({"address": ""}, "Address"),
        "short problem": ({"problem": "broken"}, "Problem"),
        "past date": ({"preferred_date": "2020-01-01"}, "Preferred date"),
        "bad date format": ({"preferred_date": "12/09/2026"}, "Preferred date"),
        "no time slot": ({"preferred_time": ""}, "Preferred time"),
        "invalid area": ({"area": "Multan"}, "Area"),
    }
    for label, (override, expected_field) in bad_cases.items():
        r = booking(**override)
        check(f"{label} is rejected", r["ok"] is False)
        check(f"{label} names the field", expected_field in r["message_md"],
              r["message_md"][:90])

    check("no failed submission was written", len(database.load_requests()) == 15)

    r = booking(name="", phone="123")
    check("several errors are listed together",
          "Name" in r["message_md"] and "Phone" in r["message_md"])
    check("the error block is a bullet list", "- **" in r["message_md"])

    # =======================================================================
    print("\n[3] A successful booking")
    # =======================================================================
    result = booking()
    check("submission succeeds", result["ok"] is True, result["message_md"][:120])
    check("a reference is issued",
          result["request_id"] and result["request_id"].startswith("HFX-"))
    check("the form is cleared", result["clear_form"] is True)
    check("the row count goes 15 to 16", len(database.load_requests()) == 16)

    saved = database.get_request(result["request_id"])
    check("the request reads back", saved is not None)
    check("status starts as Pending", saved["status"] == "Pending")
    check("the provider is recorded",
          saved["provider_name"] == "Capital Climate Care")
    check("the service comes from the provider, not the form",
          saved["service_category"] == "AC Technician")
    check("urgency is carried from the conversation", saved["urgency"] == "urgent")
    check("the customer's own words are stored",
          saved["problem_description"].startswith("AC is leaking"))
    check("notes are stored", saved["notes"] == "Second floor")

    # =======================================================================
    print("\n[4] The confirmation message")
    # =======================================================================
    md = result["message_md"]
    check("the reference is shown first",
          md.index(result["request_id"]) < 120, str(md.index(result["request_id"])))
    check("the professional is named", "Capital Climate Care" in md)
    check("the date is shown", TOMORROW in md)
    check("the time slot is shown", config.TIME_SLOTS[0] in md)
    check("the estimate is shown", "PKR" in md)
    check("the status is shown", "Pending" in md)
    check("it says the final cost is agreed later", "final cost" in md)
    check("it says no real booking was made",
          "No professional has been contacted" in md)
    check("it says this is academic", "academic" in md)
    check("it points at the dashboard", "Dashboard" in md)

    # =======================================================================
    print("\n[5] Price cannot be tampered with from the form")
    # =======================================================================
    from src import utils
    expected = utils.estimate_price(PROVIDER["price_min"], PROVIDER["price_max"])
    check("the estimate is recomputed from the dataset",
          saved["estimated_price"] == expected, str(saved["estimated_price"]))
    check("the estimate matches the provider's midpoint", expected == 2850,
          str(expected))

    # a provider whose trade does not match what was described
    plumber = database.get_provider("P005")
    r = booking(provider=plumber, problem="my AC is leaking water badly")
    check("booking a different trade is still allowed if the data agrees",
          r["ok"] is True, r["message_md"][:100])
    check("the recorded service follows the provider",
          database.get_request(r["request_id"])["service_category"] == "Plumber")

    # =======================================================================
    print("\n[6] Dashboard picks up the new rows")
    # =======================================================================
    table, note = ui_logic.dashboard_table()
    check("the dashboard shows 17 rows now", len(table) == 17, str(len(table)))
    check("the newest booking is at the top",
          table.iloc[0]["Request ID"] == r["request_id"])
    check("the summary count updates", "17" in ui_logic.dashboard_summary())

    pending, _ = ui_logic.dashboard_table("Pending")
    check("new bookings appear under Pending",
          result["request_id"] in set(pending["Request ID"]))

    ids = ui_logic.request_id_choices()
    check("every request is offered in the status dropdown", len(ids) == 17)
    check("the newest reference is first", ids[0] == r["request_id"])

    # =======================================================================
    print("\n[7] Changing a status")
    # =======================================================================
    message = ui_logic.change_status(result["request_id"], "Confirmed")
    check("the change is reported", "Confirmed" in message)
    check("the change is persisted",
          database.get_request(result["request_id"])["status"] == "Confirmed")

    table, _ = ui_logic.dashboard_table("Confirmed")
    check("the dashboard reflects the new status",
          result["request_id"] in set(table["Request ID"]))

    check("an unknown reference is rejected",
          "not found" in ui_logic.change_status("HFX-00000000-ZZZZZZ", "Completed"))
    check("an invalid status is rejected",
          "must be one of" in ui_logic.change_status(result["request_id"], "Teleported"))
    check("a blank reference is rejected",
          "Choose a request" in ui_logic.change_status("", "Completed"))
    check("a blank status is rejected",
          "Choose a status" in ui_logic.change_status(result["request_id"], ""))
    check("no rows were added or lost by status changes",
          len(database.load_requests()) == 17)

    # =======================================================================
    print("\n[8] app.py handlers")
    # =======================================================================
    class _Node:
        def __init__(self, name="n"):
            self._name = name

        def __call__(self, *a, **k):
            return _Node(self._name)

        def __getattr__(self, item):
            if item.startswith("_"):
                raise AttributeError(item)
            return _Node(f"{self._name}.{item}")

        def __enter__(self):
            return self

        def __exit__(self, *e):
            return False

    class _FakeGradio:
        def __getattr__(self, item):
            if item.startswith("_"):
                raise AttributeError(item)
            return lambda *a, **k: _Node(item)

    sys.modules["gradio"] = _FakeGradio()
    sys.modules["gradio"].themes = _Node("themes")

    import app  # noqa: E402

    check("on_submit is defined", callable(getattr(app, "on_submit", None)))
    check("on_change_status is defined",
          callable(getattr(app, "on_change_status", None)))

    out = app.on_submit("Another Customer", "0301-9876543", "Lahore",
                        "Flat 4, Model Town", "The kitchen tap keeps dripping",
                        TOMORROW, config.TIME_SLOTS[1], "", database.get_provider("P007"),
                        {"urgency": "normal"})
    check("on_submit returns 15 outputs", len(out) == 15, str(len(out)))
    check("on_submit confirms the booking", "Request received" in out[0])
    check("on_submit refreshes the dashboard table", len(out[5]) == 18,
          str(len(out[5])))
    check("on_submit refreshes the headline", "18" in out[7])
    check("on_submit refreshes the analytics too", "PKR" in out[9])

    out_bad = app.on_submit("", "", "", "", "", "", "", "", None, {})
    check("on_submit still returns 15 outputs on failure", len(out_bad) == 15)
    check("on_submit reports the problem", "Choose a professional" in out_bad[0])
    check("a failed submit does not clear the form", len(database.load_requests()) == 18)

    out_status = app.on_change_status(result["request_id"], "Completed", "All")
    check("on_change_status returns 11 outputs", len(out_status) == 11)
    check("on_change_status reports success", "Completed" in out_status[0])

    dash = app.on_dashboard_refresh("All")
    check("on_dashboard_refresh now returns 10 outputs", len(dash) == 10)

finally:
    shutil.move(str(backup), str(config.REQUESTS_CSV))
    print(f"\n  (restored {config.REQUESTS_CSV.name} to its seeded state)")

restored = database.load_requests()
check("requests.csv is back to 15 rows", len(restored) == 15, str(len(restored)))
check("no test data survived",
      not restored["customer_name"].isin(["Test Customer", "Another Customer"]).any())

# ===========================================================================
print(f"\n{'=' * 46}")
print(f"  {PASSED} passed, {FAILED} failed")
print(f"{'=' * 46}\n")
sys.exit(1 if FAILED else 0)
