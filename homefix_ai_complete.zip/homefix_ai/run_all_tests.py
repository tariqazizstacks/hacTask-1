"""
run_all_tests.py
================
Run every stage's test suite in order and print one summary line each.

    python run_all_tests.py

Exits non-zero if any suite fails, so it can be used as a pre-demo check or
dropped into a CI step. Run this after copying files between machines --
Stage 10 changed a handler signature that Stage 8's suite was asserting on,
and only running everything caught it.
"""

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SUITES = sorted(HERE.glob("test_stage*.py"),
                key=lambda p: int("".join(c for c in p.stem if c.isdigit())))

total_passed = total_failed = 0
broken = []

for suite in SUITES:
    proc = subprocess.run([sys.executable, str(suite)],
                          capture_output=True, text=True, cwd=HERE)
    line = next((l for l in proc.stdout.splitlines() if "passed," in l), "")
    if line:
        passed, failed = (int(x) for x in
                          [line.split()[0], line.split()[2]])
        total_passed += passed
        total_failed += failed
        mark = "ok  " if failed == 0 else "FAIL"
        print(f"  {mark}  {suite.name:<18} {passed:>4} passed, {failed} failed")
    else:
        broken.append(suite.name)
        print(f"  FAIL  {suite.name:<18} did not finish")
        print("        " + (proc.stdout.strip().splitlines() or ["no output"])[-1])

print("-" * 52)
print(f"        {'TOTAL':<18} {total_passed:>4} passed, {total_failed} failed")
sys.exit(1 if (total_failed or broken) else 0)
