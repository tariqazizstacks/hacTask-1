"""
src/rag.py
==========
Retrieval-augmented generation over the knowledge base.

WHERE RAG IS AND IS NOT USED
----------------------------
Used for: questions about the service itself -- working hours, cancellation,
pricing policy, guarantees, which areas are covered, how ranking works.

NOT used for: finding or filtering providers. Requirement I is explicit about
this and it is the right call. providers.csv is structured data with exact
fields; a similarity search over prose would be slower, less accurate and
impossible to explain. "Which plumbers are free today in Lahore" is a
DataFrame query, not a retrieval problem. Reaching for RAG there would be
using a technique because it is fashionable rather than because it fits.

HOW IT WORKS
------------
1. The three files in knowledge_base/ are split into paragraph chunks, each
   tagged with the heading it sits under.
2. Chunks are embedded and the vectors cached to disk, keyed by a hash of the
   knowledge base contents so the cache rebuilds itself when a file changes.
3. A query is embedded the same way and compared by cosine similarity.
4. Anything below RAG_MIN_SIMILARITY is discarded. If nothing survives, the
   assistant says it does not have that information rather than inventing a
   cancellation policy.

BACKENDS
--------
Three, chosen automatically, best first:

  sentence-transformers   real semantic search. Understands that "when do you
                          close" and "working hours" mean the same thing.
  scikit-learn TF-IDF     term overlap with sensible weighting. Good enough
                          for a knowledge base this size, and scikit-learn is
                          pre-installed in Colab.
  keyword overlap         pure Python, no dependencies. A safety net so the
                          app never crashes because a package is missing.

Public API:
    retrieve(query, k=3)      -> list[dict]
    format_context(hits)      -> str
    is_policy_question(text)  -> bool
    answer_from_kb(hits)      -> str
    backend_name()            -> str
    rebuild_cache()           -> int

Imports from: config.py, utils.py
Used by: ui_logic.process_message, ai_assistant (as prompt context)
"""

from __future__ import annotations

import hashlib
import json
import re

import numpy as np

from . import config, utils

# ===========================================================================
# CHUNKING
# ===========================================================================

MIN_CHUNK_CHARS = 40
MAX_CHUNK_CHARS = 900

# Minimum word-level cosine a hit must reach, on top of the overall floor.
# Only applies to the hybrid TF-IDF backend. See the note in _try_tfidf.
WORD_OVERLAP_GATE = 0.03


def _split_file(text: str, source: str) -> list[dict]:
    """
    One chunk per paragraph, tagged with the heading above it.

    Paragraph-level chunking suits this knowledge base because it was written
    as short self-contained answers. Splitting by fixed token count would cut
    the cancellation policy in half, and retrieving half a policy is worse
    than retrieving none.
    """
    chunks: list[dict] = []
    heading = ""
    for block in re.split(r"\n\s*\n", text):
        block = block.strip()
        if not block:
            continue
        if block.startswith("#"):
            lines = block.split("\n", 1)
            heading = lines[0].lstrip("# ").strip()
            block = lines[1].strip() if len(lines) > 1 else ""
            if not block:
                continue
        if len(block) < MIN_CHUNK_CHARS:
            continue
        chunks.append({
            "text": block[:MAX_CHUNK_CHARS],
            "heading": heading,
            "source": source,
        })
    return chunks


def load_chunks() -> list[dict]:
    """Read and chunk every .txt file in knowledge_base/."""
    chunks: list[dict] = []
    if not config.KB_DIR.exists():
        return chunks
    for path in sorted(config.KB_DIR.glob("*.txt")):
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        chunks.extend(_split_file(text, path.name))
    return chunks


def _kb_fingerprint(chunks: list[dict]) -> str:
    """Hash of the chunk text, so the cache invalidates when the KB changes."""
    digest = hashlib.sha256()
    for chunk in chunks:
        digest.update(chunk["text"].encode("utf-8"))
    return digest.hexdigest()[:16]


# ===========================================================================
# BACKENDS
# ===========================================================================

_state: dict = {}


def _try_sentence_transformers(chunks):
    from sentence_transformers import SentenceTransformer   # noqa: PLC0415

    model = SentenceTransformer(config.EMBEDDING_MODEL)
    vectors = model.encode([c["text"] for c in chunks],
                           normalize_embeddings=True,
                           show_progress_bar=False)
    return {
        "backend": "sentence-transformers",
        "vectors": np.asarray(vectors, dtype=np.float32),
        "encode": lambda q: np.asarray(
            model.encode([q], normalize_embeddings=True), dtype=np.float32)[0],
    }


def _light_stem(text: str) -> str:
    """
    Crude plural stripping, applied to both the corpus and the query.

    Without it "do you work on Sundays" misses the Working hours section,
    which says "Sunday". A full stemmer would be overkill for a knowledge
    base of 33 paragraphs; collapsing plurals fixes almost all of it.
    """
    out = []
    for word in re.findall(r"[a-z]+", str(text).lower()):
        if word.endswith("ies") and len(word) > 4:
            word = word[:-3] + "y"
        elif word.endswith("ses") and len(word) > 4:
            word = word[:-2]
        elif word.endswith("s") and not word.endswith("ss") and len(word) > 3:
            word = word[:-1]
        out.append(word)
    return " ".join(out)


def _try_tfidf(chunks):
    """
    Hybrid TF-IDF: word bigrams plus character 4-5 grams, averaged.

    Word features alone miss morphology -- "can I cancel my booking" does not
    match a section headed "Cancellation policy", because cancel and
    cancellation share no whole token. Character n-grams catch that, but on
    their own they give every query some background similarity, which pushes
    unrelated questions above the floor.

    Averaging the two cosines gets both properties: relevant questions score
    0.16 to 0.28, unrelated ones stay under 0.12. Measured on this knowledge
    base, not assumed.

    Implementation note: each half is L2-normalised and scaled by 1/sqrt(2),
    then concatenated. The dot product of two such vectors is exactly the
    mean of the two cosine similarities, so the rest of the module needs no
    special case for this backend.
    """
    from sklearn.feature_extraction.text import TfidfVectorizer  # noqa: PLC0415

    corpus = [f"{c['heading']} {c['text']}" for c in chunks]
    half = float(np.sqrt(0.5))

    # The stop list has to be stemmed the same way the corpus is, or
    # scikit-learn warns that the two are inconsistent -- and, worse,
    # function words survive and dominate the score. Without this,
    # "write me a poem about the sea" matched a section on 'me', 'about'
    # and 'the' and scored higher than several real questions.
    from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS  # noqa: PLC0415
    stops = frozenset(_light_stem(w) for w in ENGLISH_STOP_WORDS)

    word_vec = TfidfVectorizer(
        ngram_range=(1, 2), sublinear_tf=True, min_df=1,
        preprocessor=_light_stem, stop_words=sorted(stops),
    )
    char_vec = TfidfVectorizer(
        analyzer="char_wb", ngram_range=(4, 5), sublinear_tf=True, min_df=1,
    )

    word_matrix = _normalize(_dense(word_vec.fit_transform(corpus))) * half
    char_matrix = _normalize(_dense(char_vec.fit_transform(corpus))) * half
    matrix = np.hstack([word_matrix, char_matrix])

    def encode(query: str) -> np.ndarray:
        word_part = _normalize(_dense(word_vec.transform([query]))) * half
        char_part = _normalize(_dense(char_vec.transform([query]))) * half
        return np.hstack([word_part, char_part])[0]

    # word_dim lets retrieve() check the word half on its own. Character
    # n-grams exist to handle morphology, not to match unrelated text, and on
    # their own they give every query some background similarity -- "write me
    # a poem about the sea" scored 0.169 against the complaints section.
    # Requiring a little real term overlap removes that whole class of hit.
    return {"backend": "tfidf", "vectors": matrix, "encode": encode,
            "word_dim": word_matrix.shape[1]}


def _dense(matrix) -> np.ndarray:
    return np.asarray(matrix.todense(), dtype=np.float32)


def _try_keyword(chunks):
    """
    Last resort. Bag-of-words cosine, written by hand.

    Never expected to run in practice, but it means a missing package
    degrades retrieval quality instead of taking the whole app down.
    """
    vocab: dict[str, int] = {}
    tokenised = []
    for chunk in chunks:
        words = _tokens(f"{chunk['heading']} {chunk['text']}")
        tokenised.append(words)
        for word in words:
            vocab.setdefault(word, len(vocab))

    matrix = np.zeros((len(chunks), max(len(vocab), 1)), dtype=np.float32)
    for row, words in enumerate(tokenised):
        for word in words:
            matrix[row, vocab[word]] += 1.0
    matrix = _normalize(matrix)

    def encode(query: str) -> np.ndarray:
        vector = np.zeros((1, max(len(vocab), 1)), dtype=np.float32)
        for word in _tokens(query):
            if word in vocab:
                vector[0, vocab[word]] += 1.0
        return _normalize(vector)[0]

    return {"backend": "keyword", "vectors": matrix, "encode": encode}


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z]{3,}", str(text).lower())


def _normalize(matrix: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return matrix / norms


# ===========================================================================
# INDEX
# ===========================================================================

def _load_cache(fingerprint: str):
    """Reuse cached vectors when the knowledge base has not changed."""
    try:
        if not (config.EMBEDDINGS_CACHE.exists() and config.CHUNKS_CACHE.exists()):
            return None
        meta = json.loads(config.CHUNKS_CACHE.read_text(encoding="utf-8"))
        if meta.get("fingerprint") != fingerprint:
            return None
        vectors = np.load(config.EMBEDDINGS_CACHE)
        if len(vectors) != len(meta.get("chunks", [])):
            return None
        return meta, vectors
    except Exception:
        return None                      # a corrupt cache is not an error


def _save_cache(fingerprint: str, chunks, vectors, backend: str) -> None:
    try:
        config.CACHE_DIR.mkdir(parents=True, exist_ok=True)
        np.save(config.EMBEDDINGS_CACHE, vectors)
        config.CHUNKS_CACHE.write_text(json.dumps({
            "fingerprint": fingerprint, "backend": backend, "chunks": chunks,
        }), encoding="utf-8")
    except Exception:
        pass                             # caching is an optimisation, not a
                                         # requirement -- never fail on it


def build_index(force: bool = False) -> dict:
    """
    Build or reuse the retrieval index. Never raises.

    Returns the index dict, or one with an empty chunk list if the knowledge
    base is missing -- callers treat that as "no information available",
    which is the correct behaviour rather than a crash.
    """
    if _state and not force:
        return _state

    chunks = load_chunks()
    if not chunks:
        _state.update({"chunks": [], "vectors": None, "backend": "none",
                       "encode": None, "error": "knowledge_base/ is empty"})
        return _state

    fingerprint = _kb_fingerprint(chunks)

    # Record why each backend was skipped. A silent fallback chain hides
    # real bugs: a bad argument to TfidfVectorizer once made this module
    # quietly downgrade to the keyword backend, and retrieval quality
    # collapsed with no error anywhere. attempts[] makes that visible.
    attempts: list[str] = []

    for builder in (_try_sentence_transformers, _try_tfidf, _try_keyword):
        try:
            built = builder(chunks)
        except ImportError as exc:
            attempts.append(f"{builder.__name__}: not installed ({exc})")
            continue
        except Exception as exc:
            attempts.append(f"{builder.__name__}: {type(exc).__name__}: {exc}")
            continue
        # only the expensive backend is worth caching to disk
        if built["backend"] == "sentence-transformers" and not force:
            cached = _load_cache(fingerprint)
            if cached:
                meta, vectors = cached
                built["vectors"] = vectors
                chunks = meta["chunks"]
            else:
                _save_cache(fingerprint, chunks, built["vectors"], built["backend"])

        _state.update({"chunks": chunks, "vectors": built["vectors"],
                       "backend": built["backend"], "encode": built["encode"],
                       "word_dim": built.get("word_dim"), "error": "",
                       "attempts": attempts})
        return _state

    _state.update({"chunks": chunks, "vectors": None, "backend": "none",
                   "encode": None, "attempts": attempts,
                   "error": "no retrieval backend available"})
    return _state


def rebuild_cache() -> int:
    """Force a rebuild. Returns the number of chunks indexed."""
    _state.clear()
    return len(build_index(force=True)["chunks"])


def backend_name() -> str:
    return build_index()["backend"]


def backend_attempts() -> list[str]:
    """Why the better backends were skipped. Empty means the best one ran."""
    return list(build_index().get("attempts") or [])


def chunk_count() -> int:
    return len(build_index()["chunks"])


# ===========================================================================
# RETRIEVAL
# ===========================================================================

def retrieve(query: str, k: int = None,
             min_similarity: float = None) -> list[dict]:
    """
    Top matching passages above the similarity floor. Never raises.

    Each hit is {text, heading, source, similarity}. An empty list means we
    do not know, and the caller must say so rather than guess.
    """
    k = k or config.RAG_TOP_K
    clean = utils.clean_text(query, 400)
    if not clean:
        return []

    index = build_index()
    if index["vectors"] is None or not index["chunks"]:
        return []

    # The floor depends on which backend is running -- see the comment on
    # RAG_SIMILARITY_FLOORS in config.py.
    if min_similarity is None:
        floor = config.RAG_SIMILARITY_FLOORS.get(
            index["backend"], config.RAG_MIN_SIMILARITY)
    else:
        floor = min_similarity

    try:
        vector = index["encode"](clean)
        scores = index["vectors"] @ vector
    except Exception:
        return []

    # Term-overlap gate, for the hybrid TF-IDF backend only.
    word_scores = None
    word_dim = index.get("word_dim")
    if word_dim:
        word_scores = (index["vectors"][:, :word_dim] @ vector[:word_dim]) * 2.0

    order = np.argsort(scores)[::-1][:k]
    hits = []
    for position in order:
        similarity = float(scores[position])
        if similarity < floor:
            continue
        if word_scores is not None and float(word_scores[position]) < WORD_OVERLAP_GATE:
            continue
        chunk = index["chunks"][int(position)]
        hits.append({
            "text": chunk["text"],
            "heading": chunk.get("heading", ""),
            "source": chunk.get("source", ""),
            "similarity": round(similarity, 3),
        })
    return hits


# ===========================================================================
# ROUTING -- when should RAG run at all?
# ===========================================================================
# Running retrieval on every message would waste time and, worse, would tempt
# the model to answer "my sink is blocked" with a paragraph about the
# cancellation policy. So retrieval only runs when the message looks like a
# question about the service rather than a description of a broken thing.

_POLICY_TERMS = [
    r"\bpolic(?:y|ies)\b", r"\bcancel", r"\breschedul", r"\brefund",
    r"\bwarrant(?:y|ies)\b", r"\bguarantee\b", r"\bhours?\b", r"\btiming",
    r"\bopen(?:ing)?\b", r"\bclosed?\b", r"\bsunday\b", r"\bholiday\b",
    r"\bcharge[sd]?\b", r"\bfees?\b", r"\bpayment\b", r"\bpay\b",
    r"\bprice list\b", r"\bhow much\b", r"\bcost\b",
    r"\bareas?\b", r"\bcover\b", r"\bserve\b", r"\bavailable in\b",
    r"\bhow (?:do|does|can) (?:i|you|it)\b", r"\bhow (?:are|is)\b",
    r"\bwhat (?:are|is) your\b", r"\bdo you\b", r"\bcan i\b",
    r"\bcomplain", r"\bprivacy\b", r"\bdata\b", r"\bsafe\b", r"\bverified?\b",
    r"\bbackground check\b", r"\btime slots?\b", r"\bslot\b",
]

# If the message clearly describes a fault, it is a service request, not a
# policy question, even if it happens to contain a word like "cost".
_PROBLEM_TERMS = [
    r"\bmy\b.{0,20}\b(?:is|isn't|is not|has|won't|will not|keeps?)\b",
    r"\bleak", r"\bblocked\b", r"\bbroken\b", r"\bnot working\b",
    r"\bnot cooling\b", r"\bstopped\b", r"\bmaking a noise\b",
]


def is_policy_question(text: str) -> bool:
    """True when the message is asking about the service rather than reporting a fault."""
    clean = utils.clean_text(text, 400).lower()
    if not clean:
        return False
    if any(re.search(p, clean) for p in _PROBLEM_TERMS):
        return False
    return any(re.search(p, clean) for p in _POLICY_TERMS)


# ===========================================================================
# FORMATTING
# ===========================================================================

def format_context(hits: list[dict]) -> str:
    """
    Retrieved passages as a block for the system prompt.

    The instruction matters as much as the passages: without it a model will
    happily blend the reference material with its own assumptions about how
    home service companies usually work.
    """
    if not hits:
        return ""
    blocks = []
    for hit in hits:
        label = f"{hit['source']}"
        if hit.get("heading"):
            label += f" \u2014 {hit['heading']}"
        blocks.append(f"[{label}]\n{hit['text']}")
    return (
        "\n\nREFERENCE INFORMATION about this service, retrieved from the "
        "company knowledge base. Answer the customer's question using ONLY "
        "what is written here. If it does not contain the answer, say you do "
        "not have that information rather than guessing.\n\n"
        + "\n\n".join(blocks)
    )


def answer_from_kb(hits: list[dict]) -> str:
    """
    A direct answer built from the passages, used when the model is offline.

    This is what keeps the RAG feature demonstrable with no API key: the
    retrieval half works on its own, and the passage is shown as written
    rather than paraphrased by anything.
    """
    if not hits:
        return (
            "I do not have that information in my knowledge base. You can ask "
            "about working hours, service areas, pricing, cancellations or the "
            "workmanship guarantee."
        )
    top = hits[0]
    heading = f"**{top['heading']}**\n\n" if top.get("heading") else ""
    return f"{heading}{top['text']}"


def sources_line(hits: list[dict]) -> str:
    """A short provenance note for the UI."""
    if not hits:
        return ""
    seen = []
    for hit in hits:
        label = hit["heading"] or hit["source"]
        if label not in seen:
            seen.append(label)
    return "Answered from: " + ", ".join(seen[:3])


# ===========================================================================
# Self-check: python -m src.rag
# ===========================================================================
if __name__ == "__main__":
    count = rebuild_cache()
    print(f"backend: {backend_name()}   chunks indexed: {count}")
    for note in backend_attempts():
        print(f"  skipped {note[:100]}")
    print()

    questions = [
        "what are your working hours",
        "can I cancel my booking",
        "do you work on Sundays",
        "which areas do you cover",
        "is there a warranty on the repair",
        "how do I pay",
        "my kitchen sink is blocked",          # a fault, not a policy question
        "what is the capital of France",       # nothing in the knowledge base
    ]
    for question in questions:
        routed = is_policy_question(question)
        hits = retrieve(question) if routed else []
        if not routed:
            print(f"{question!r}\n    -> not a policy question, retrieval skipped")
        elif hits:
            print(f"{question!r}\n    -> {hits[0]['heading']} "
                  f"({hits[0]['similarity']:.2f}) from {hits[0]['source']}")
        else:
            print(f"{question!r}\n    -> nothing above the similarity floor")
