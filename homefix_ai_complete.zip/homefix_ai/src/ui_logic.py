"""
src/ui_logic.py
===============
Everything the interface needs to DECIDE or FORMAT, with no Gradio import.

Why this file exists: Gradio cannot be imported in every environment (it is
not installed in some CI sandboxes, and it pulls a large dependency tree).
Keeping the logic here means the behaviour of the UI is unit-testable with
plain Python, and app.py becomes a thin wiring layer that only lays out
components and connects them to these functions.

Rule for this module: takes plain values, returns plain values. Strings,
dicts, lists and DataFrames only. If a function needs a Gradio object, it
belongs in app.py instead.

Public API is grouped by tab:
    startup_banner()                 -> str      (shown on every tab)
    home_markdown()                  -> str
    about_markdown()                 -> str
    browse_providers(...)            -> (DataFrame, str)
    provider_cards_html(df)          -> str
    dashboard_table(status)          -> (DataFrame, str)
    dashboard_summary()              -> str

Imports from: config, database, provider_matching, safety, utils
Used by: app.py
"""

from __future__ import annotations

import pandas as pd

from . import analytics, config, database, provider_matching as pm, safety, utils

DASHBOARD_COLUMNS = ["Request ID", "Customer", "Service", "Provider",
                     "Area", "Date", "Time", "Status"]

BROWSE_COLUMNS = ["Provider", "Service", "Area", "Rating", "Price range",
                  "Available", "Experience"]


# ===========================================================================
# STARTUP BANNER
# ===========================================================================

def startup_banner() -> str:
    """
    One line at the top of the app describing the state of the system.

    Three things a user or examiner needs to know immediately: is the AI
    connected, is the data loaded, and will anything they do survive the
    session. Failing silently on any of these is how a demo goes wrong in
    front of an audience.
    """
    health = database.data_health()
    ai_on = config.ai_enabled()

    if health["ok"] and ai_on:
        return (
            f"Ready. {health['providers']} demo providers loaded, "
            f"{health['requests']} requests on file."
        )

    notes = []
    if not ai_on:
        notes.append(
            "The AI assistant is offline because no Groq API key was found. "
            "Problem descriptions will be matched by keyword instead, and "
            "everything else works normally."
        )
    notes.extend(health["problems"])

    lines = ["**Some things need attention:**"]
    lines += [f"- {n}" for n in notes]
    lines.append(
        f"\n{health['providers']} providers and {health['requests']} requests loaded."
    )
    return "\n".join(lines)


# ===========================================================================
# HOME
# ===========================================================================

def home_markdown() -> str:
    return f"""# {config.APP_NAME}

### {config.APP_TAGLINE}

Describe the problem in your own words and the assistant will work out which
trade you need, then show you matching professionals with a clear reason for
each recommendation.

**Try one of these to see how it works:**
"""


def home_footer_markdown() -> str:
    return f"""---

*{config.DEMO_NOTICE}*
"""


# ===========================================================================
# ABOUT
# ===========================================================================

def about_markdown() -> str:
    services = ", ".join(config.SERVICE_CATEGORIES)
    areas = ", ".join(config.AREAS)
    weights = "  \n".join(
        f"- {name.replace('_', ' ').title()}: {points} points"
        for name, points in config.SCORING_WEIGHTS.items()
    )
    return f"""## About {config.APP_NAME}

A student project combining generative AI with business analytics. You
describe a household problem in plain language; the app works out which trade
you need, ranks suitable professionals, and records the request.

### How a request is handled

1. Your message is checked for safety hazards before anything else happens.
2. A language model reads it and fills in a structured summary: the trade
   needed, the item affected, how urgent it is, and your area.
3. That trade is checked against a fixed list of {len(config.SERVICE_CATEGORIES)}
   services, so the assistant cannot invent a category.
4. Matching professionals are scored and ranked by ordinary arithmetic, not
   by the language model.
5. You choose one and submit a request, which is saved with a reference number.

### How professionals are scored

The trade itself is a filter, not a score: a plumber is never offered for an
electrical fault. Everyone in the right trade is then scored out of 100.

{weights}

Every recommendation shows its own breakdown, so you can see exactly why one
professional ranked above another.

### Services and areas

Services: {services}

Areas: {areas}

### Safety

{safety.SAFETY_DISCLAIMER}

### About the data

{config.DEMO_NOTICE}
"""


# ===========================================================================
# FIND A PROFESSIONAL (browse tab)
# ===========================================================================

def browse_providers(category=None, area=None, availability=None,
                     min_rating=None) -> tuple[pd.DataFrame, str]:
    """
    Dropdown-driven browsing, for people who already know what they need.

    No relevance score here on purpose: scoring without a stated problem
    would be meaningless. Sorted by rating instead.
    """
    category = None if category in (None, "", "Any service") else category
    area = None if area in (None, "", "Any area") else area
    availability = None if availability in (None, "", "Any time") else availability
    rating = None if min_rating in (None, "", 0) else min_rating

    df = pm.filter_providers(category=category, area=area,
                             availability=availability, min_rating=rating)

    if df.empty:
        return pd.DataFrame(columns=BROWSE_COLUMNS), (
            "No professionals match those filters. Try widening the area or "
            "lowering the minimum rating."
        )

    table = pd.DataFrame({
        "Provider": df["provider_name"],
        "Service": df["service_category"],
        "Area": df["area"],
        "Rating": df["rating"].map(lambda r: f"{r:.1f}"),
        "Price range": df.apply(
            lambda r: utils.format_price_range(r["price_min"], r["price_max"]), axis=1),
        "Available": df["availability"],
        "Experience": df["experience_years"].map(lambda y: f"{y} years"),
    })

    count = len(table)
    status = f"{count} {'professional' if count == 1 else 'professionals'} found."
    return table.reset_index(drop=True), status


# ===========================================================================
# PROVIDER CARDS
# ===========================================================================

def provider_card_html(row, rank: int = None, show_score: bool = True) -> str:
    """
    One provider as an HTML card.

    Two rules here. Every user-supplied or dataset value goes through
    escape_html, because these strings are injected as raw HTML. And the
    phone number is masked: requirement F says do not expose unnecessary
    private information, and the full number is only needed after booking.
    """
    row = row.to_dict() if hasattr(row, "to_dict") else dict(row)
    e = utils.escape_html

    name = e(row.get("provider_name", "Unknown"))
    score = row.get("score")
    badge = ""
    if show_score and score is not None:
        badge = f'<span class="hf-score">{score:.0f}<span class="hf-score-max">/100</span></span>'

    position = f'<span class="hf-rank">{rank}</span>' if rank else ""

    reason = e(pm.explain_score(row)) if show_score and "why_area" in row else ""
    reason_html = f'<p class="hf-reason">{reason}</p>' if reason else ""

    return f"""
<div class="hf-card">
  <div class="hf-card-head">
    <div>{position}<span class="hf-name">{name}</span></div>
    {badge}
  </div>
  <p class="hf-meta">
    {e(row.get('service_category', ''))} in {e(row.get('area', ''))} &nbsp;|&nbsp;
    {e(utils.star_rating(row.get('rating')))} &nbsp;|&nbsp;
    {e(row.get('experience_years', 0))} years experience
  </p>
  <p class="hf-price">
    Estimated {e(utils.format_price(row.get('estimated_price', 0)))}
    <span class="hf-range">(usual range {e(utils.format_price_range(
        row.get('price_min'), row.get('price_max')))})</span>
  </p>
  <p class="hf-avail">Available {e(row.get('availability', 'on request'))}</p>
  <p class="hf-desc">{e(row.get('description', ''))}</p>
  {reason_html}
</div>
"""


def provider_cards_html(df, show_score: bool = True) -> str:
    """All matching providers as a stack of cards, or an empty-state message."""
    if df is None or (hasattr(df, "empty") and df.empty):
        return (
            '<div class="hf-empty">No professionals to show yet. '
            'Describe your problem and matches will appear here.</div>'
        )
    cards = [
        provider_card_html(row, rank=i, show_score=show_score)
        for i, (_, row) in enumerate(df.iterrows(), start=1)
    ]
    return f'<div class="hf-cards">{"".join(cards)}</div>'


def provider_choices(df) -> list[str]:
    """
    Labels for the selection radio.

    Gradio cannot put a working button inside generated HTML, so selection
    happens in a radio underneath the cards. The label has to be unique and
    human-readable, hence name plus area.
    """
    if df is None or (hasattr(df, "empty") and df.empty):
        return []
    return [f"{row['provider_name']} ({row['area']})" for _, row in df.iterrows()]


def provider_id_from_choice(choice: str, df) -> str | None:
    """Reverse the label back into a provider_id."""
    if not choice or df is None or (hasattr(df, "empty") and df.empty):
        return None
    for _, row in df.iterrows():
        if f"{row['provider_name']} ({row['area']})" == choice:
            return row["provider_id"]
    return None


# ===========================================================================
# DASHBOARD
# ===========================================================================

def dashboard_table(status: str = "All") -> tuple[pd.DataFrame, str]:
    """Every submitted request, newest first, optionally filtered by status."""
    df = database.load_requests()
    if df.empty:
        return pd.DataFrame(columns=DASHBOARD_COLUMNS), (
            "No requests yet. Describe a problem on the AI Assistant tab to "
            "create one."
        )

    if status and status != "All":
        df = df[df["status"] == status]
        if df.empty:
            return pd.DataFrame(columns=DASHBOARD_COLUMNS), (
                f"No requests with the status {status}."
            )

    df = df.sort_values("created_at", ascending=False)
    table = pd.DataFrame({
        "Request ID": df["request_id"],
        "Customer": df["customer_name"],
        "Service": df["service_category"],
        "Provider": df["provider_name"],
        "Area": df["area"],
        "Date": df["preferred_date"],
        "Time": df["preferred_time"],
        "Status": df["status"],
    })
    count = len(table)
    return table.reset_index(drop=True), (
        f"{count} {'request' if count == 1 else 'requests'} shown."
    )


def dashboard_summary() -> str:
    """
    A short headline above the table. The full analytics tab arrives at
    Stage 12; this is the at-a-glance version.
    """
    df = database.load_requests()
    if df.empty:
        return "No requests recorded yet."

    counts = df["status"].value_counts()
    parts = [f"{counts.get(s, 0)} {s.lower()}" for s in config.REQUEST_STATUSES]
    total = len(df)
    return (
        f"**{total} {'request' if total == 1 else 'requests'}** \u2014 "
        + ", ".join(parts)
    )


def status_filter_choices() -> list[str]:
    return ["All"] + list(config.REQUEST_STATUSES)


def analytics_bundle() -> dict:
    """
    Everything the analytics section needs, in one call.

    Gathered together so the dashboard refreshes as a single unit. Four
    separate calls could render a chart against one snapshot of the data and
    a headline figure against another if a booking landed in between.
    """
    return {
        "metrics_md": analytics.metrics_markdown(),
        "insights_md": analytics.insights_markdown(),
        "by_category": analytics.requests_by_category(),
        "by_status": analytics.status_distribution(),
        "by_value": analytics.value_by_category(),
        "over_time": analytics.requests_over_time(),
    }


# ===========================================================================
# AI ASSISTANT - the conversation pipeline
# ===========================================================================
# One function runs the whole turn, so the order of operations is visible in
# one place instead of being spread across Gradio callbacks:
#
#     safety -> language model -> category validation -> provider matching
#
# It returns plain values. app.py turns them into Gradio updates.

MAX_HISTORY = 20          # chat turns kept; the model only sees the last few
NO_MATCH_NOTE = ""


def _blank_turn(slots: dict | None = None) -> dict:
    return {
        "history": [],
        "slots": slots or {},
        "matches": None,
        "summary_md": "_Your problem summary will appear here._",
        "cards_html": provider_cards_html(None),
        "choices": [],
        "note_md": "",
        "reply": "",
        "can_book": False,
    }


def process_message(message: str, history: list | None,
                    slots: dict | None, client=None) -> dict:
    """
    Handle one user message end to end. Never raises.

    Returns a dict with everything the assistant tab needs to redraw:
        history      chat turns for gr.Chatbot (role/content dicts)
        slots        accumulated understanding, carried into the next turn
        matches      ranked DataFrame, or None
        summary_md   the "what the assistant understood" panel
        cards_html   provider cards
        choices      labels for the selection radio
        note_md      explanation above the cards
        can_book     whether a provider can be chosen yet
    """
    from . import ai_assistant, classifier, rag   # imported here to keep the
                                                  # module import graph shallow
    history = list(history or [])
    slots = dict(slots or {})
    clean = utils.clean_text(message, 1000)

    if not clean:
        out = _blank_turn(slots)
        out["history"] = history
        out["reply"] = "Please describe the problem first."
        out["summary_md"] = _summary_markdown(slots)
        return out

    # 1. safety, before anything else and before any API call
    guard = safety.screen(clean)

    # 2. retrieval, but only for questions about the service itself. Running
    #    it on "my sink is blocked" would waste time and tempt the model to
    #    answer a plumbing problem with the cancellation policy.
    kb_hits = []
    if not safety.is_blocked(guard) and rag.is_policy_question(clean):
        kb_hits = rag.retrieve(clean)
    context = rag.format_context(kb_hits)

    # 3. language model (skipped entirely for critical hazards)
    slots = ai_assistant.extract_request_info(clean, history, slots,
                                              client=client, context=context)

    # 4. category validation and the offline keyword fallback
    slots = classifier.resolve(slots, clean)

    slots["rag_used"] = bool(kb_hits)
    slots["rag_sources"] = rag.sources_line(kb_hits)

    # 5. when the model is unavailable, the retrieved passage IS the answer.
    #    Retrieval works with no API key, so the RAG feature stays
    #    demonstrable even when Groq is not reachable.
    #    The safety check has to be repeated here: "there is a gas smell,
    #    what are your hours" is a policy question by wording, and without
    #    this guard the knowledge base answer would overwrite the emergency
    #    message. Caught by the Stage 11 test suite.
    if (not slots.get("ai_used") and rag.is_policy_question(clean)
            and not safety.is_blocked(guard)):
        slots["reply"] = rag.answer_from_kb(kb_hits)

    reply = slots.get("reply") or "Let me see what I can find."

    history = history + [
        {"role": "user", "content": clean},
        {"role": "assistant", "content": reply},
    ]
    history = history[-MAX_HISTORY:]

    out = {
        "history": history,
        "slots": slots,
        "matches": None,
        "summary_md": _summary_markdown(slots),
        "cards_html": provider_cards_html(None),
        "choices": [],
        "note_md": "",
        "reply": reply,
        "can_book": False,
    }

    # 6. a critical hazard means safety first and nothing else. Offering
    #    booking cards under a "there is a gas leak, get out" message would
    #    bury the only part of the response that matters.
    if safety.is_blocked(guard):
        out["note_md"] = (
            "Once everyone is safe, tell me and I will find you a professional."
        )
        return out

    # 7. a policy question was answered from the knowledge base, so there is
    #    nothing to search for and the provenance is worth showing.
    if kb_hits and not slots.get("service_category"):
        out["note_md"] = slots["rag_sources"]
        return out

    # 8. provider matching
    if slots.get("service_category"):
        result = pm.find_providers(slots)
        out["matches"] = result["providers"]
        out["cards_html"] = provider_cards_html(result["providers"])
        out["choices"] = provider_choices(result["providers"])
        out["can_book"] = result["count"] > 0
        # Both lines matter: the first says what was searched, the second
        # only appears when the area could not be honoured in full. Showing
        # the caveat alone loses the context; showing the summary alone
        # hides that some results are out of area.
        note = _match_note(result, slots)
        if result["message"]:
            note = f"{note}\n\n{result['message']}" if note else result["message"]
        out["note_md"] = note
    else:
        out["note_md"] = (
            "I need to know which trade you need before I can search. "
            + (slots.get("follow_up_question") or "")
        ).strip()

    return out


def _match_note(result: dict, slots: dict) -> str:
    """The line above the cards. States what was searched, in plain words."""
    if result["count"] == 0:
        return "No professionals found for that service yet."
    where = f" in {slots['area']}" if slots.get("area") else ""
    urgency = ""
    if slots.get("urgency") in ("urgent", "emergency"):
        urgency = ", prioritising who can come soonest"
    return (
        f"Showing the top {result['count']} of {result['total_in_category']} "
        f"{result['category']} professionals{where}{urgency}."
    )


def _summary_markdown(slots: dict) -> str:
    """The extracted-summary panel, plus how the trade was identified."""
    from . import ai_assistant

    if not slots or not any(slots.get(k) for k in
                            ("service_category", "problem_summary", "area")):
        return "_Your problem summary will appear here._"

    table = ai_assistant.format_slots_markdown(slots)
    reason = slots.get("classifier_reason")
    footer = f"\n\n<small>{utils.escape_html(reason)}</small>" if reason else ""
    return "#### What I understood\n\n" + table + footer


def select_provider(choice: str, matches, slots: dict | None = None) -> dict:
    """
    Turn a radio selection into a chosen provider plus its score breakdown.

    Returns provider=None when nothing valid is selected, so the caller can
    keep the booking button disabled rather than carrying a half-made choice
    into the form.
    """
    blank = {"provider": None, "breakdown_md": "",
             "booking_md": "_No professional selected yet._", "can_book": False}

    provider_id = provider_id_from_choice(choice, matches)
    if not provider_id:
        return blank

    row = None
    if matches is not None and not matches.empty:
        hit = matches[matches["provider_id"] == provider_id]
        if not hit.empty:
            row = hit.iloc[0].to_dict()
    if row is None:
        row = database.get_provider(provider_id)
    if not row:
        return blank

    return {
        "provider": row,
        "breakdown_md": "#### Why this ranking\n\n" + pm.score_breakdown_markdown(row),
        "booking_md": booking_summary_markdown(row, slots),
        "can_book": True,
    }


def booking_summary_markdown(provider: dict, slots: dict | None = None) -> str:
    """The confirmation of choice shown at the top of the booking form."""
    if not provider:
        return "_No professional selected yet._"
    slots = slots or {}
    estimate = utils.format_price(provider.get("estimated_price", 0))
    lines = [
        f"**{provider.get('provider_name')}** \u2014 "
        f"{provider.get('service_category')} in {provider.get('area')}",
        f"{utils.star_rating(provider.get('rating'))} \u00b7 "
        f"{provider.get('experience_years')} years experience \u00b7 "
        f"available {str(provider.get('availability', '')).lower()}",
        f"Estimated cost {estimate}. The final price is agreed with the "
        f"professional after they see the job.",
    ]
    if slots.get("service_category") and \
            slots["service_category"] != provider.get("service_category"):
        lines.append(
            f"\n> Note: you described a {slots['service_category']} problem "
            f"but selected a {provider.get('service_category')}."
        )
    return "\n\n".join(lines)


def reset_conversation() -> dict:
    """Start over. Returns the same shape as process_message."""
    return _blank_turn({})


# ===========================================================================
# BOOKING
# ===========================================================================

def submit_booking(name, phone, area, address, problem, preferred_date,
                   preferred_time, notes, provider, slots=None) -> dict:
    """
    Validate and save one booking request.

    Returns:
        ok           True when the request was written
        request_id   the reference number, or None
        message_md   confirmation, or the list of things to fix
        clear_form   whether the caller should blank the inputs

    Note what is NOT passed through from the form: the price and the
    provider's details. Those are read from the dataset inside
    database.save_request(), so a tampered form field cannot change what
    gets recorded, and the language model has no path to the stored price.
    """
    if not provider:
        return {
            "ok": False, "request_id": None, "clear_form": False,
            "message_md": (
                "Choose a professional first. Describe your problem on the "
                "AI Assistant tab, then pick one of the suggestions."
            ),
        }

    slots = slots or {}
    form = {
        "customer_name": name,
        "phone": phone,
        "area": area,
        "address": address,
        "problem_description": problem or slots.get("problem_summary", ""),
        "service_category": provider.get("service_category"),
        "provider_id": provider.get("provider_id"),
        "preferred_date": preferred_date,
        "preferred_time": preferred_time,
        "notes": notes,
        "urgency": slots.get("urgency", "normal"),
    }

    ok, request_id, error = database.save_request(form)
    if not ok:
        return {"ok": False, "request_id": None, "clear_form": False,
                "message_md": error}

    saved = database.get_request(request_id) or {}
    return {
        "ok": True,
        "request_id": request_id,
        "clear_form": True,
        "message_md": confirmation_markdown(saved, provider),
    }


def confirmation_markdown(saved: dict, provider: dict) -> str:
    """
    What the customer sees after submitting.

    The reference number goes first because it is the one thing they may
    need to write down. The demo disclaimer goes last but is not optional:
    nobody has actually been contacted, and the app must not imply otherwise.
    """
    e = utils.escape_html
    estimate = utils.format_price(saved.get("estimated_price", 0))
    return f"""### Request received

**Reference {e(saved.get('request_id', ''))}**

| | |
| --- | --- |
| Professional | {e(saved.get('provider_name', ''))} |
| Service | {e(saved.get('service_category', ''))} |
| Date | {e(saved.get('preferred_date', ''))} |
| Time | {e(saved.get('preferred_time', ''))} |
| Area | {e(saved.get('area', ''))} |
| Estimated cost | {e(estimate)} |
| Status | {e(saved.get('status', ''))} |

The request is saved with the status *{e(saved.get('status', 'Pending'))}*. You
can see it on the Dashboard tab. The estimate is based on
{e(provider.get('provider_name', 'the professional'))}'s usual price range; the
final cost is agreed once they have seen the job.

*This is an academic demonstration. No professional has been contacted and no
real booking exists.*
"""


# ===========================================================================
# DASHBOARD ACTIONS
# ===========================================================================

def request_id_choices() -> list[str]:
    """Reference numbers for the status dropdown, newest first."""
    df = database.load_requests()
    if df.empty:
        return []
    return list(df.sort_values("created_at", ascending=False)["request_id"])


def change_status(request_id: str, status: str) -> str:
    """
    Move a request between the four demo statuses.

    Real dispatch software would drive this from the professional's app.
    Here it is a manual control so the status distribution chart in the
    analytics tab has something to show.
    """
    if not request_id:
        return "Choose a request reference first."
    if not status:
        return "Choose a status."

    ok, error = database.update_request_status(request_id, status)
    if not ok:
        return error
    return f"{request_id} is now {status}."
