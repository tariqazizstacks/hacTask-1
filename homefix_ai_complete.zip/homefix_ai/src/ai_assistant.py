"""
src/ai_assistant.py
===================
The only module that talks to Groq.

Its job is narrow on purpose: turn free text into a validated SLOT DICT.
It does not choose providers, does not quote prices, does not confirm
bookings. Those are all deterministic Python elsewhere. The LLM handles
language; the app handles facts (requirement K).

Flow of one turn:

    user text
       |
       v
    safety.screen()            <- runs FIRST, no API call yet
       |
       +-- critical hazard? --> return safety response, LLM never called
       |
       v
    Groq chat completion in JSON mode  (retry -> fallback model)
       |
       v
    _parse_json()              <- tolerates ```json fences and stray prose
       |
       v
    harden_slots()             <- nothing from the LLM is trusted as-is
       |
       v
    merge_slots()              <- accumulate across conversation turns
       |
       v
    validated slot dict --> classifier.py --> provider_matching.py

Public API:
    build_system_prompt(safety_result=None)     -> str
    extract_request_info(text, history, previous_slots, client=None) -> dict
    harden_slots(raw, safety_result, previous)  -> dict
    merge_slots(previous, new)                  -> dict
    empty_slots()                               -> dict
    format_slots_markdown(slots)                -> str
    health_check(client=None)                   -> (bool, str)

Imports from: config.py, utils.py, safety.py, database.py
Used by: classifier.py, app.py
"""

from __future__ import annotations

import json
import re

from . import config, database, safety, utils

# ===========================================================================
# SLOT SHAPE
# ===========================================================================
# Every consumer of this module can rely on these keys always being present.
# The meta_ fields are bookkeeping for the UI, not data about the problem.

SLOT_KEYS = (
    "service_category", "problem_summary", "object", "symptoms", "urgency",
    "area", "preferred_date", "preferred_time", "missing_info",
    "follow_up_question", "reply", "safety_flag", "confidence", "in_scope",
)

SAFETY_FLAGS = ("none", "electrical", "gas", "fire", "water", "structural", "other")


def empty_slots() -> dict:
    return {
        "service_category": None,
        "problem_summary": "",
        "object": None,
        "symptoms": [],
        "urgency": "normal",
        "area": None,
        "preferred_date": None,
        "preferred_time": None,
        "missing_info": [],
        "follow_up_question": None,
        "reply": "",
        "safety_flag": "none",
        "confidence": 0.0,
        "in_scope": True,
        # --- meta ---
        "ai_used": False,          # did a Groq call actually succeed?
        "model": None,             # which model answered
        "category_source": None,   # "llm" | "safety_hint" | "keyword_fallback"
        "needs_keyword_fallback": False,
        "error": "",
        "safety_tier": 3,
    }


# ===========================================================================
# SYSTEM PROMPT
# ===========================================================================

def _category_block() -> str:
    """
    Build the category list from services.csv, including keywords as hints.

    Generated rather than hardcoded so the prompt, the validator and the
    dataset can never disagree. Add a 9th service to services.csv and the
    prompt updates itself.
    """
    services = database.load_services()
    if services.empty:
        return "\n".join(f"- {c}" for c in config.SERVICE_CATEGORIES)

    lines = []
    for _, row in services.iterrows():
        hints = ", ".join(str(row.get("keywords", "")).split(",")[:8])
        lines.append(f'- "{row["service_category"]}" \u2014 e.g. {hints}')
    return "\n".join(lines)


def build_system_prompt(safety_result: dict | None = None,
                        context: str = "") -> str:
    """
    The system prompt. Requirement K, written as hard constraints.

    The word "JSON" appears deliberately and repeatedly: Groq's JSON mode
    rejects a request whose prompt never mentions JSON.
    """
    prompt = f"""You are the intake assistant for {config.APP_NAME}, a home services booking app.

YOUR ONLY JOB: read what the customer says and return a single JSON object describing their problem. You are an intake assistant, not a technician and not a search engine.

SERVICE CATEGORIES (you MUST use one of these exact strings, or null):
{_category_block()}

SERVICE AREAS: {", ".join(config.AREAS)}

TIME SLOTS: {" | ".join(config.TIME_SLOTS)}

ABSOLUTE RULES:
1. Never invent a service category. If the problem does not clearly fit one of the categories above, set service_category to null.
2. Never mention, invent or guess a provider, company, technician name, price, rating or availability. You have no access to that data. The application supplies it after you respond.
3. Never say a booking is made, confirmed or scheduled. Only the application confirms bookings.
4. Never give step-by-step repair instructions for electrical, gas, structural or appliance work. Recommend a qualified professional instead.
5. Never claim to be a certified technician, engineer or licensed tradesperson.
6. If you do not know something, leave the field null rather than guessing.
7. Ask AT MOST ONE follow-up question per turn, and only when the missing information genuinely changes which professional is needed or when they can come. Do not ask for information the customer has already given.
8. Understand informal, misspelled and mixed English/Urdu text. Reply in the same language style the customer used.

REPLY STYLE: one or two short sentences, warm and practical. No bullet lists. No markdown headings.

RETURN JSON ONLY. No preamble, no explanation, no markdown code fences. The JSON object must have exactly these keys:

{{
  "service_category": "<one exact category string above, or null>",
  "problem_summary": "<one short sentence in your own words>",
  "object": "<the device or thing affected, or null>",
  "symptoms": ["<short symptom>", "..."],
  "urgency": "<emergency | urgent | normal>",
  "area": "<one of the service areas, or null>",
  "preferred_date": "<YYYY-MM-DD, or null>",
  "preferred_time": "<one exact time slot string above, or null>",
  "missing_info": ["<field name you still need>", "..."],
  "follow_up_question": "<one short question, or null>",
  "reply": "<your one or two sentence message to the customer>",
  "safety_flag": "<none | electrical | gas | fire | water | structural | other>",
  "confidence": <number between 0 and 1>,
  "in_scope": <true if this is a home service request, false otherwise>
}}

URGENCY GUIDE: "emergency" only for danger to people or active property damage. "urgent" for no water, no power, no cooling in extreme heat, or a household that cannot function. "normal" for everything else, including painting, cleaning and general repairs.

IN_SCOPE: set false for anything that is not a home service request (homework, general chat, coding, medical questions). When in_scope is false, put a brief polite redirect in "reply" and set service_category to null."""

    # Stage 4 hook: the safety override, when a hazard was detected.
    # Stage 11 hook: retrieved knowledge-base passages, when the customer
    # asked about the service rather than reporting a fault.
    return prompt + safety.system_note(safety_result or {}) + (context or "")


# ===========================================================================
# GROQ CALL
# ===========================================================================

class LLMUnavailable(Exception):
    """Raised internally when every model attempt failed. Never escapes."""


_client_cache = {}


def _get_client():
    """
    Lazy singleton. Importing this module must never require a key or a
    network connection -- app.py imports it at startup regardless.
    """
    if "client" in _client_cache:
        return _client_cache["client"]

    key = config.get_api_key()
    if not key:
        raise LLMUnavailable("No GROQ_API_KEY found.")
    try:
        from groq import Groq
    except ImportError as exc:
        raise LLMUnavailable(f"The groq package is not installed: {exc}") from exc

    client = Groq(api_key=key, timeout=config.GROQ_TIMEOUT)
    _client_cache["client"] = client
    return client


def reset_client() -> None:
    """Drop the cached client. Use after changing the API key at runtime."""
    _client_cache.pop("client", None)


def _scrub(message: str) -> str:
    """
    Strip anything that looks like an API key out of an error message before
    it reaches the screen. Groq errors can echo request headers, and a Gradio
    app with share=True is a public URL.
    """
    text = str(message)
    text = re.sub(r"gsk_[A-Za-z0-9]{8,}", "[REDACTED_API_KEY]", text)
    key = config.get_api_key()
    if key:
        text = text.replace(key, "[REDACTED_API_KEY]")
    return text[:300]


def _complete(messages: list[dict], client=None) -> tuple[str, str]:
    """
    Call Groq with the primary model, then the fallback model.

    Returns (content, model_used). Raises LLMUnavailable if all attempts fail.

    Why a second model rather than a second attempt at the first: the most
    common failure in a free-tier demo is a rate limit on the big model, and
    retrying it immediately hits the same limit. The 8B model has separate
    headroom and is fast enough that nobody notices the downgrade.
    """
    client = client or _get_client()
    attempts = [config.GROQ_MODEL] * (1 + config.GROQ_MAX_RETRIES)
    attempts.append(config.GROQ_FALLBACK_MODEL)

    last_error = "unknown error"
    for model in attempts:
        try:
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=config.GROQ_TEMPERATURE,
                max_tokens=config.GROQ_MAX_TOKENS,
                response_format={"type": "json_object"},
            )
            content = response.choices[0].message.content
            if content and content.strip():
                return content, model
            last_error = "the model returned an empty response"
        except Exception as exc:
            last_error = _scrub(exc)
    raise LLMUnavailable(last_error)


# ===========================================================================
# JSON PARSING
# ===========================================================================

def _parse_json(content: str) -> dict:
    """
    Recover a JSON object from the model's reply.

    JSON mode makes bare JSON overwhelmingly likely, but not certain --
    models still occasionally wrap output in ```json fences or add a
    sentence before it. Three strategies, cheapest first.
    """
    text = (content or "").strip()
    if not text:
        raise ValueError("empty response")

    try:                                        # 1. it is already clean JSON
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if fenced:                                  # 2. wrapped in code fences
        try:
            return json.loads(fenced.group(1))
        except json.JSONDecodeError:
            pass

    braced = re.search(r"\{.*\}", text, re.DOTALL)
    if braced:                                  # 3. buried in prose
        try:
            return json.loads(braced.group(0))
        except json.JSONDecodeError:
            pass

    raise ValueError("no JSON object found in the response")


# ===========================================================================
# HARDENING
# ===========================================================================
# Nothing the LLM returns is trusted. Every field is coerced to the right
# type, clamped to the allowed values, or dropped. This function is the
# boundary between "a language model said so" and "the app believes it".

def _as_list(value, limit: int = 6) -> list[str]:
    """Models return strings where a list was asked for, and vice versa."""
    if value is None:
        return []
    if isinstance(value, str):
        parts = [p.strip() for p in re.split(r"[,;\n]", value) if p.strip()]
        return [utils.clean_text(p, 80) for p in parts][:limit]
    if isinstance(value, (list, tuple)):
        out = [utils.clean_text(v, 80) for v in value if utils.clean_text(v)]
        return out[:limit]
    return [utils.clean_text(value, 80)]


def _as_float(value, default: float = 0.0) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default


def harden_slots(raw: dict, safety_result: dict | None = None,
                 previous: dict | None = None) -> dict:
    """
    Validate and clamp one raw LLM payload into a trustworthy slot dict.

    Order matters at the end: the safety guard's findings override the LLM's,
    because the guard is deterministic and the LLM is not.
    """
    slots = empty_slots()
    raw = raw if isinstance(raw, dict) else {}

    # -- service category: must be an exact member of the controlled list
    category = utils.clean_text(raw.get("service_category"), 50)
    if category in config.SERVICE_CATEGORIES:
        slots["service_category"] = category
        slots["category_source"] = "llm"
    else:
        # A near-miss ("Plumbing", "AC technician") is common. Try a
        # case-insensitive match before giving up -- but never invent.
        lowered = category.lower()
        match = next(
            (c for c in config.SERVICE_CATEGORIES if c.lower() == lowered), None
        )
        if match:
            slots["service_category"] = match
            slots["category_source"] = "llm"
        else:
            slots["service_category"] = None
            slots["needs_keyword_fallback"] = True

    # -- free text
    slots["problem_summary"] = utils.clean_text(raw.get("problem_summary"), 200)
    slots["object"] = utils.clean_text(raw.get("object"), 60) or None
    slots["reply"] = utils.clean_text(raw.get("reply"), 400)
    slots["follow_up_question"] = utils.clean_text(
        raw.get("follow_up_question"), 200) or None

    # -- lists
    slots["symptoms"] = _as_list(raw.get("symptoms"))
    slots["missing_info"] = _as_list(raw.get("missing_info"))

    # -- enums
    urgency = utils.clean_text(raw.get("urgency"), 20).lower()
    slots["urgency"] = urgency if urgency in config.URGENCY_LEVELS else "normal"

    flag = utils.clean_text(raw.get("safety_flag"), 20).lower()
    slots["safety_flag"] = flag if flag in SAFETY_FLAGS else "none"

    # -- area: run through the same normaliser the user's own input uses
    slots["area"] = utils.normalize_area(raw.get("area"))

    # -- date: only accept a real, in-range ISO date
    raw_date = utils.clean_text(raw.get("preferred_date"), 20)
    if raw_date:
        ok, _ = utils.validate_date(raw_date)
        slots["preferred_date"] = raw_date[:10] if ok else None

    # -- time slot: must be one of ours verbatim
    slot_text = utils.clean_text(raw.get("preferred_time"), 60)
    if slot_text in config.TIME_SLOTS:
        slots["preferred_time"] = slot_text
    else:
        lowered = slot_text.lower()
        slots["preferred_time"] = next(
            (s for s in config.TIME_SLOTS if s.lower() == lowered), None
        )

    # -- numbers and booleans
    slots["confidence"] = _as_float(raw.get("confidence"))
    in_scope = raw.get("in_scope")
    slots["in_scope"] = bool(in_scope) if isinstance(in_scope, bool) else True

    # -- safety guard wins over the model ------------------------------
    if safety_result and safety_result.get("tier", 3) != 3:
        slots["safety_tier"] = safety_result["tier"]
        if safety_result.get("urgency_override"):
            slots["urgency"] = safety_result["urgency_override"]
        if safety_result.get("hazard") and safety_result["hazard"] in SAFETY_FLAGS:
            slots["safety_flag"] = safety_result["hazard"]
        # a keyword-confident category beats an LLM guess of null
        if not slots["service_category"] and safety_result.get("category_hint"):
            slots["service_category"] = safety_result["category_hint"]
            slots["category_source"] = "safety_hint"
            slots["needs_keyword_fallback"] = False

    if previous:
        slots = merge_slots(previous, slots)
    return slots


def merge_slots(previous: dict, new: dict) -> dict:
    """
    Carry information forward across conversation turns.

    The user says "my AC is leaking", then answers "Islamabad" to the
    follow-up. That second message contains no AC information, so the model
    legitimately returns service_category null for it. Without merging, the
    app would forget the problem the moment the user answers a question.

    Rule: a non-empty new value wins; otherwise keep the previous one.
    Exception: per-turn fields (reply, follow_up_question, confidence and the
    meta fields) always come from the new turn.
    """
    if not previous:
        return dict(new)

    merged = dict(previous)
    per_turn = {"reply", "follow_up_question", "confidence", "ai_used", "model",
                "error", "safety_tier", "category_source",
                "needs_keyword_fallback", "in_scope"}

    for key, value in new.items():
        if key in per_turn:
            merged[key] = value
        elif isinstance(value, list):
            if value:                       # union, preserving order
                combined = list(previous.get(key) or [])
                for item in value:
                    if item not in combined:
                        combined.append(item)
                merged[key] = combined[:8]
        elif key == "urgency":
            # never downgrade urgency within a conversation
            rank = {"emergency": 0, "urgent": 1, "normal": 2}
            old = previous.get("urgency", "normal")
            merged["urgency"] = min([old, value], key=lambda u: rank.get(u, 2))
        elif value not in (None, "", 0.0):
            merged[key] = value

    return merged


# ===========================================================================
# MAIN ENTRY POINT
# ===========================================================================

OFFLINE_REPLY = (
    "I could not reach the AI service just now, so I could not read your "
    "message automatically. You can still pick a service yourself on the "
    "\u201cFind a Professional\u201d tab and I will find matching professionals."
)


def _offline_slots(text: str, safety_result: dict, error: str) -> dict:
    """
    What we return when Groq is unreachable.

    Stage 6 (classifier.py) replaces the null category here with a keyword
    match, so the app stays usable with no API key at all. Until then,
    needs_keyword_fallback is the flag that says "someone else must fill
    this in".
    """
    slots = empty_slots()
    slots["problem_summary"] = utils.clean_text(text, 200)
    slots["reply"] = safety_result.get("message") or OFFLINE_REPLY
    slots["needs_keyword_fallback"] = True
    slots["ai_used"] = False
    slots["error"] = error
    slots["safety_tier"] = safety_result.get("tier", 3)
    if safety_result.get("urgency_override"):
        slots["urgency"] = safety_result["urgency_override"]
    if safety_result.get("category_hint"):
        slots["service_category"] = safety_result["category_hint"]
        slots["category_source"] = "safety_hint"
        slots["needs_keyword_fallback"] = False
    if safety_result.get("hazard") in SAFETY_FLAGS:
        slots["safety_flag"] = safety_result["hazard"]
    return slots


def _history_messages(history, limit: int = 6) -> list[dict]:
    """
    Last few turns, in Groq's message format.

    Capped deliberately: a long chat would otherwise grow the prompt on every
    turn until it hits the token limit mid-demo. Six turns is enough for
    slot-filling follow-ups.
    """
    if not history:
        return []
    out = []
    for item in list(history)[-limit:]:
        if isinstance(item, dict) and item.get("role") in ("user", "assistant"):
            content = utils.clean_text(item.get("content"), 400)
            if content:
                out.append({"role": item["role"], "content": content})
    return out


def extract_request_info(text: str, history=None, previous_slots: dict | None = None,
                         client=None, context: str = "") -> dict:
    """
    Turn one user message into a validated slot dict. NEVER raises.

    `client` exists for testing: pass a stub and the retry, fallback and
    parsing logic can be exercised without a network call or an API key.
    """
    clean = utils.clean_text(text, 1000)
    guard = safety.screen(clean)

    # --- empty input -------------------------------------------------
    if not clean:
        slots = empty_slots()
        slots["reply"] = "Please describe the problem and I will help you find the right professional."
        if previous_slots:
            slots = merge_slots(previous_slots, slots)
        return slots

    # --- Stage 4 gate: critical hazards never reach the LLM ----------
    if safety.is_blocked(guard):
        slots = empty_slots()
        slots["problem_summary"] = clean[:200]
        slots["reply"] = guard["message"]
        slots["urgency"] = guard.get("urgency_override") or "emergency"
        slots["safety_flag"] = guard["hazard"] if guard["hazard"] in SAFETY_FLAGS else "other"
        slots["safety_tier"] = guard["tier"]
        slots["ai_used"] = False
        slots["error"] = ""
        if guard.get("category_hint"):
            slots["service_category"] = guard["category_hint"]
            slots["category_source"] = "safety_hint"
        if previous_slots:
            slots = merge_slots(previous_slots, slots)
        return slots

    # --- normal path -------------------------------------------------
    messages = [{"role": "system",
                 "content": build_system_prompt(guard, context)}]
    messages += _history_messages(history)
    messages.append({"role": "user", "content": clean})

    try:
        content, model = _complete(messages, client=client)
    except LLMUnavailable as exc:
        return _offline_slots(clean, guard, f"AI unavailable: {exc}")

    try:
        raw = _parse_json(content)
    except ValueError as exc:
        return _offline_slots(clean, guard, f"Could not read the AI response: {exc}")

    slots = harden_slots(raw, guard, previous_slots)
    slots["ai_used"] = True
    slots["model"] = model

    # A tier-2 DIY request: show the safety message, not just the model's reply
    if guard["tier"] == 2:
        slots["reply"] = guard["message"] + "\n\n" + (slots["reply"] or "")
        slots["reply"] = slots["reply"].strip()

    if not slots["reply"]:
        slots["reply"] = "Let me find the right professional for that."
    return slots


# ===========================================================================
# PRESENTATION HELPERS
# ===========================================================================

def format_slots_markdown(slots: dict) -> str:
    """
    The 'what the AI understood' panel from the demo script.

    Showing this is the single most effective thing you can do in a viva: it
    makes the extraction step visible instead of magic, and it proves the
    category came from a controlled list.
    """
    if not slots:
        return "_Nothing extracted yet._"

    source = {
        "llm": "AI language model",
        "safety_hint": "safety keyword guard",
        "keyword_fallback": "keyword fallback (AI unavailable)",
    }.get(slots.get("category_source"), "not identified")

    rows = [
        ("Service", slots.get("service_category") or "not identified yet"),
        ("Identified by", source),
        ("Problem", slots.get("problem_summary") or "-"),
        ("Item", slots.get("object") or "-"),
        ("Symptoms", ", ".join(slots.get("symptoms") or []) or "-"),
        ("Urgency", slots.get("urgency", "normal")),
        ("Area", slots.get("area") or "not given yet"),
        ("Preferred date", slots.get("preferred_date") or "not given yet"),
        ("Preferred time", slots.get("preferred_time") or "not given yet"),
        ("Still needed", ", ".join(slots.get("missing_info") or []) or "nothing"),
        ("Confidence", f"{slots.get('confidence', 0):.0%}"),
        ("Model", slots.get("model") or ("offline" if not slots.get("ai_used") else "-")),
    ]
    return "\n".join(f"| {k} | {utils.escape_html(v)} |" for k, v in
                     [("Field", "Value"), ("---", "---")] + rows)


def health_check(client=None) -> tuple[bool, str]:
    """One tiny call to prove the key and model work. Used by Cell 6 and app.py."""
    if not config.get_api_key():
        return False, "No GROQ_API_KEY found. Add it to Colab Secrets or a .env file."
    try:
        content, model = _complete(
            [{"role": "user", "content": 'Reply with this JSON only: {"ok": true}'}],
            client=client,
        )
        return True, f"{model} responded: {content.strip()[:80]}"
    except LLMUnavailable as exc:
        return False, f"Groq is not reachable: {exc}"


# ===========================================================================
# Self-check: python -m src.ai_assistant
# ===========================================================================
if __name__ == "__main__":
    prompt = build_system_prompt()
    print(f"system prompt: {len(prompt)} chars, {len(prompt.split())} words")
    print(f"mentions JSON: {'JSON' in prompt}")
    print(f"lists all 8 categories: "
          f"{all(c in prompt for c in config.SERVICE_CATEGORIES)}")

    ok, message = health_check()
    print(f"\nGroq health: {'OK' if ok else 'FAILED'} - {message}")

    if ok:
        for text in ["My AC is leaking water and isn't cooling",
                     "kitchen sink blocked water not going down"]:
            slots = extract_request_info(text)
            print(f"\n{text!r}")
            print(f"  -> {slots['service_category']} / {slots['urgency']} "
                  f"/ conf {slots['confidence']:.2f} / model {slots['model']}")
            print(f"  -> reply: {slots['reply'][:100]}")
            if slots["follow_up_question"]:
                print(f"  -> asks: {slots['follow_up_question']}")
