"""
test_stage8.py
==============
Tests for src/ui_logic.py and the structure of app.py.

    python test_stage8.py

Two halves.

Sections [1] to [6] test ui_logic directly. That module has no Gradio
import, which is exactly why the UI's behaviour can be tested at all.

Section [7] installs a STUB gradio module into sys.modules and imports
app.py. That proves the layout code runs end to end -- no typos, no
undefined names, no components referenced before they exist. What it cannot
prove is that the real Gradio accepts every argument. Only launching it in
Colab does that, so do run the app before your demo.
"""

import sys
from pathlib import Path

import pandas as pd

sys.path.append(str(Path(__file__).resolve().parent))

from src import config, database, provider_matching as pm, ui_logic

PASSED = 0
FAILED = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  PASS  {label}")
    else:
        FAILED += 1
        print(f"  FAIL  {label} {detail}")


# ===========================================================================
print("\n[1] Startup banner")
# ===========================================================================
banner = ui_logic.startup_banner()
check("banner is produced", isinstance(banner, str) and len(banner) > 10)
check("banner reports the provider count", "32" in banner)
check("banner mentions the offline AI when there is no key",
      config.ai_enabled() or "offline" in banner.lower(), banner[:80])
check("banner never leaks a path", "/home/" not in banner and "\\" not in banner)

# ===========================================================================
print("\n[2] Home and About copy")
# ===========================================================================
home = ui_logic.home_markdown()
check("home shows the app name", config.APP_NAME in home)
check("home shows the tagline", config.APP_TAGLINE in home)
check("home footer carries the demo-data notice",
      "DEMO DATA" in ui_logic.home_footer_markdown().upper())

about = ui_logic.about_markdown()
# Markdown wraps across lines, so collapse whitespace before matching phrases.
about_flat = " ".join(about.lower().split())
check("about lists all 8 services",
      all(c in about for c in config.SERVICE_CATEGORIES))
check("about lists all 6 areas", all(a in about for a in config.AREAS))
check("about explains the scoring weights",
      all(str(v) in about for v in config.SCORING_WEIGHTS.values()))
check("about says the trade is a filter, not a score", "filter" in about_flat)
check("about carries the safety disclaimer", "certified technician" in about)
check("about carries the demo-data notice", "FICTIONAL" in about.upper())
check("about explains that scoring is not done by the model",
      "not by the language model" in about_flat, about_flat[:120])

# ===========================================================================
print("\n[3] Browse tab")
# ===========================================================================
table, note = ui_logic.browse_providers()
check("no filters shows everyone", len(table) == 32, str(len(table)))
check("columns match the declared headers",
      list(table.columns) == ui_logic.BROWSE_COLUMNS)
check("count is reported", "32 professionals" in note, note)

table, note = ui_logic.browse_providers("Plumber")
check("category filter works", len(table) == 4 and set(table["Service"]) == {"Plumber"})

table, _ = ui_logic.browse_providers("Plumber", "Lahore")
check("category and area combine", len(table) == 1)

table, note = ui_logic.browse_providers("Locksmith", "Hyderabad")
check("an impossible combination returns an empty table", table.empty)
check("the empty state suggests what to do next",
      "widening" in note or "lowering" in note, note)
check("the empty table still has the right columns",
      list(table.columns) == ui_logic.BROWSE_COLUMNS)

table, _ = ui_logic.browse_providers("Any service", "Any area", "Any time", 0)
check("the 'Any' sentinel values are treated as no filter", len(table) == 32)

table, _ = ui_logic.browse_providers(min_rating=4.5)
check("minimum rating filter works",
      all(float(r) >= 4.5 for r in table["Rating"]))

table, _ = ui_logic.browse_providers(availability="Today")
check("availability filter works", set(table["Available"]) == {"Today"})

table, _ = ui_logic.browse_providers()
check("prices are formatted for display", table["Price range"].iloc[0].startswith("PKR"))
check("experience is formatted for display", table["Experience"].iloc[0].endswith("years"))
check("no internal ids are exposed in the browse table",
      "provider_id" not in [c.lower() for c in table.columns])
check("no phone numbers are exposed in the browse table",
      not any("phone" in c.lower() for c in table.columns))

# ===========================================================================
print("\n[4] Provider cards")
# ===========================================================================
result = pm.find_providers({"service_category": "AC Technician",
                            "area": "Islamabad", "urgency": "urgent"})
df = result["providers"]

html = ui_logic.provider_cards_html(df)
check("a card is rendered per provider", html.count("hf-card\"") == len(df))
check("the top provider is named", "Capital Climate Care" in html)
check("the score is shown", "92" in html or "93" in html)
check("the rating is shown as stars", "\u2605" in html)
check("the price estimate is shown", "PKR" in html)
check("the score reason is shown", "based in Islamabad" in html)
check("phone numbers are NOT rendered on cards",
      "0300-000" not in html and "phone" not in html.lower())

empty = ui_logic.provider_cards_html(None)
check("no providers gives an empty state", "hf-empty" in empty)
check("the empty state invites an action", "Describe your problem" in empty)
check("an empty DataFrame gives the same empty state",
      "hf-empty" in ui_logic.provider_cards_html(pd.DataFrame()))

hostile = {"provider_name": "<script>alert(1)</script>",
           "description": "Bad & \"quoted\" <b>text</b>",
           "service_category": "Plumber", "area": "Lahore", "rating": 4.0,
           "price_min": 100, "price_max": 200, "estimated_price": 150,
           "availability": "Today", "experience_years": 3}
card = ui_logic.provider_card_html(hostile, show_score=False)
check("HTML in provider data is escaped", "<script>" not in card)
check("the escaped text is still readable", "&lt;script&gt;" in card)
check("quotes are escaped too", "&quot;" in card)

card = ui_logic.provider_card_html(df.iloc[0], rank=1)
check("the rank number is rendered", "hf-rank" in card and ">1<" in card)
check("cards work without a score",
      "hf-score" not in ui_logic.provider_card_html(hostile, show_score=False))

# ===========================================================================
print("\n[5] Provider selection helpers")
# ===========================================================================
choices = ui_logic.provider_choices(df)
check("one choice per provider", len(choices) == len(df))
check("choices are unique", len(set(choices)) == len(choices))
check("choices name the provider and area",
      "Capital Climate Care (Islamabad)" in choices, str(choices))

pid = ui_logic.provider_id_from_choice(choices[0], df)
check("a choice maps back to a provider id", pid == df.iloc[0]["provider_id"])
check("the id resolves in the database", database.get_provider(pid) is not None)
check("an unknown choice maps to None",
      ui_logic.provider_id_from_choice("Nobody (Nowhere)", df) is None)
check("an empty choice maps to None",
      ui_logic.provider_id_from_choice("", df) is None)
check("no providers gives no choices", ui_logic.provider_choices(None) == [])

# ===========================================================================
print("\n[6] Dashboard")
# ===========================================================================
table, note = ui_logic.dashboard_table()
check("seeded requests are listed", len(table) == 15, str(len(table)))
check("columns match the declared headers",
      list(table.columns) == ui_logic.DASHBOARD_COLUMNS)
check("newest request is first",
      table.iloc[0]["Request ID"] in set(database.load_requests()["request_id"]))
check("the count is reported", "15 requests" in note, note)

table, note = ui_logic.dashboard_table("Pending")
check("status filter works", set(table["Status"]) == {"Pending"})

table, note = ui_logic.dashboard_table("Cancelled")
check("a rare status still returns rows", len(table) >= 1)

check("every status option is offered",
      ui_logic.status_filter_choices() == ["All"] + list(config.REQUEST_STATUSES))

summary = ui_logic.dashboard_summary()
check("summary counts the requests", "15" in summary)
check("summary breaks down by status",
      all(s.lower() in summary for s in config.REQUEST_STATUSES))

real_loader = database.load_requests
database.load_requests = lambda: pd.DataFrame(columns=config.REQUEST_COLUMNS)
try:
    table, note = ui_logic.dashboard_table()
    check("an empty request file gives an empty table", table.empty)
    check("the empty state tells the user what to do",
          "AI Assistant" in note, note)
    check("the empty summary does not crash",
          "No requests" in ui_logic.dashboard_summary())
finally:
    database.load_requests = real_loader

# ===========================================================================
print("\n[7] app.py structure - imported against a stub gradio")
# ===========================================================================
# Gradio is not installed in this environment, so a stand-in is injected.
# It accepts any call and any attribute, which is enough to run the layout
# code and catch typos, undefined names and ordering mistakes.

class _Node:
    def __init__(self, name="node"):
        self._name = name
        self.calls = []

    def __call__(self, *args, **kwargs):
        return _Node(self._name)

    def __getattr__(self, item):
        if item.startswith("_"):
            raise AttributeError(item)
        RECORD.setdefault(self._name, []).append(item)
        return _Node(f"{self._name}.{item}")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def __iter__(self):
        return iter([])


RECORD: dict[str, list] = {}
CREATED: list[str] = []


class _FakeGradio:
    def __getattr__(self, item):
        if item.startswith("_"):
            raise AttributeError(item)

        def factory(*args, **kwargs):
            CREATED.append(item)
            if item == "Tab":
                CREATED.append(f"Tab:{kwargs.get('id') or (args[0] if args else '')}")
            return _Node(item)

        return factory


fake = _FakeGradio()
fake.themes = _Node("themes")
sys.modules["gradio"] = fake

try:
    import app  # noqa: E402
    imported = True
    error = ""
except Exception as exc:                      # pragma: no cover
    imported = False
    error = f"{type(exc).__name__}: {exc}"

check("app.py imports and builds without error", imported, error)

if imported:
    check("a Blocks container is created", "Blocks" in CREATED)
    check("six tabs are created", CREATED.count("Tab") == 6,
          str(CREATED.count("Tab")))
    for tab_id in ["home", "assistant", "browse", "booking", "dashboard", "about"]:
        check(f"tab '{tab_id}' exists", f"Tab:{tab_id}" in CREATED)

    check("four State objects are created", CREATED.count("State") == 4,
          str(CREATED.count("State")))
    check("a Chatbot is created", "Chatbot" in CREATED)
    check("two Dataframes are created", CREATED.count("Dataframe") == 2)
    check("a Radio is used for provider selection", "Radio" in CREATED)
    check("the booking form has text inputs", CREATED.count("Textbox") >= 6)
    check("example prompt buttons are created",
          CREATED.count("Button") >= len(config.EXAMPLE_PROMPTS))
    check("a theme is configured", "Base" in RECORD.get("themes", []))
    check("a Google font is requested", "GoogleFont" in RECORD.get("themes", []))

    check("build_ui is defined", callable(getattr(app, "build_ui", None)))
    check("a module-level demo object exists", getattr(app, "demo", None) is not None)
    for handler in ["on_browse", "on_dashboard_refresh", "on_example_click"]:
        check(f"handler {handler} is defined", callable(getattr(app, handler, None)))

    # the live handlers must work on real data, stub or no stub
    table, note = app.on_browse("Plumber", "Any area", "Any time", 0)
    check("on_browse returns a table and a note", len(table) == 4 and bool(note))

    # This signature has grown twice: Stage 10 added the request-reference
    # dropdown, Stage 12 added the six analytics outputs.
    dash = app.on_dashboard_refresh("All")
    check("on_dashboard_refresh returns ten values", len(dash) == 10, str(len(dash)))
    check("on_dashboard_refresh returns the table and headline",
          len(dash[0]) == 15 and bool(dash[2]))

    text, _ = app.on_example_click("My AC isn't cooling.")
    check("on_example_click passes the prompt through",
          text == "My AC isn't cooling.")

    css = app._load_css()
    check("the stylesheet is found and loaded", len(css) > 500, f"{len(css)} chars")
    check("the stylesheet defines the card styles", ".hf-card" in css)
    check("a missing stylesheet would not crash the app",
          isinstance(app._load_css(), str))

# ===========================================================================
print(f"\n{'=' * 46}")
print(f"  {PASSED} passed, {FAILED} failed")
print(f"{'=' * 46}\n")
sys.exit(1 if FAILED else 0)
