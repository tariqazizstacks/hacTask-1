"""
test_stage11.py
===============
Tests for src/rag.py and its place in the conversation pipeline.

    python test_stage11.py

Section [3] is the one to read: retrieval must return NOTHING for questions
the knowledge base does not answer. A retriever that always returns its best
guess is worse than no retriever, because the model will treat whatever comes
back as authoritative and state it as company policy.
"""

import json
import sys
from pathlib import Path
from types import SimpleNamespace

sys.path.append(str(Path(__file__).resolve().parent))

from src import config, rag, ui_logic

PASSED = 0
FAILED = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"  PASS  {label}")
    else:
        FAILED += 1
        print(f"  FAIL  {label} {detail}")


class Stub:
    def __init__(self, *payloads):
        self.payloads = list(payloads)
        self.prompts = []
        outer = self

        class _C:
            def create(self, **kwargs):
                outer.prompts.append(kwargs["messages"][0]["content"])
                item = outer.payloads.pop(0) if outer.payloads else {"reply": "ok"}
                if isinstance(item, Exception):
                    raise item
                return SimpleNamespace(choices=[SimpleNamespace(
                    message=SimpleNamespace(content=json.dumps(item)))])

        self.chat = SimpleNamespace(completions=_C())


# ===========================================================================
print("\n[1] Knowledge base and index")
# ===========================================================================
files = sorted(p.name for p in config.KB_DIR.glob("*.txt"))
check("three knowledge base files exist",
      files == ["faq.txt", "policies.txt", "services.txt"], str(files))

chunks = rag.load_chunks()
check("the knowledge base splits into chunks", len(chunks) > 20, str(len(chunks)))
check("every chunk records its source",
      all(c["source"].endswith(".txt") for c in chunks))
check("every chunk records its heading", all(c["heading"] for c in chunks))
check("no chunk is trivially short",
      all(len(c["text"]) >= rag.MIN_CHUNK_CHARS for c in chunks))
check("no chunk is oversized",
      all(len(c["text"]) <= rag.MAX_CHUNK_CHARS for c in chunks))
check("headings are not left in the body text",
      not any(c["text"].startswith("#") for c in chunks))

count = rag.rebuild_cache()
check("the index builds", count == len(chunks))
check("a backend was selected", rag.backend_name() in
      ("sentence-transformers", "tfidf", "keyword"), rag.backend_name())
check("a floor is configured for the active backend",
      rag.backend_name() in config.RAG_SIMILARITY_FLOORS)

# every requirement-I topic must actually be present in the knowledge base
kb_text = " ".join(c["text"].lower() + " " + c["heading"].lower() for c in chunks)
for topic in ["working hours", "cancel", "guarantee", "area", "price",
              "privacy", "complaint", "time slot"]:
    check(f"knowledge base covers: {topic}", topic in kb_text)

# ===========================================================================
print("\n[2] Retrieval finds the right section")
# ===========================================================================
expected = {
    "what are your working hours": "Working hours",
    "do you work on Sundays": "Working hours",
    "can I cancel my booking": "Cancellation policy",
    "what happens if I cancel late": "Cancellation policy",
    "is there a warranty on the repair": "Workmanship guarantee",
    "how do I pay": "Do I pay through the app?",
    "what are the time slots": "Time slots",
    "do you cover Karachi": "Service areas",
    "is my information shared": "Is my information shared with anyone?",
    "how do I make a complaint": "Complaints",
}
for question, heading in expected.items():
    hits = rag.retrieve(question)
    got = hits[0]["heading"] if hits else "nothing"
    check(f"{question[:40]!r} -> {heading}", got == heading, f"got {got}")

hits = rag.retrieve("what are your working hours")
check("hits carry a similarity score", hits[0]["similarity"] > 0)
check("hits carry their source file", hits[0]["source"].endswith(".txt"))
check("hits are ordered by similarity",
      [h["similarity"] for h in hits] == sorted(
          [h["similarity"] for h in hits], reverse=True))
check("k is respected", len(rag.retrieve("working hours", k=2)) <= 2)

# ===========================================================================
print("\n[3] Retrieval returns NOTHING when it should")
# ===========================================================================
for question in ["what is the capital of France",
                 "tell me about football scores",
                 "write me a poem about the sea",
                 "who won the election",
                 "xyzzy qqq zzz"]:
    hits = rag.retrieve(question)
    check(f"{question[:38]!r} retrieves nothing", hits == [], str(len(hits)))

for value in ["", "   ", None]:
    check(f"{value!r} retrieves nothing safely", rag.retrieve(value) == [])

answer = rag.answer_from_kb([])
check("an empty result admits it does not know",
      "do not have that information" in answer)
check("the admission suggests what can be asked", "working hours" in answer)
check("no sources line when nothing was found", rag.sources_line([]) == "")
check("no context block when nothing was found", rag.format_context([]) == "")

# ===========================================================================
print("\n[4] Routing - RAG is not used for provider filtering")
# ===========================================================================
policy_questions = ["what are your working hours", "can I cancel",
                    "which areas do you cover", "how much does it cost",
                    "do you take card payment", "what is your privacy policy"]
for question in policy_questions:
    check(f"routed to RAG: {question[:34]!r}", rag.is_policy_question(question))

faults = ["my kitchen sink is blocked", "my AC is leaking water",
          "the lights keep going off", "my washing machine is making a noise",
          "I need someone to paint my bedroom", "my door lock is broken"]
for fault in faults:
    check(f"not routed to RAG: {fault[:34]!r}", not rag.is_policy_question(fault))

check("a fault mentioning cost is still a fault",
      not rag.is_policy_question("my geyser is not working, how much will it cost"))
check("empty text is not a policy question", not rag.is_policy_question(""))

# ===========================================================================
print("\n[5] Context block for the model")
# ===========================================================================
hits = rag.retrieve("what is your cancellation policy")
context = rag.format_context(hits)
check("the context names the source file", "policies.txt" in context)
check("the context includes the passage text", "two hours" in context)
check("the context tells the model to use only this material",
      "ONLY" in context)
check("the context tells the model to admit gaps",
      "do not have that information" in context)
check("the context is labelled as reference material",
      context.startswith("\n\nREFERENCE INFORMATION"))

line = rag.sources_line(hits)
check("the sources line is readable", line.startswith("Answered from:"))
check("the sources line names the section", "Cancellation" in line)

# ===========================================================================
print("\n[6] Wired into the conversation - model available")
# ===========================================================================
stub = Stub({"service_category": None, "in_scope": True,
             "reply": "We attend between 9 AM and 8 PM, Monday to Saturday."})
turn = ui_logic.process_message("what are your working hours", [], {}, client=stub)
check("the model was called", len(stub.prompts) == 1)
check("the retrieved passage was put in the system prompt",
      "REFERENCE INFORMATION" in stub.prompts[0])
check("the passage itself is in the prompt", "9 AM and 8 PM" in stub.prompts[0])
check("the turn is marked as using retrieval", turn["slots"]["rag_used"] is True)
check("provenance is shown to the user",
      "Answered from" in turn["note_md"], turn["note_md"])
check("no provider cards for a policy question", turn["matches"] is None)
check("booking is not offered", turn["can_book"] is False)

stub = Stub({"service_category": "Plumber", "area": "Lahore",
             "reply": "Let me find a plumber.", "urgency": "normal"})
turn = ui_logic.process_message("my kitchen sink is blocked", [], {}, client=stub)
check("a fault does not trigger retrieval", turn["slots"]["rag_used"] is False)
check("no reference block in the prompt for a fault",
      "REFERENCE INFORMATION" not in stub.prompts[0])
check("a fault still returns providers", turn["can_book"] is True)

# ===========================================================================
print("\n[7] Wired into the conversation - model unavailable")
# ===========================================================================
dead = Stub(*[RuntimeError("no network")] * 6)
turn = ui_logic.process_message("can I cancel my booking", [], {}, client=dead)
check("retrieval still runs with no model", turn["slots"]["rag_used"] is True)
check("the passage becomes the reply",
      "two hours" in turn["reply"], turn["reply"][:100])
check("the reply names the section", "Cancellation policy" in turn["reply"])
check("provenance is still shown", "Answered from" in turn["note_md"])

dead = Stub(*[RuntimeError("no network")] * 6)
turn = ui_logic.process_message("what is the capital of France", [], {},
                                client=dead)
check("an unanswerable question is not bluffed",
      "do not have that information" in turn["reply"]
      or "could not reach" in turn["reply"].lower(), turn["reply"][:90])

# ===========================================================================
print("\n[8] Safety still comes first")
# ===========================================================================
stub = Stub({"reply": "x"})
turn = ui_logic.process_message("there is a gas smell, what are your hours",
                                [], {}, client=stub)
check("a hazard beats a policy question - no model call", len(stub.prompts) == 0)
check("the safety message is shown", "gas" in turn["reply"].lower())
check("retrieval is skipped under a hazard",
      turn["slots"].get("rag_used") is not True)

# ===========================================================================
print("\n[9] Resilience")
# ===========================================================================
check("rebuilding the index twice is stable", rag.rebuild_cache() == count)
check("the index is cached between calls",
      rag.build_index() is rag.build_index())
check("chunk_count matches the index", rag.chunk_count() == count)

original = config.KB_DIR
try:
    config.KB_DIR = config.BASE_DIR / "no_such_folder"
    rag._state.clear()
    check("a missing knowledge base does not crash", rag.load_chunks() == [])
    check("a missing knowledge base retrieves nothing",
          rag.retrieve("working hours") == [])
    check("a missing knowledge base reports no backend",
          rag.backend_name() == "none")
finally:
    config.KB_DIR = original
    rag._state.clear()
    rag.build_index()

check("the index recovers after the folder is restored", rag.chunk_count() == count)
check("retrieval works again", len(rag.retrieve("working hours")) > 0)

# ===========================================================================
print(f"\n{'=' * 46}")
print(f"  {PASSED} passed, {FAILED} failed")
print(f"{'=' * 46}\n")
sys.exit(1 if FAILED else 0)
